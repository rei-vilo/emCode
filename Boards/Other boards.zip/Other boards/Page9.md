---
tags:
    - Active
---

# Install the NodeMCU board

![](img/Logo-064-NodeMCU.png) The [NodeMCU board](http://nodemcu.com/index_en.html#fr_54747661d775ef1a3600009e) :octicons-link-external-16: is based on an ESP8266-12 but features a built-in serial over USB interface.

Although promoted for Lua, the board can be programmed using the Wiring / Arduino framework as the other ESP8266 boards.

If you plan to use the NodeMCU board:

+ Follow the procedure [Install the ESP8266 platform](../../Install/Section4/#install-the-esp8266-platform) :octicons-link-16:.

The NodeMCU board is considered a a generic ESP8266 board under the menu **Tools > Board**.

<center>![](img/114-01-420.png)</center>

The default uploader provided with the IDE, `esptool`, supports all the ESP8266-based boards, including the NodeMCU 0.9 and 1.0 boards, since release 0.4.5.

:octicons-plus-circle-16: The embedXcode+ edition allows to locate the Arduino or ESP8266 IDE in another folder.

+ Please refer to the section [Set the folder for standard IDEs](../../Install/Section3/#set-the-folder-for-standard-ides) :octicons-link-16:.

## Install the CH340 driver

The NodeMCU 0.9 uses the CH340 serial to USB programmer, which requires the installation of a specific driver.

<center>![](img/115-01-140.png)</center>

+ Download the [CH340 USB to Serial Driver for Mac](http://www.wch.cn/download/CH341SER_MAC_ZIP.html) :octicons-link-external-16:.

+ Unzip it.

+ Launch the `CH34x_Install.pkg` installation package.

+ Relaunch the Mac.

Release 1.2 of the driver is signed and thus no longer requires disabling the driver signing verification on Mac OS X.

A more detailed procedure is provided at [How to Use Cheap Chinese Arduinos That Come With CH340G / CH341G Serial/USB Chip (Windows & Mac OS-X)](http://kig.re/2014/12/31/how-to-use-arduino-nano-mini-pro-with-CH340G-on-mac-osx-yosemite.html) :octicons-link-external-16:.

+ In case a prior version of the driver was installed, uninstall it first.

For more information,

+ Please refer to the [WCH website](http://www.wch.cn) :octicons-link-external-16: and to the instructions included in the `ReadMe` file, available in English.

## Install the CP2102 driver

The NodeMCU 1.0 uses the CP2102 serial to USB programmer, which requires the installation of a specific driver.

<center>![](img/115-02-180.png)</center>

+ Download the [CP210x USB to UART Bridge VCP Driver for Mac](https://www.silabs.com/products/development-tools/software/usb-to-uart-bridge-vcp-drivers) :octicons-link-external-16:.

+ Open it.

+ Launch the `Silicon Labs VCP Driver.pkg` installation package.

For more information,

+ Please refer to the application note [The Serial Communications Guide for the CP210x](https://www.silabs.com/Support Documents/TechnicalDocs/an197.pdf) :octicons-link-external-16:.

## Check the tests

The test protocol includes building and linking, uploading and running a sketch on the boards using those versions of the IDEs and plug-ins. Boards packages are versioned but not dated.

| | Platform | IDE | Package | Date | Comment
---- | ---- | ---- | ---- | ---- | ----

## Visit the official websites

![](img/Logo-064-NodeMCU.png) | **NodeMCU Board**
:---- | ----
IDE | Arduino with Boards Manager
Website | <http://nodemcu.com/index_en.html> :octicons-link-external-16:
Download | <https://github.com/nodemcu> :octicons-link-external-16:
Forum | <http://bbs.nodemcu.com> :octicons-link-external-16:
Driver for 0.9 | <http://www.wch.cn/download/CH341SER_MAC_ZIP.html> :octicons-link-external-16:
Driver for 1.0 | <https://www.silabs.com/products/development-tools/software/usb-to-uart-bridge-vcp-drivers> :octicons-link-external-16: