---
tags:
    - Active
---

# Install the ATtinyCore platform

:octicons-plus-circle-16: This section requires the embedXcode+ edition.

The installation of the ATtinyCore platform is performed with the **Boards Manager** on the Arduino 1.8 IDE.

If you plan to use the ATtiny MCUs,

+ Download and install the supported versions of the Arduino IDE under the `/Applications` folder, as described in the section [Install the Arduino platform](../../Install/Section4/Arduino) :octicons-link-16:.

+ Launch it.

+ Define the path of the sketchbook folder in the menu **Arduino > Preferences > Sketchbook location**.

+ Avoid spaces in the name and path of the sketchbook folder.

+ Follow the procedure [Install additional boards on Arduino](../../Install/Section4/#install-additional-boards-on-arduino) :octicons-link-16:.

+ Call the **Boards Manager** and check the ATtinyCore boards are listed.

<center>![](img/062-02-420.png)</center>

If the ATtinyCore boards aren't listed on the **Boards Manager**,

+ Open the **Preferences**.

+ Add the following URL on a separate line, as described in section [Add URLs for new boards](../../Install/Section4/#add-urls-for-new-boards) :octicons-link-16:.

```
http://drazzy.com/package_drazzy.com_index.json
```

+ Select the boards and click on **Install**.

For more information,

+ Please refer to the [Installation](https://github.com/SpenceKonde/ATTinyCore/blob/master/Installation.md) :octicons-link-external-16: section of the ATTiny Core repository.

## Check the tests

The test protocol includes building and linking, uploading and running a sketch on the boards using those versions of the IDEs and plug-ins. Boards packages are versioned but not dated.

| | Platform | IDE | Package | Date | Comment
---- | ---- | ---- | ---- | ---- | ----
![](img/Logo-064-ATtinyCore-alpha.png) | **ATtinyCore** | Arduino 1.8 | 1.3.3 | |
