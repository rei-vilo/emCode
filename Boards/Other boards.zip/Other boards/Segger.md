---
tags:
    - Active
---

# Install utilities for Segger debugger

:octicons-plus-circle-16: This section requires the embedXcode+ edition.

The Segger J-Link is a very popular JTAG and SWD emulator for ARM Cortex-M cores. It comes with a full software suite.

<center>![](img/148-01-180.png)</center>

## Install the Segger J-Link Software Suite

Segger provides a comprehensive software suite that works better than **OpenOCD** with the Segger J-Link programmer-debugger.

<center>![](img/148-02-200.png)</center>

If you plan to use the Segger J-Link debugger,

+ Download the latest release of the [J-Link Software and Documentation pack for Mac OS X](https://www.segger.com/downloads/jlink) :octicons-link-external-16:, version `6.00g` or later.

+ Install the software.

By default, the software is located at `/Applications/SEGGER`.

If the IDEs are located in another folder, as described at section [Set the folder for standard IDEs](../../Install/Section3/#set-the-folder-for-standard-ides) :octicons-link-16:,

+ Move the `/Applications/SEGGER` folder onto the specific folder for IDEs.

<center>![](img/149-01-360.png)</center>

In this example, the specific folder is called IDE and the full path is `/Applications/IDE/SEGGER`.

It is important to keep the JLink symbolic link to the current version, here `JLink_V60g`.
If the symbolic link has been lost,

+ Open a **Terminal** window.

+ Enter the commands to select the folder and create the symbolic link.

``` bash
$ cd /Applications/IDE/SEGGER
$ sudo ln -s JLink_V60g/ JLink
```

For more information about the Segger J-Link emulator,

+ Please refer to the list of [Supported CPUs and devices](https://www.segger.com/jlink_supported_devices.html) :octicons-link-external-16: and to the document [Segger J-Link / J-Trace User Guide](https://www.segger.com/jlink-gdb-server.html) :octicons-link-external-16:.

## Install the Segger Ozone Graphical Debugger

Segger provides Ozone, a free graphical debugger, to use with the Segger J-Link.

<center>![](img/150-01-070.png)</center>

If you plan to use the Segger Ozone graphical debugger,

+ Proceed first with the installation of the latest release of the **Segger J-Link** debugger as per the [Install the Segger J-Link Software Suite](../../Install/Section4/#install-the-segger-j-link-software-suite]  :octicons-link-16: procedure.

+ Ensure the release of `J-Link` is `6.12i` or later.

+ Download the latest release of the [Ozone J-Link Debugger for Mac OS X](https://www.segger.com/downloads/jlink) :octicons-link-external-16:, version 2.22o or later.

+ Install the software.

By default, the software is located at `/Applications/SEGGER/Ozone`.

If the IDEs are located in another folder, as described at section [Set the folder for standard IDEs](../../Install/Section3/#set-the-folder-for-standard-ides) :octicons-link-16:,

+ Move the `/Applications/SEGGER/Ozone` folder onto the Segger sub-folder of the specific folder for IDEs,
In the example, the specific folder is called IDE and the full path is `/Applications/IDE/SEGGER/Ozone`.

## Visit the official websites

![](img/Logo-064-J-Link.png) | **Segger J-Link**
:---- | ----
Website | <https://www.segger.com> :octicons-link-external-16:
Download | <https://www.segger.com/downloads/jlink> :octicons-link-external-16:
Blog | <https://blog.segger.com> :octicons-link-external-16:
Forum | <http://forum.segger.com> :octicons-link-external-16:

