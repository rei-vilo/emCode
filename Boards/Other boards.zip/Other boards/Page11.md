---
tags:
    - Active
---

# Install the nRF5 boards platform

![](img/Logo-064-Nordic.png) The nRF5 boards platform by Sandeep Mistry provides support for a wide range of nRF51 and nRF52 boards, including the [BBC micro:bit board](../../Install/Section4/Page10) :octicons-link-16: and the [RedBear boards](Legacy/Section4/Page16) :octicons-link-16:. The installation is performed with the **Boards Manager** on the Arduino 1.8 IDE.

+ Ensure **Arduino-CLI** is installed. 

+ Open a **Terminal** window.

+ Run

``` bash
$
arduino-cli core install sandeepmistry:nRF5
```

## Install the platform

If you plan to use the nRF5 boards platform,

+ Download and install the supported versions of the Arduino IDE under the `/Applications` folder, as described in the section [Install the Arduino platform](../../Install/Section4/Arduino) :octicons-link-16:.

+ Launch it.

+ Define the path of the sketchbook folder in the menu **Arduino > Preferences > Sketchbook location**.

+ Avoid spaces in the name and path of the sketchbook folder.

+ Follow the procedure [Install additional boards on Arduino](../../Install/Section4/#install-additional-boards-on-arduino) :octicons-link-16:. Call the **Boards Manager** and check the nRF5 boards platform is listed.

<center>![](img/116-02-420.png)</center>

If the nRF5 boards platform isn't listed on the **Boards Manager**,

+ Open the **Preferences**.

+ Add the following URL on a separate line, as described in section [Add URLs for new boards](../../Install/Section4/#add-urls-for-new-boards) :octicons-link-16:.

```
https://sandeepmistry.github.io/arduino-nRF5/package_nRF5_boards_index.json
```

+ Select the boards and click on **Install**.

For more information on the installation of the nRF5 boards platform,

+ Please refer to the [Installing](https://github.com/sandeepmistry/arduino-nRF5#installing) :octicons-link-external-16: section on the nRF5 boards GitHub repository.

+ Please refer to the extensive guide [micro:bit with Arduino](https://learn.adafruit.com/use-micro-bit-with-arduino/overview) :octicons-link-external-16: by Adafruit.

## Install the libraries

Before using Bluetooth, the stack called SoftDevice needs to be uploaded to the board.

+ For the BBC micro:bit board, follow the procedure [Install SoftDevice onto MicroBit](https://learn.adafruit.com/use-micro-bit-with-arduino/install-board-and-blink#install-softdevice-onto-microbit-2-5) :octicons-link-external-16: from the Adafruit Learning System.

+ Alternatively, refer to [Selecting a SoftDevice](https://github.com/sandeepmistry/arduino-nRF5#selecting-a-softdevice) :octicons-link-external-16: and [Flashing a SoftDevice](https://github.com/sandeepmistry/arduino-nRF5#flashing-a-softdevice) :octicons-link-external-16: sections on the nRF5 boards GitHub repository.

The recommended Bluetooth library is [BLEPeripheral](https://github.com/sandeepmistry/arduino-BLEPeripheral) :octicons-link-external-16:, also developed by Sandeep Mistry.

+ Please refer to [Install additional libraries on Arduino](../Install/Section4/#install-additional-libraries-on-arduino) :octicons-link-16:.

Adafruit provides a nice library to use the LED matrix and the Bluetooth connection.

+ Please refer to [Download Adafruit_Microbit library](https://learn.adafruit.com/use-micro-bit-with-arduino/adafruit-libraries#download-adafruit-microbit-library-6-6) :octicons-link-external-16: on the Adafruit Learning System.

## Install the Adafruit Bluefruit LE Connect application

Appart from the official [micro:bit companion app](https://microbit.org/guide/mobile/#og-app) :octicons-link-external-16: for Android or iOS, the [Bluefruit LE Connect for iOS and Android](https://learn.adafruit.com/bluefruit-le-connect/ios-setup) :octicons-link-external-16: application from Adafruit allows to connect to the BBC micro:bit and interact with the examples.

+ Follow the procedure [Installation and Setup](https://learn.adafruit.com/bluefruit-le-connect/ios-setup) :octicons-link-external-16: from the Adafruit Learning System.

The Adafruit Bluefruit LE Connect application is also available for macOS.

+ Install the [Adafruit Bluefruit LE Connect](https://itunes.apple.com/app/adafruit-bluefruit-le-connect/id830125974?mt=8) :octicons-link-external-16: for macOS from the Apple Mac Store.

## Check the tests

The test protocol includes building and linking, uploading and running a sketch on the boards using those versions of the IDEs and plug-ins. Boards packages are versioned but not dated.

| | Platform | IDE | Package | Date | Comment
---- | ---- | ---- | ---- | ---- | ----
![](img/Logo-064-Nordic.png) | **nRF5 boards** | Arduino 1.8 | 0.7.0 | | Additional libraries are required

## Visit the official websites

![](img/Logo-064-Nordic.png) | **nRF5 boards**
:---- | ----
IDE | Arduino with Boards Manager
Boards package | <https://github.com/sandeepmistry/arduino-nRF5> :octicons-link-external-16:
Library | <https://github.com/sandeepmistry/arduino-BLEPeripheral> :octicons-link-external-16:
Wiki | <https://github.com/sandeepmistry/arduino-nRF5#selecting-a-softdevice> :octicons-link-external-16: and <https://github.com/sandeepmistry/arduino-nRF5#flashing-a-softdevice> :octicons-link-external-16:
