---
tags:
    - Active
---

# Install the RasPiArduino platform

![](img/Logo-064-Raspberry-Pi.png) The [RasPiArduino platform](https://github.com/me-no-dev/RasPiArduino) :octicons-link-external-16: provides an easy solution for the Raspberry Pi computer boards.

Unless other boards packages, it is not managed by the **Board Manager** but comes instead as a package to be installed on the `hardware` sub-folder of the Arduino sketchbook folder.

The RasPiArduino platform uses the GPIO numbers instead of the pins number.

<center>![](img/RasPi-2.png)</center>

+ Please refer to the official [GPIO](https://www.raspberrypi.org/documentation/usage/gpio/README.md) :octicons-link-external-16: maps from the Raspberry Pi website or the [interactive pinout diagram](http://pinout.xyz/) :octicons-link-external-16:.

## Install the RasPiArduino boards package

If you plan to use the RasPiArduino package,

+ Download and install the supported versions of the Arduino IDE under the `/Applications` folder, as described in the section [Install the Arduino platform](../../Install/Section4/Arduino) :octicons-link-16:.

+ Launch it.

+ Define the path of the sketchbook folder in the menu **Arduino > Preferences > Sketchbook location**.

+ Avoid spaces in the name and path of the sketchbook folder.

+ Open the sketchbook folder defined previously, `~/Documents/Arduino` in this example.

+ Open a **Terminal** window.

+ Ensure `git` is installed.

``` bash
% git --version
```

If `git` is not installed, we need **Homebrew** to install it.

+ If **Homebrew** if not installed, launch

``` bash
% /usr/bin/ruby -e "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/master/install)"
```

+ Then launch

``` bash
% brew install git
```

+ Download and install the RasPiArduino board package.

``` bash
% cd ~/Documents/Arduino
% mkdir -p Hardware/RaspberryPi
% cd Hardware/RaspberryPi
% git clone https://github.com/me-no-dev/RasPiArduino piduino
```

+ Download and install the `arm-linux-gnueabihf` tool-chain.

``` bash
% cd ~/Documents/Arduino/piduino
% mkdir -p piduino/tools/arm-linux-gnueabihf
% cd piduino/tools
% wget https://github.com/me-no-dev/RasPiArduino/releases/download/0.0.1/arm-linux-gnueabihf-osx.tar.gz
% tar xvzf arm-linux-gnueabihf-osx.tar.gz arm-linux-gnueabihf/
```

+ Authorise the executables from the folders `arm-linux-gnueabihf/arm-linux-gnueabihf/bin` and `arm-linux-gnueabihf/bin`.

For more information on the installation of the Arduino IDE,

+ Please refer to the [Instructions for Arduino IDE](https://github.com/me-no-dev/RasPiArduino#instructions-for-arduino-ide) :octicons-link-external-16: section on the GitHub repository.

For more information on how to authorise the utilities,

+ Please refer to the section [Authorise the utilities](../../Install/Section3/#authorise-the-utilities) :octicons-link-16:.

## Install the tools and SDK on the Raspberry Pi

+ Connect to the Raspberry Pi though SSH.

+ On the SSH console, launch

``` bash
$ sudo su
$ passwd
```

+ Enter the password twice.

+ Edit `/etc/ssh/sshd_config` and add

```
PermitRootLogin yes
PasswordAuthentication yes
```

+ Check the serial console is disable by removing `console=/dev/ttyAMA0` from `/boot/cmdline.txt`.

+ Disable the serial TTY and the sound kernel module.

``` bash
$ systemctl disable serial-getty@ttyAMA0
$ sed -i "s/dtparam=audio=on/#dtparam=audio=on/" /boot/config.txt
```

+ Edit the service `/etc/avahi/services/arduino.service` to allow the Arduino IDE to upload the sketch.

```
<?xml version="1.0" standalone='no'?><!--*-nxml-*-->
<!DOCTYPE service-group SYSTEM "avahi-service.dtd">
<service-group>
  <name replace-wildcards="yes">%h</name>
  <service>
    <type>_arduino._tcp</type>
    <port>22</port>
    <txt-record>board=bplus</txt-record>
  </service>
</service-group>
```

+ Authorise the new service.

``` bash
$ service avahi-daemon restart
```
+ Install Git and Telnet.

``` bash
$ apt-get update
$ apt-get install telnet git
```

+ Download and install the SDK

``` bash
$ git clone https://github.com/me-no-dev/RasPiArduino.git piduino
$ chmod +x piduino/tools/arpi_bins/*
$ cp piduino/tools/arpi_bins/* /usr/local/bin
$ rm -rf piduino
$ ln -s /usr/local/bin/run-avrdude /usr/bin/run-avrdude
```

+ Optionally for debugging, install the GDB server.

``` bash
$ apt-get update
$ apt-get install telnet git gdbserver
```

+ Finally, reboot.

``` bash
$ reboot
```

For more information on the installation of the Arduino IDE,

+ Please refer to the [Instructions for the Pi](https://github.com/me-no-dev/RasPiArduino#instructions-for-the-pi) :octicons-link-external-16: section on the GitHub repository.

## Connect the board

The Raspberry Pi is available under the menu **Tools > Board > Raspberry Pi** and its address appears under **Tools > Port**.

<center>![](img/RasPi-0.png)</center>

## Check the tests

The test protocol includes building and linking, uploading and running a sketch on the boards using those versions of the IDEs and plug-ins. Boards packages are versioned but not dated.

| | Platform | IDE | Package | Date | Comment
---- | ---- | ---- | ---- | ---- | ----
![](img/Logo-064-Raspberry-Pi.png) | **RasPiArduino** | Arduino 1.8 | 0.0.1 | | For Raspberry Pi boards, not recommended

## Visit the official websites

![](img/Logo-064-Raspberry-Pi.png) | **RasPiArduino**
:---- | ----
IDE | Arduino with hardware sub-folder
Repository | <https://github.com/me-no-dev/RasPiArduino> :octicons-link-external-16:
Wiki | <https://github.com/me-no-dev/RasPiArduino/wiki> :octicons-link-external-16:
Website | <https://www.raspberrypi.org> :octicons-link-external-16:
