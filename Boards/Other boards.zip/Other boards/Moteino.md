---
tags:
    - Active
---

# Install the Moteino platform

:octicons-plus-circle-16: This section requires the embedXcode+ edition.

![](img/Logo-064-Moteino.png) The Moteino platform by LowPowerLab combines an ATMega328 with a RFM69 sub-1GHz or a RFM95 LoRa radio. The installation of the Moteino platform is performed with the **Boards Manager** on the Arduino 1.8 IDE.

An external [FTDI programmer](https://lowpowerlab.com/shop/FTDI-Adapter) :octicons-link-external-16: is required.

+ Ensure **Arduino-CLI** is installed. 

+ Open a **Terminal** window.

+ Run

``` bash
$
arduino-cli core install Moteino:avr
```

## Install the Moteino platform

If you plan to use the Moteino platform,

+ Download and install the supported versions of the Arduino IDE under the `/Applications` folder, as described in the section [Install the Arduino platform](../../Install/Section4/Arduino) :octicons-link-16:.

+ Launch it.

+ Define the path of the sketchbook folder in the menu **Arduino > Preferences > Sketchbook location**.

+ Avoid spaces in the name and path of the sketchbook folder.

+ Follow the procedure [Install additional boards on Arduino](../../Install/Section4/#install-additional-boards-on-arduino) :octicons-link-16:.

+ Call the **Boards Manager** and check the Moteino platform is listed.

<center>![](img/111-01-420.png)</center>

If the Moteino platform isn't listed on the **Boards Manager**,

+ Open the **Preferences**.

+ Add the following URL on a separate line, as described in section [Add URLs for new boards](../../Install/Section4/#add-urls-for-new-boards) :octicons-link-16:.

```
https://lowpowerlab.github.io/MoteinoCore/package_LowPowerLab_index.json
```

+ Select the board and click on **Install**.

For more information on the installation of the Arduino IDE,

+ Please refer to the [Programming and Libraries](http://lowpowerlab.com/moteino/#programming) :octicons-link-external-16: page on the LowPowerLab website.

## Install the libraries

The RFM69 sub-1GHz-based board requires the [RFM69 library](https://github.com/LowPowerLab/RFM69) :octicons-link-external-16:, while the RFM95 LoRa-based board requires the [LoRa library](http://lowpowerlab.com/RadioHead_LowPowerLab.zip) :octicons-link-external-16: from [RadioHead](http://www.airspayce.com/mikem/arduino/RadioHead/) :octicons-link-external-16:.

Optionally, the Moteino platform requires the installation of the [SPIFlash library](https://github.com/LowPowerLab/SPIFlash) :octicons-link-external-16: if the SPI flash is populated, and the [WirelessHEX69 library](https://github.com/LowPowerLab/WirelessProgramming/tree/master/WirelessHEX69) :octicons-link-external-16: for wireless programming.

For each library,

+ Download the compressed `.zip` file.

+ Unzip the file.

+ Copy the resulting folder as a user's library on the `Libraries` sub-folder of the sketchbook folder.

The user's libraries are stored on the `Libraries` or `libraries` sub-folder under the sketchbook folder.

For more information on the LoRa radio,

+ Please refer to the page [LoRa Transceiver Support](http://lowpowerlab.com/moteino/#wirelessprogramming) :octicons-link-external-16: page on the LowPowerLab website.

For more information on the wireless programming,

+ Please refer to the page [Wireless Programming](http://lowpowerlab.com/moteino/#wirelessprogramming) :octicons-link-external-16: page on the LowPowerLab website.

## Connect the board

The Moteino boards appear under the menu **Tools > Board**.

<center>![](img/113-01-420.png)</center>

For more information on the installation of the panStamp plug-in,

+ Please refer to the [Moteino](http://lowpowerlab.com/moteino/#whatisit) :octicons-link-external-16: page the LowPowerLab website.

## Check the tests

The test protocol includes building and linking, uploading and running a sketch on the boards using those versions of the IDEs and plug-ins. Boards packages are versioned but not dated.

| | Platform | Package | Date | Comment
---- | ----  | ---- | ---- | ----
![](img/Logo-064-Moteino.png) | **Moteino** | 1.6.2 | | Additional libraries are required
![](img/Logo-064-emCode.png) | emCode | 13.0.3 | 09 Feb 2023 | 

## Visit the official websites

![](img/Logo-064-Moteino.png) | **Moteino**
:---- | ----
Download | <http://lowpowerlab.com/moteino/#programming> :octicons-link-external-16: and <https://github.com/lowpowerlab> :octicons-link-external-16:
Forum | <http://lowpowerlab.com/forum> :octicons-link-external-16: