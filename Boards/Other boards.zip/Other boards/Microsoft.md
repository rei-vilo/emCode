---
tags:
    - Active
---

# Install the Microsoft platform

+ Ensure **Arduino-CLI** is installed. 

+ Open a **Terminal** window.

+ Run

``` bash
$
arduino-cli core install AZ3166:stm32f4
```

:octicons-plus-circle-16: This section requires the embedXcode+ edition.

![](img/Logo-064-Microsoft.png) The Microsoft IoT DevKit platform combines a Cortex-M4 and a WiFi radio and a large assortment of sensors. The installation of the Microsoft platform is performed with the **Boards Manager** on the Arduino 1.8 IDE.

## Install the Microsoft platform

If you plan to use the Microsoft platform,

+ Download and install the supported versions of the Arduino IDE under the `/Applications` folder, as described in the section [Install the Arduino platform](../../Install/Section4/Arduino) :octicons-link-16:.

+ Launch it.

+ Define the path of the sketchbook folder in the menu **Arduino > Preferences > Sketchbook location**.

+ Avoid spaces in the name and path of the sketchbook folder.

+ Follow the procedure [Install additional boards on Arduino](../../Install/Section4/#install-additional-boards-on-arduino) :octicons-link-16:.

+ Call the **Boards Manager** and check the Microsoft platform is listed.

<center>![](img/109-01-420.png)</center>

If the Microsoft platform isn't listed on the **Boards Manager**,

+ Open the **Preferences**.

+ Add the following URL on a separate line, as described in section [Add URLs for new boards](../../Install/Section4/#add-urls-for-new-boards) :octicons-link-16:.

```
https://raw.githubusercontent.com/VSChina/azureiotdevkit_tools/master/package_azureboard_index.json
```

+ Select the board and click on **Install**.

For more information on the installation of the Arduino IDE,

+ Please refer to the [Get Started](https://microsoft.github.io/azure-iot-developer-kit/docs/get-started/) :octicons-link-external-16: page on the Microsoft website.

+ Download and install the Azure command line tool from the [macOS Azure Manual Installation](https://microsoft.github.io/azure-iot-developer-kit/docs/installation/) :octicons-link-external-16: page on the Microsoft website.

For more information on the Azure installation,

+ Please refer to the [Install Azure CLI 2.0](https://docs.microsoft.com/en-us/cli/azure/install-azure-cli#macos) :octicons-link-external-16: page on the Microsoft website.

For more information,

+ Please refer to the [MXChip IoT Developer Kit](https://microsoft.github.io/azure-iot-developer-kit) :octicons-link-external-16: page on the Microsoft website.

## Fix the Compiler Error

Compiling against the AZ3166 with standard tools may raise the error `Expected ')' before numeric constant`.

+ Please refer to the ticket [Error: Expected ')' before numeric constant (1.2.0.28)](https://github.com/Microsoft/azure-iot-developer-kit/issues/169#issuecomment-340347238) :octicons-link-external-16:.

## Check the tests

The test protocol includes building and linking, uploading and running a sketch on the boards using those versions of the IDEs and plug-ins. Boards packages are versioned but not dated.

| | Platform | IDE | Package | Date | Comment
---- | ---- | ---- | ---- | ---- | ----
![](img/Logo-064-Microsoft.png) | **Microsoft** | Arduino 1.8 | AZ3166 2.0.0 | | For AZ3166 IoT DevKit board

## Visit the official websites

![](img/Logo-064-Microsoft.png) | **Microsoft**
:---- | ----
IDE | Arduino
Website | <https://microsoft.github.io/azure-iot-developer-kit> :octicons-link-external-16:
Download | <https://microsoft.github.io/azure-iot-developer-kit/docs/installation/> :octicons-link-external-16:
Wiki | <https://microsoft.github.io/azure-iot-developer-kit/docs/get-started/> :octicons-link-external-16: