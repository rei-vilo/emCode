---
tags:
    - Active
---

# Install another platform

![](img/Logo-064-Processing.png) For other boards, the procedures are the same.
For boards based on a Processing-based Wiring-derived Arduino-like IDE,

+ Download and install the corresponding Processing-based Wiring-derived Arduino-like IDE under the `/Applications` folder.

+ Launch it.

+ Define the path of the sketchbook.

For boards installed as a package with the **Boards Manager** of the Arduino IDE,

+ Follow the procedure [Install additional boards on Arduino](../../Install/Section4/#install-additional-boards-on-arduino) :octicons-link-16:.

Additionally, other steps are required to add supports for the new board to embedXcode, as developing a specific makefile and a specific upload procedure, proceeding with tests and validations, and integrating the new template in the suite.

+ Please refer to section [What requirements to meet when asking support for a new board](../../Chapter7/Section3/#what-requirements-to-meet-when-asking-support-for-a-new-board) :octicons-link-16:.

:octicons-plus-circle-16: The embedXcode+ edition allows to locate the IDE in another folder.

+ Please refer to the section [Set the folder for standard IDEs](../../Install/Section3/#set-the-folder-for-standard-ides) :octicons-link-16:.

# Install drivers for programmers and debuggers

:octicons-plus-circle-16: This section requires the embedXcode+ edition.

Some boards require specific drivers.

## Install the AVRDUDE utility

:octicons-plus-circle-16: This section requires the embedXcode+ edition.

Some boards aren't defined by Arduino, so you need to add them. A list is supplied by the `avrduderc.txt` file located in the embedXcode folder and needs to be copied into the user's home folder.

+ Open the **Terminal** and launch the following commands

``` bash
$ cd ~/Documents/embedXcode
$ cp avrduderc.txt ~/.avrduderc
```

For more information,

+ Please refer to the [AVRDUDE User Manual](http://www.nongnu.org/avrdude/user-manual/avrdude.html) :octicons-link-external-16:.

Similarly, if you plan to use other MCUs from AVR, you may need to install a more recent version of AVRDUDE, as Arduino still uses release 5.11 dated August 2011.

To install a more recent release of AVRDUDE,

+ Download [AVRDUDE release 6.0.1](http://www.nongnu.org/avrdude/) :octicons-link-external-16: or later,

+ Unzip the compressed file,

+ Open the **Terminal** and launch the following commands, with `path_to_avrdude` being the path to `avrdude-6.0.1`, `~/Downloads/avrdude-6.0.1` in the example.

``` bash
$ cd ~/Downloads/avrdude-6.0.1
$ ./configure; make; make install
```

To know where `avrdude` has been installed,

+ Launch the command

``` bash
$ which avrdude

/usr/local/bin/avrdude
```

To check the release and know where the configuration file is located,

+ Launch the command

``` bash
$ /usr/local/bin/avrdude -v
avrdude: Version 6.0.1, compiled on Nov 2 2013 at 17:50:28
Copyright (c) 2000-2005 Brian Dean, http://www.bdmicro.com/
Copyright (c) 2007-2009 Joerg Wunsch
System wide configuration file is "/usr/local/etc/avrdude.conf"
```

The configuration file for AVRDUDE is located at `/usr/local/etc/avrdude.conf`.

## Install the telnet utility

It looks like macOS 10.13 *Sierra* and higher no longer provide **telnet**.

+ Use **nc** (netcat) instead.

+ Install **telnet**.

To install **telent**,

+ Open a **Terminal** window.

+ Launch the following command to install **Homebrew**.

``` bash
$ /usr/bin/ruby -e "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/master/install)"
```

+ Launch the following command to install telnet.

``` bash
$ brew install telnet
```

## Install the FTDI driver

If you plan to use a programmer like the [5V FTDI basic from Sparkfun](https://www.sparkfun.com/products/9716) :octicons-link-external-16:, the [USB ASP from Protostack](http://www.protostack.com/accessories/usbasp-avr-programmer) :octicons-link-external-16:, the [USB tinyISP from Adafruit](http://www.adafruit.com/products/46) :octicons-link-external-16:, the USB Spoke POV dongle or similar, you may need to install the FTDI drivers,

<center>![](img/145-01-320.png)</center>

+ Download [FTDI USB Serial Driver version 2.3](http://www.ftdichip.com/Drivers/VCP.htm) :octicons-link-external-16: or later,

+ Install the drivers,

+ Reboot your Mac.

Rebooting the Mac is compulsory, otherwise the drivers aren't taken into account.

For more information,

+ Please refer to the [FTDI Drivers Installation Guide for Mac OS X](http://www.ftdichip.com/Support/Documents/AppNotes/AN_134_FTDI_Drivers_Installation_Guide_for_MAC_OSX.pdf) :octicons-link-external-16:.

When a board with a FTDI is connected to the Mac with a serial console open on a Terminal window, always use the following procedure to close the session.

+ Use the ++ctrl+a++ ++ctrl+k++ key sequence.

<center>![](img/146-01-300.png)</center>

+ Then press ++y++ to confirm.

Otherwise, the USB port is no longer listed. This is a bug on Mac OS X 10.11.4.

## Install the OpenOCD driver

The Open On-Chip Debugger, or **OpenOCD**, provides tools for programming and debugging MCUs. It runs with other software like GDB from the GCC tool-chain.

<center>![](img/146-02-400.png)</center>

It requires a hardware programmer-debugger. The installation of **OpenOCD** is done using either **Homebrew** or [MacPorts](../../Legacy/Section2/#install-openocd-with-macports) :octicons-link-16:. **Homebrew** is recommended over **MacPorts** .

**OpenOCD** requires the previous installation of [libusb](http://www.libusb.org) :octicons-link-external-16:, a library that provides an easy access to USB devices.

To install **OpenOCD** with **Homebrew**,

<center>![](img/146-03-260.png)</center>

+ Open a **Terminal** window.

+ Launch the following command to install **Homebrew**.

``` bash
$ /usr/bin/ruby -e "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/master/install)"
```

+ Launch the following command to install **libusb**.

``` bash
$ brew install libusb
```

Launch the following command to install `openOCD`.

``` bash
$ brew install openocd
```

Some boards require a specific installation of **OpenOCD**. This is done by specifying options during installation.

For example, the CC3200 LaunchPad requires the `--enable-ft2232_libftdi --enable-stlink` options.

=== "Homebrew release prior to 2.0"

    With **Homebrew** release prior to 2.0, the options were listed on the installation command line, tested on OpenOCD version 0.9.0:

    ``` bash
    $ brew install openocd --enable-ft2232_libftdi --enable-stlink
    ```

    Those options can be combined with those for other boards.

=== "Homebrew release 2.0 and later"

    Since release 2.0, **Homebrew** no longer accepts the options listed on the installation command line. The new procedure relies on the `--edit` option, tested on OpenOCD version 0.10.0.

    + On a **Terminal** window, launch to open the default editor.

    ``` bash
    % brew edit openocd
    ```

    + To use a specific editor, define the `HOMEBREW_EDITOR` variable before.

    ``` bash
    % export HOMEBREW_EDITOR=/usr/local/bin/nano
    % brew edit openocd
    ```

    + Add the options, then save and close the editor.

    <center>![](img/080-02-640.png)</center>

    + Now, launch the installation of **OpenOCD**:

    ``` bash
    % brew install openocd
    ```

For more information on the configuration of **OpenOCD**,

+ Please refer to the [OpenOCD documentation](http://openocd.sourceforge.net/documentation) :octicons-link-external-16: and to the websites of the respective manufacturers of the boards.

For more information on the use of **Homebrew**,

+ Please refer to the [Homebrew Documentation](https://docs.brew.sh) :octicons-link-external-16:.

## Install the OpenOCD driver for ESP32

![](img/Logo-064-Espressif-Systems.png) The ESP-Prog programmer-debbuger brings JTAG debugging to the ESP32 boards, but requires a specific version of OpenOCD.

+ Download the latest release of OpenOCD for ESP32 from the [openocd-esp32 repository](https://github.com/espressif/openocd-esp32/releases) :octicons-link-external-16:.

+ Unzip the file, `openocd-esp32-macos-0.10.0-esp32-20191114.tar` to obtain `~/Downloads/openocd-esp32` in the example.

+ Open a **Terminal** and launch the following commands.

``` bash
% mkdir -p ~/Library/Arduino15/packages/esp32/tools/openocd-esp32/0.10.0-esp32-20191114
% cp -r ~/Downloads/openocd-esp32/* ~/Library/Arduino15/packages/esp32/tools/openocd-esp32/0.10.0-esp32-20191114
```

+ Check the utility has been correctly installed.

``` bash
% ~/Library/Arduino15/packages/esp32/tools/openocd-esp32/v0.10.0-esp32-20191114/bin/openocd -v
Open On-Chip Debugger  v0.10.0-esp32-20191114 (2019-11-14-14:19)
Licensed under GNU GPL v2
For bug reports, read
http://openocd.org/doc/doxygen/bugs.html
```

For more information on OpenOCD for ESP32,

+ Please refer to [Setup of OpenOCD](https://docs.espressif.com/projects/esp-idf/en/latest/api-guides/jtag-debugging/#setup-of-openocd) :octicons-link-external-16: and [Configuring ESP32 Target](https://docs.espressif.com/projects/esp-idf/en/latest/api-guides/jtag-debugging/#configuring-esp32-target) :octicons-link-external-16: on the Espressif website.

## Install the Texane ST-Link driver

The driver STMicroelectronics recommends is **ST-Link**, part of the [STM32CubeProgrammer](https://www.st.com/en/development-tools/stm32cubeprog.html) :octicons-link-external-16: package. However, it requires Java. **Texane ST-Link** offers an open-source and native version of the STMicroelectronics ST-Link tools.

The Texane ST-Link utilities include the uploader `st-flash` and the debugger server `st-util` compatible with GDB.

+ Open a **Terminal** window.

+ Launch the following command to install **Homebrew**.

``` bash
$ /usr/bin/ruby -e "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/master/install)"
```

+ Launch the following command to install **Texane ST-Link** and its dependencies.

``` bash
$ brew install stlink
```

For more information on the installation of the utilities,

+ Please refer to the [Open source version of the STMicroelectronics ST-Link tools](https://github.com/texane/stlink) :octicons-link-external-16: page and the [Installation](https://github.com/texane/stlink#installation) :octicons-link-external-16: section on the GitHub repository.

## Check the tests

The test protocol includes building and linking, uploading and running a sketch on the boards using those versions of the IDEs and plug-ins. Boards packages are versioned but not dated.

| | Platform | IDE | Package | Date | Comment
---- | ---- | ---- | ---- | ---- | ----
