---
tags:
    - Active
---

# Install the DFRobot platform

:octicons-plus-circle-16: This section requires the embedXcode+ edition.

![](img/Logo-064-DFRobot.png) If you plan to use the DFRobot platform:

+ Download and install the supported versions of the Arduino IDE under the `/Applications` folder, as described in section [Install the Arduino platform](../../Install/Section4/Arduino) :octicons-link-16:. Other releases don't work.

+ Launch it.

+ Define the path of the sketchbook folder in the menu **Arduino > Preferences > Sketchbook location**.

The BLuno board integrates Bluetooth 4.0 or BLE into a standard Arduino Uno board and the Wido board integrates WiFi into a standard Arduino Leonardo board.

## Install the DFRobot BLuno Board

The Bluetooth connection of the DFRobot BLuno board is managed by the dedicated [PlainProtocol](http://www.dfrobot.com.cn/download/PlainProtocol.zip) :octicons-link-external-16: library.

+ Download and install the [PlainProtocol](http://www.dfrobot.com.cn/download/PlainProtocol.zip) :octicons-link-external-16: library as a standard Arduino library.

For more details on examples,

+ Please refer to the reference pages for [simple](http://www.dfrobot.com/community/dfrobot-wireless-communication-protocol-simple-version.html) :octicons-link-external-16: and the [advanced](http://www.dfrobot.com/community/dfrobot-plain-communication-protocol-2.html) :octicons-link-external-16: usage.

On embedXcode,

+ Select the Arduino Uno board or the DFRobot BLuno board to compile and upload the sketch to the board.

## Install the DFRobot Wido Board

The WiFi connection of the DFRobot Wido board is managed by the CC3200 MCU with integrated WiFi radio..

+ Download and install the [CC3000 Library](https://github.com/Lauren-ED209/Adafruit_CC3000_Library) :octicons-link-external-16: as a standard Arduino library.

For learn more about examples,

+ Please refer to the reference pages for different [examples](http://www.dfrobot.com/wiki/index.php/Wido-WIFI_IoT_Node_SKU:DFR0321) :octicons-link-external-16:.

On embedXcode,

+ Select the Arduino Leonardo board or the DFRobot Wido board to compile and upload the sketch to the board.

:octicons-plus-circle-16: The embedXcode+ edition allows to locate the Arduino IDE in another folder.

+ Please refer to the section [Set the folder for standard IDEs](../../Install/Section3/#set-the-folder-for-standard-ides) :octicons-link-16:.

## Check the tests

The test protocol includes building and linking, uploading and running a sketch on the boards using those versions of the IDEs and plug-ins. Boards packages are versioned but not dated.

| | Platform | IDE | Package | Date | Comment
---- | ---- | ---- | ---- | ---- | ----

## Visit the official websites

![](img/Logo-064-DFRobot.png) | **DFRobot**
:---- | ----
IDE | Arduino with Boards Manager
Bluetooth library | <http://www.dfrobot.com.cn/download/PlainProtocol.zip> :octicons-link-external-16:
Website | <http://www.dfrobot.com> :octicons-link-external-16:
Wiki | <http://www.dfrobot.com/wiki/index.php/Bluno_SKU:DFR0267> :octicons-link-external-16:
Forum | <http://www.dfrobot.com/forum> :octicons-link-external-16:

