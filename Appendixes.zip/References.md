# Browse the references

I've compiled a list of references I've consulted to develop the embedXcode and emCode templates.

All brand names and trademarks mentioned in this website are the property of their respective owners. None of the brands mentioned in this website sponsor, authorise, or endorse embedXcode. Similarly, embedXcode does not sponsor, authorise, or endorse any of the brands mentioned in this website.

In case a reference is missing, please let me know so I could update the list.

Due to the very nature of internet, some links may be dead.

This website may contain links to external websites that are not provided or maintained by or in any way affiliated with it. Similarly, this website does not guarantee the accuracy, relevance, timeliness, or completeness of any information on these external websites.

## Boards and platforms

4D Systems. (17 July 2014). *PICadillo-35T - 3.5" PIC32 Embedded Display Module - Datasheet* revision 1.3. Retrieved from <http://www.4dsystems.com.au/product/PICadillo_35T> :octicons-link-external-16:

Ahlberg, F. (06 September 2014). *ESP8266 ROM Boot-Loader Utility* including esptool.py. Retrieved from <https://github.com/themadinventor/esptool> :octicons-link-external-16:

Allan A. (03 April 2015). *How the ESP8266 Community Added Arduino Support for the $5 Micro-Controller*. Retrieved from <https://makezine.com/2015/04/03/esp8266-community-added-arduino-support-5-microcontroller> :octicons-link-external-16:

Arm Limited. (2018) *Debugging the BBC micro:bit with pyOCD and GDB*. Retrieved from <https://os.mbed.com/docs/mbed-os/v5.11/tutorials/debug-microbit.html> :octicons-link-external-16:.

Banzi, M. (2015). *Getting started with Arduino*. Sebastopol, California : O'Reilly

Chang. (02 April 2015). *Let's play with the ESP8266 on the Arduino IDE*. Retrieved from <http://www.ayarafun.com/2015/04/arduino-ide-for-esp8266> :octicons-link-external-16:

chipKIT. (06 January 2016). *Arduino IDE and chipKIT core*. Retrieved from <http://chipkit.net/wiki/index.php?title=ChipKIT_core> :octicons-link-external-16:

Digilent Inc. (04 February 2015). *Mac OS X Installation*. Retrieved from <http://chipkit.net/started/install-chipkit-software/installing-mpide-mac-os> :octicons-link-external-16:

Digilent Inc. (04 February 2015). *MPIDE 1.5*. Retrieved from <http://chipkit.net/started/install-chipkit-software/installing-mpide-mac-os> :octicons-link-external-16: under Listing of previous builds and test releases or at <http://chipkit.s3.amazonaws.com/index.html> :octicons-link-external-16:

Espressif Systems. (20 March 2015). *Espressif SDK*. Retrieved from <https://espressif.com> :octicons-link-external-16: and <http://bbs.espressif.com/viewtopic.php?f=5&t=286> :octicons-link-external-16:

Fernández, B. A., & Dang, D. (2013). *Getting started with the MSP430 LaunchPad*. Newnes. eBook ISBN: 9780124116009. Paperback ISBN: 9780124115880.  <https://www.elsevier.com/books/getting-started-with-the-msp430-launchpad/fernandez/978-0-12-411588-0> :octicons-link-external-16:

Filippov, M. (22 February 2015). *Xtensa GCC Tool-Chain* from the GNU Compiler Collection. Retrieved from <https://github.com/jcmvbkbc/gcc-xtensa> :octicons-link-external-16:

GNU and ARM. (30 September 2014). *GNU Tools for ARM Embedded Processors* release 4.8-2014-q3-update. Retrieved from <https://launchpad.net/gcc-arm-embedded/4.8/4.8-2014-q3-update> :octicons-link-external-16:

Grokhotkov, I., et al. (27 March 2015). *Arduino-Compatible IDE with ESP8266 Support* version 1.6.1-esp8266-1. Retrieved from <https://github.com/esp8266/Arduino> :octicons-link-external-16: and <http://www.esp8266.com> :octicons-link-external-16:

Harbaum, Till. (18 February 2018). *ftDuino, ein fischertechnik-kompatibler Arduino - Bedienungsanleitung* [ftDuino, a fischertechnik-compatible Arduino - Manual]. Retrieved from <https://github.com/harbaum/ftduino/blob/master/manual.pdf> :octicons-link-external-16:

hiduino. (06 November 2012). *Arduino Due upload trace log*. Retrieved from <http://arduino.cc/forum/index.php/topic,128913.msg984614.html#msg984614> :octicons-link-external-16:

Intel. (30 January 2015). *Intel(r) Edison Boards and Compute Modules SDK*. Retrieved from <http://www.intel.com/support/edison/sb/CS-035180.htm> :octicons-link-external-16:

Intel. (5 March 2015). *Intel(r) IoT Developer Kit v1.0*. Retrieved from <https://software.intel.com/en-us/iot/downloads> :octicons-link-external-16:

Jenkins, M., Majenko Technologies. (17 October 2013). *Universal TFT and other display device library for the chipKIT and PIC32 based boards*. Retrieved from <https://github.com/majenkotech/TFT> :octicons-link-external-16:

Jenkins, M., Majenko Technologies. (02 February 2015). *DisplayCore*. Retrieved from <https://github.com/MajenkoLibraries/DisplayCore> :octicons-link-external-16: and <http://displaycore.org> :octicons-link-external-16:

Keith Vogel, Digilent Inc. (15 January 2015). *chipKIT Network Stack. (DEIPcK)*. Retrieved from <http://www.digilentinc.com/Data/Products/CHIPKIT-WIFIRE/deIPcK.zip> :octicons-link-external-16:

Kettenburg, E. (20 March 2013). *Digispark Add-on for Arduino 1.0.4*. Retrieved from <http://digistump.com/wiki/digispark/tutorials/connecting> :octicons-link-external-16:

Klippel C. (27 March 2015). *ESP8266 ROM Boot-Loader Utility* version 0.4.2. Retrieved from <https://github.com/igrr/esptool-ck> :octicons-link-external-16:

krzychb et al. (8 November 2015). *ESP8266 OTA Updates*. Retrieved from <https://github.com/esp8266/Arduino/blob/master/doc/ota_updates/ota_updates.md> :octicons-link-external-16:

Lady Ada. (18 September 2018) *micro:bit with Arduino*. Retrieved from <https://learn.adafruit.com/use-micro-bit-with-arduino> :octicons-link-external-16:

Maglie, C. et al. (2013, February-March). *Arduino IDE 1.5 3rd party hardware specification*. Retrieved from <http://github.com/arduino/Arduino/wiki/Arduino-IDE-1.5---3rd-party-Hardware-specification> :octicons-link-external-16:

Maglie, C. et al. (2013, February-March). *Arduino IDE 1.5: library specification*. Retrieved from <http://github.com/arduino/Arduino/wiki/Arduino-IDE-1.5:-Library-specification> :octicons-link-external-16:

Majenko Technologies. (02 February 2015). *DisplayCore &ndash; The Premium Display Framework for the chipKIT(tm) Environment*. Retrieved from <http://displaycore.org> :octicons-link-external-16: and <https://github.com/MajenkoLibraries/DisplayCore> :octicons-link-external-16:

Margolis, M. (2011, December). *Arduino cookbook* (2nd ed.). Sebastopol, CA: O'Reilly Media.

Microchip Technology Inc. (15 January 2015). *chipKIT Network and USB Libraries 2015-01-15*. Retrieved from <https://www.digilentinc.com/Agreement.cfm?DocID=DSD-0000318> :octicons-link-external-16:

Miller, P., maintained by Finneran, S. (22 June 2014). *SRecord 1.64*. Retrieved from <http://srecord.sourceforge.net> :octicons-link-external-16:

Mistry, S. (21 April 2016). *Arduino Core for Nordic Semiconductor nRF5 based boards*. Retrieved from <https://github.com/sandeepmistry/arduino-nRF5> :octicons-link-external-16:

MrEStreet. (12 April 2014). *Theme for Galileo IDE*. Retrieved from <http://communities.intel.com/docs/DOC-22572> :octicons-link-external-16:

Okano, T. (17 December 2014). *Yosemite file copier for HDK-based mbed*. Retrieved from <https://developer.mbed.org/users/okano/notebook/mbed-on-yosemite> :octicons-link-external-16:

Pasotti, A. (18 March 2013). *MSP430 LaunchPad Energia development on Linux*. Retrieved from <http://www.itopen.it/2013/03/01/msp430-energia-on-linux> :octicons-link-external-16:

Pasotti, A. (18 March 2013). *LaunchPad MSP430*. Retrieved from <http://github.com/elpaso/energia-makefile> :octicons-link-external-16:

Passault, G. (24 April 2014). *Robotis loader for OpenCM9.04 and CM900*. Retrieved from <https://github.com/Gregwar/robotis-loader> :octicons-link-external-16:

Patel, M. (12 November 2012). *Cosa, An Object-Oriented Platform for Arduino Programming*. Retrieved from <https://github.com/mikaelpatel/Cosa> :octicons-link-external-16:

RFduino. (25 August 2014). *RFduino Library version 2.1.2*. Retrieved from <http://www.rfduino.com/download-rfduino-library> :octicons-link-external-16:

Ricklon. (21 December 2011). *MPIDE 0023 mpide-0023-macosx-20111221*. Retrieved from <https://github.com/chipKIT32/chipKIT32-MAX/downloads> :octicons-link-external-16:

Robotis. (05 May 2014). *Robotis OpenCM*. Retrieved from <http://support.robotis.com/en/software/robotis_opencm.htm> :octicons-link-external-16:

Silicon Laboratories. (23 June 2015). *CP210x USB to UART Bridge VCP Drivers*. Retrieved from <https://www.silabs.com/products/development-tools/software/usb-to-uart-bridge-vcp-drivers> :octicons-link-external-16:

Silicon Laboratories. (01 October 2012). *The Serial Communications Guide for the CP210x* [PDF]. Retrieved from <https://www.silabs.com/Support%20Documents/TechnicalDocs/an197.pdf> :octicons-link-external-16:

smallbulb. (07 February 2012). *Mass erase of MSP-EXP430FR5739*. Retrieved from <http://www.smallbulb.net/2012/202-mass-erase-of-msp-exp430fr5739> :octicons-link-external-16:

Stancliff, M. (07 January 2016). *How to C in 2016*. Retrieved from <https://matt.sh/howto-c> :octicons-link-external-16:

Stoffregen, P. (06 November 2012). *Minimal makefile for Teensy 30*. Retrieved from <http://forum.pjrc.com/threads/64-Suggested-Development-Tools-for-Mac?p=263&viewfull=1#post263> :octicons-link-external-16:

Supalla, Z. (13 May 2015). *Spark is now Particle*. Retrieved from <http://blog.particle.io/2015/05/13/spark-is-now-particle> :octicons-link-external-16:

svofski. (21 July 2011). *MPLAB X project configurations for stk500v2 bootloader*. Retrieved from <http://www.chipkit.cc/forum/viewtopic.php?p=1285#p1285> :octicons-link-external-16: and <http://pastebin.com/31XXwmUV> :octicons-link-external-16:

Tensilica. (2010, March). *Diamond Standard 106Micro Controller* [PDF]. Retrieved from <http://ip.cadence.com/uploads/pdf/106Micro.pdf> :octicons-link-external-16:

Texas Instruments. (31 March 2015). *TI-RTOS: A Real-Time Operating System for TI Devices* [PDF]. Retrieved from <http://www.ti.com/lit/pdf/sprt646> :octicons-link-external-16:

Vilo, R. (18 June 2015). *Exploring RTOS with Galaxia on Energia MT*. Retrieved from <http://embeddedcomputing.weebly.com/exploring-rtos-with-galaxia.html> :octicons-link-external-16:

Vilo, R. (03 August 2015). *Galaxia Library*. Retrieved from <https://github.com/rei-vilo/GalaxiaLibrary> :octicons-link-external-16:

Welzel, K. (02 February 2015). *ARM Cross Compiling with Mac OS X*. Retrieved from <http://www.welzels.de/blog/en/arm-cross-compiling-with-mac-os-x> :octicons-link-external-16:

Wessel, R. (18 March 2012). *Energia: Arduino IDE ported to LaunchPad MSP430*. Retrieved from <https://github.com/energia/Energia> :octicons-link-external-16:

Wiring et al. (10 September 2010). Wiring Wiki. Retrieved from <http://wiki.wiring.co/wiki/Main_Page> :octicons-link-external-16:

Zankel, C., Delaney, P. (09 September 2014). *crosstool-NG* release 1.20.0 by Max Filippov. Retrieved from <https://github.com/jcmvbkbc/crosstool-NG> :octicons-link-external-16:

Zimmermann, L. (26 September 2014). *TI's SimpleLink CC3200-LaunchXL with Linux First Steps*. Retrieved from <http://azug.minpet.unibas.ch/~lukas/bricol/ti_simplelink/CC3200-LaunchXL.html#openOCD> :octicons-link-external-16:

Akkana, P. (30 May 2011). *Command-line Arduino development*. Retrieved from <http://shallowsky.com/software/arduino/arduino-cmdline.html> :octicons-link-external-16:

Justen, A. aka. Turicas. (11 October 2011). *Arduino makefile*. Retrieved from <https://github.com/turicas/arduinoMakefile/blob/master/resources.markdown> :octicons-link-external-16:

Oldfield, M. (04 June 2010). *A Makefile for Arduino Sketches*. Retrieved from <http://bleaklow.com/2010/06/04/a_makefile_for_arduino_sketches.html> :octicons-link-external-16:

## Tool-chains and frameworks

Carney, D. (2014 , March 29). *Debugging Strategies and Techniques*. Retrieved from <https://macroware.wordpress.com/2014/03/29/debugging-strategies-techniques> :octicons-link-external-16:

Administrator. (18 October 2010). *How to compile AVR-Code with Mac OSX*. Retrieved from <http://www.definefalsetrue.com/index.php/en/AVR/how-to-compile-avr-code-with-mac-osx.html> :octicons-link-external-16:

Agans, D. J. (2006). *Debugging: The nine indispensable rules for finding even the most elusive software and hardware problems*. New York: Amacom.

Bancila, M. (02 April 2013). *Ten C++11 Features Every C++ Developer Should Use*. Retrieved from <http://www.codeproject.com/Articles/570638/Ten-Cplusplus-Features-Every-Cplusplus-Developer> :octicons-link-external-16:

Beer, D. (18 July 2013). *MSPDebug Version 0.22*. Retrieved from <http://mspdebug.sourceforge.net/index.html> :octicons-link-external-16:

Bernstein, R. (November 2017). *Remake &ndash; GNU Make with comprehensible tracing and a debugger*. Retrieved from <http://bashdb.sourceforge.net/remake/remake.html/index.html> :octicons-link-external-16:

Crockett, Z., Spark et al. (12 March 2013). *Spark firmware*. Retrieved from <https://github.com/spark/firmware> :octicons-link-external-16:

Dean, B. S. (29 October 2007). *AVRDUDE, A program for download/uploading AVR microcontroller flash and eeprom* [PDF]. Retrieved from <ftp://gnumirrorspaircom/savannah/avrdude/avrdude-doc-55pdf> :octicons-link-external-16:

EmbeddedMan. (02 February 2014). *PIC32 AVRdude Boot-Loaders*. Retrieved from <http://github.com/chipKIT32/PIC32-avrdude-bootloader> :octicons-link-external-16:

Free Software Foundation, ARM, et al. (28 March 2014). *GNU ARM Embedded Toolchain*. Retrieved from <https://launchpad.net/gcc-arm-embedded> :octicons-link-external-16:

Free Software Foundation, ARM, et al. (04 April 2016). *GNU ARM Embedded Toolchain, Pre-built GNU toolchain for ARM Cortex-M and Cortex-R processors*. Retrieved from <https://developer.arm.com/open-source/gnu-toolchain/gnu-rm> :octicons-link-external-16:

Free Software Foundation, collective. (14 August 2017). *GCC Online Documentation*. Retrieved from <https://gcc.gnu.org/onlinedocs> :octicons-link-external-16:

Free Software Foundation, collective. (15 November 2011). *Using the GNU Compiler Collection*. Retrieved from <http://gcc.gnu.org/onlinedocs/gcc-4.6.2/gcc> :octicons-link-external-16:

Free Software Foundation, collective. (15 November 2011). *Make Documentation*. Retrieved from <http://www.gnu.org/software/make/manual/html_node/index.html> :octicons-link-external-16:

fwhacking. (04 November 2011). *Query on -ffunction-section and -fdata-sections options of gcc*. Retrieved from <http://stackoverflow.com/questions/4274804/query-on-ffunction-section-fdata-sections-options-of-gcc/11223700> :octicons-link-external-16:

Johannsen, J.W. (25 August 2011). *Minimal AVR project template for Xcode*. Retrieved from <http://stackoverflow.com/questions/6976500/avr-for-xcode-4> :octicons-link-external-16:

Le Mentec, F. aka. texane. (14 January 2011). *STLINK, STM32 Discovery Line Linux Programmer*. Retrieved from <https://github.com/texane/stlink> :octicons-link-external-16:

MCUdude. (11 July 2016). *MiniCore, an Arduino Core for the ATmega8, ATmega48, ATmega88, ATmega168 and ATmega328*. Retrieved from <https://github.com/MCUdude/MiniCore> :octicons-link-external-16:

Pettenò, D. E. (2009-2013). *Autotools Mythbuster*. Retrieved from <http://autotools.io> :octicons-link-external-16:

Rath, D. (5 May 2013). *Open On-Chip Debugger OpenOCD 0.7.0*. Retrieved from <http://openocd.sourceforge.net> :octicons-link-external-16:

Scompo Projects. (07 November 2012). *Debugging a Program on the Stellaris LaunchPad Board*. Retrieved from <http://scompoprojects.wordpress.com/2012/11/07/debugging-a-program-on-the-stellaris-launchpad-board> :octicons-link-external-16:

Stallman, R., Pesch, R., Shebs, S., et al. (30 August 2013). *Debugging with GDB*. Retrieved from <http://sourceware.org/gdb/current/onlinedocs/gdb> :octicons-link-external-16:

Stroustrup, B. (09 September 2015). *C++11 &ndash; The New ISO C++ Standard*. Retrieved from <http://www.stroustrup.com/C++11FAQ.html> :octicons-link-external-16:

The OpenOCD Project, collective. (17 November 2013). *OpenOCD User's Guide* [PDF]. Retrieved from <http://openocd.sourceforge.net/doc/pdf/openocd.pdf> :octicons-link-external-16:

University of Maryland, Department of Computer Science. (22 March 2009). *GDB Tutorial - A Walkthrough with Examples* [PDF]. Retrieved from <http://www.cs.umd.edu/~srhuang/teaching/cmsc212/gdb-tutorial-handout.pdf> :octicons-link-external-16:

Vanier, J. (16 August 2015). *Five Steps to Setup and Use a Debugger with the Particle Photon*. Retrieved from <https://medium.com/@jvanier/5-steps-to-setup-and-use-a-debugger-with-the-particle-photon-ad0e0fb43a34> :octicons-link-external-16:

Vogel, K., Microchip Masters 2013. (2013, August). *Debugging chipKIT(tm) Sketches with MPLAB(r) X IDE* [PDF]. Retrieved from <ftp://ftp.sqsol.co.uk/pub/docs/mplab/17007.pdf> :octicons-link-external-16:

Zimmermann, L. (08 May 2014). *TI's SimpleLink CC3200-LaunchXL with Linux First Steps*. Retrieved from <http://azug.minpet.unibas.ch/~lukas/bricol/ti_simplelink/CC3200-LaunchXL.html> :octicons-link-external-16:

## Command line and makefile

Mecklenburg, R. (February 2009). *Managing Projects with GNU Make, 3rd Edition: The Power of GNU Make for Building Anything*. Sebastopol, CA: O'Reilly Media. Listed at <http://shop.oreilly.com/product/9780596006105.do> :octicons-link-external-16: and retrieved from <https://www.oreilly.com/openbook/make3/book/index.csp> :octicons-link-external-16:

Oldfield, M. (23 June 2011). *Arduino from the command line*. Retrieved from <http://mjo.tc/atelier/2009/02/arduino-cli.html> :octicons-link-external-16: and <http://mjo.tc/atelier/2009/02/acli/arduino-mk_0.6.tar.gz> :octicons-link-external-16:

Schmidt, M. (01 April 2011). *Advanced Arduino Hacking*. Retrieved from <http://pragprog.com/magazines/2011-04/advanced-arduino-hacking> :octicons-link-external-16: and <https://github.com/maik/pragpub> :octicons-link-external-16:

Амперка aka. amperka. (01 November 2011). *A command line toolkit for working with Arduino hardware*. Retrieved from <http://arduino.cc/forum/index.php/topic,77458.0.html> :octicons-link-external-16: and <https://github.com/amperka/ino> :octicons-link-external-16:

## Apple, macOS and Xcode

Adam aka. red-glasses. (21 March 2011). *Making custom templates for Xcode 4 &ndash; March 2011*. Retrieved from <http://blog.red-glasses.com/index.php/tutorials/making-custom-templates-for-xcode-4-march-2011> :octicons-link-external-16:

Anderson, F. (18 May 2012). *Xcode 4 unleashed*. Indianapolis, Ind: Sams

borealkiss. (11 March 2011). *A minimal project template for Xcode 4*. Retrieved from <http://blog.boreal-kiss.net/2011/03/11/a-minimal-project-template-for-xcode-4/> :octicons-link-external-16: and <https://github.com/borealkiss/Minimal-Template> :octicons-link-external-16:

Gnimmel. (04 December 2011). *Master cloned by gnimmel*. Retrieved from <https://github.com/gnimmel/Xcode-for-MPIDE-Arduino> :octicons-link-external-16:

Knapen, T. (04 December 2011). *Trunk continued by Tim Knapen*. Retrieved from <https://github.com/timknapen/Arduino-With-XCode> :octicons-link-external-16:

Me and Mark Publishing. (05 December 2011). *Creating Custom Xcode 4 Project Templates*. Retrieved from <http://meandmark.com/blog/2011/12/creating-custom-xcode-4-project-templates> :octicons-link-external-16:

Netkas. (15 Octpber 2019). *Bringing back 32-bit apps to life*. Retreived from <http://netkas.org/?p=1491> :octicons-link-external-16:

Scheirman, B. (08 June 2011). *Fixing Xcode 4's Broken Code Completion*. Retrieved from <http://benscheirman.com/2011/06/fixing-xcode-4s-broken-code-completion> :octicons-link-external-16:

Sweater, R. (11 December 2016). *Touché, Touch Bar for everyone*. Retrieved from <https://red-sweater.com/touche> :octicons-link-external-16:

Vilo, R. (06 January 2011). *Thread Update: Linker Problem, Arduino Uno and Xcode*. Retrieved from <http://arduino.cc/forum/index.php/topic,49956.0.html> :octicons-link-external-16:

Vilo, R. (01 July 2011). *Arduino makefile for Xcode*. Retrieved from <https://embedxcode.weebly.com/arduino/20--arduino-makefile-for-xcode> :octicons-link-external-16:

Vilo, R. (04 December 2011). *Initial repository closed*. Retrieved from <http://github.com/rei-vilo/Xcode-for-MPIDE-Arduino> :octicons-link-external-16:

Wadman, M. (11 January 2012). *Xcode 4 external build system code completion*. Retrieved from <http://stackoverflow.com/questions/8726869/xcode-4-external-build-system-code-completion> :octicons-link-external-16:

Vilo, R. (16 January 2012). *Arduino with Xcode*. Retrieved from <https://github.com/rei-vilo/Arduino-With-XCode> :octicons-link-external-16:

Vilo, R. (19 Nov 2019). *The misadventures of a MacBook Pro 15”*. Retrieved from <https://embedxcode.com/site/Appendixes/Section11/#the-misadventures-of-a-macbook-pro-15> :octicons-link-external-16:

Vilo, R. (18 Feb 2020). *The MacBook affair, an update*. Retrieved from <https://embedxcode.com/site/Appendixes/Section11/#the-macbook-affair-an-update> :octicons-link-external-16:

Vilo, R. (27 Jun 2020). *WWDC 2020: Apple, tool or toy?*. Retrieved from <https://embedxcode.com/site/Appendixes/Section11/#wwdc-2020-apple-tool-or-toy> :octicons-link-external-16:

Vilo, R. (07 Jul 2020). *Apple support: a complete disaster*. Retrieved from <https://embedxcode.com/site/Appendixes/Section11/#apple-support-a-complete-disaster> :octicons-link-external-16:

Vilo, R. (17 Jul 2020). *How to loose a customer—even if you don't care*. Retrieved from <https://embedxcode.com/site/Appendixes/Section11/#how-to-loose-a-customereven-if-you-dont-care> :octicons-link-external-16:

Vilo, R. (14 Sep 2020). *The MacBook affair, a new update*. Retrieved from <https://embedxcode.com/site/Appendixes/Section11/#the-macbook-affair-an-update> :octicons-link-external-16:

Vilo, R. (15 Sep 2020). *Apple: “What is a CCG toolchain?”*. Retrieved from <https://embedxcode.com/site/Appendixes/Section11/#apple-what-is-a-ccg-toolchain> :octicons-link-external-16:

Vilo, R. (20 Jan 2021). *Windows-Apple: time to switch back? Six reasons to consider*. Retrieved from <https://embedxcode.com/site/Appendixes/Section11/#windows-apple-time-to-switch-back-six-reasons-to-consider> :octicons-link-external-16:

Vilo, R. (21 Feb 2021). *Apple MacBook Pro: The Keyboard Strikes Again*. Retrieved from <https://embedxcode.com/site/Appendixes/Section11/#apple-macbook-pro-the-keyboard-strikes-again> :octicons-link-external-16:

Vilo, R. (24 Mar 2021). *And now a class-action*. Retrieved from <https://embedxcode.com/site/Appendixes/Section11/#and-now-a-class-action> :octicons-link-external-16:

Vilo, R. (16 Apr 2021). *Same issue, dire consequences*. Retrieved from <https://embedxcode.com/site/Appendixes/Section11/#same-issue-dire-consequences> :octicons-link-external-16:

Vilo, R. (12 May 2021). *MTBF 4 months - TCO $2,737/year*. Retrieved from <https://embedxcode.com/site/Appendixes/Section11/#mtbf-4-months-tco-2737year> :octicons-link-external-16:

Vilo, R. (23 May 2021). *Leaving Apple for Linux*. Retrieved from <https://embedxcode.com/site/Appendixes/Section11/#leaving-apple-for-linux> :octicons-link-external-16:

Vilo, R. (20 Jul 2022). *Apple infamous $50m butterfly keyboard*. Retrieved from <https://embedxcode.com/site/Appendixes/Section11/#apple-infamous-50m-butterfly-keyboard> :octicons-link-external-16:

## Visual Studio Code


## emCode and similar projects

Atkins, R. (28 February 2009). *Using Arduino in Xcode*. Retrieved from <http://robertcarlsen.net/2009/02/28/using-arduino-in-xcode-532> :octicons-link-external-16:

fabiankr. (12 January 2012). *New IDE for Mac OS X written in Cocoa*. Retrieved from <http://arduino.cc/forum/index.php/topic,86028.0.html> :octicons-link-external-16: and <https://github.com/fabiankr/Cocoduino> :octicons-link-external-16:

Jantje. (06 November 2011). *Arduino Eclipse Plug-In*. Retrieved from <http://www.baeyens.it/eclipse> :octicons-link-external-16: and <https://github.com/jantje/arduino-eclipse-plugin> :octicons-link-external-16: and <http://sloeber.io> :fa-external-link

Jenkins, M., Majenko Technologies. (23 June 2013). *UECIDE: The Universal Embedded Computing IDE*. Retrieved from <http://uecide.org> :octicons-link-external-16: and <https://github.com/UECIDE/UECIDE> :octicons-link-external-16:

Knapen, T. (12 November 2011). *Arduino with Xcode*. Retrieved from <https://github.com/timknapen/Arduino-With-XCode> :octicons-link-external-16:

Kravets, I. (13 June 2004). *PlatformIO IDE*. Retrieved from <https://platformio.org> :octicons-link-external-16:

Leek, T., Visual Micro. (04 October 2011). *Visual Micro, Free Arduino Programming IDE for Microsoft Visual Studio*. Retrieved from <https://www.visualmicro.com> :octicons-link-external-16:

Moussa, J. (20 March 2014). *An AVR C Project Template for Xcode*. Retrieved from <https://github.com/jawher/xavr> :octicons-link-external-16:

Nick. (30 July 2011). *Programming Arduino with Xcode*. Retrieved from <http://makesomecode.com/2010/07/30/programming-arduino-with-xcode/> :octicons-link-external-16:

Peplin, C. (09 December 2011). *chipKIT Compatible Arduino-based Makefile*. Retrieved from <http://christopherpeplin.com/2011/12/chipkit-arduino-makefile> :octicons-link-external-16: and <https://github.com/peplin/arduino.mk> :octicons-link-external-16:

Vilo, R. (17 May 2021). *embedXcode*. Retrieved from <https://embeddedcomputing.weebly.com/embedxcode.html> :octicons-link-external-16:

Vilo, R. (22 January 2012). *mpideXcode &ndash; release a: initial release*. Retrieved from <https://github.com/rei-vilo/mpideXcode> :octicons-link-external-16:

Vilo, R. (14 June 2013). *embedXcode User Manual* [iBooks]. Retrieved from <https://itunes.apple.com/book/embedxcode/id667501748> :octicons-link-external-16:

## Doxygen tool and related utilities

Abhay447. (22 July 2017). *Documentation-101: Doxygen with Github pages*. Retrieved from <https://goseeky.wordpress.com/2017/07/22/documentation-101-doxygen-with-github-pages/> :octicons-link-external-16:

Anonymous. (20 August 2012). *Graphviz: Getting it to work on Mountain Lion*. Retrieved from <http://www.graphviz.org/Download_macos.php#comment-1025> :octicons-link-external-16:

Apple. (01 September 2010). *Using Doxygen to Create Xcode Documentation Sets*. Retrieved from <http://developerapplecom/library/mac/#featuredarticles/DoxygenXcode/index.html> :octicons-link-external-16:

ATT. (25 April 2012). *Graphviz 228, Graph Visualization Software*. Retrieved from <http://www.graphviz.org> :octicons-link-external-16:

ATT. (01 March 2013). *Graphviz 230, Mountain Lion compatible, Graph Visualization Software*. Retrieved from <http://www.graphviz.org> :octicons-link-external-16:

Broken Rules GmbH. (29 March 2011). *Doxygen Shortcuts in Xcode 4*. Retrieved from <http://www.brokenrul.es/blog/?p=761> :octicons-link-external-16:

Heesch, D. van. (19 May 2012). *Doxygen 181*. Retrieved from <http://doxygen.org> :octicons-link-external-16:

Heesch, D. van. (11 August 2012). *Doxygen 182*. Retrieved from <http://doxygen.org> :octicons-link-external-16:

Koch, R. (06 June 2012). *TeXShop 311*. Retrieved from <http://www.texshop.org> :octicons-link-external-16:

McCann, F. (18 March 2010). *Documenting Objective-C with Doxygen Part I*. Retrieved from <http://www.duckrowing.com/2010/03/18/documenting-objective-c-with-doxygen-part-i> :octicons-link-external-16:

McCann, F. (18 March 2010). *Documenting Objective-C with Doxygen Part II*. Retrieved from <http://www.duckrowing.com/2010/03/18/documenting-objective-c-with-doxygen-part-ii> :octicons-link-external-16:

McCann, F. (14 May 2011). *Using the Doxygen Helper in Xcode 4*. Retrieved from <http://www.duckrowing.com/2011/05/14/using-the-doxygen-helper-in-xcode-4> :octicons-link-external-16: and <http://www.duckrowing.com/wp-content/uploads/2011/05/xcode_doxygen_helper.tgz> :octicons-link-external-16:

mouviciel. (07 February 2009). *Bien documenter son code avec Doxygen et Xcode*. Retrieved from <http://mouviciel.free.fr/blog/index.php?2009/02/07/46-bien-documenter-son-code-avec-doxygen-et-xcode> :octicons-link-external-16:

premosystems. (31 January 2014). *DoxygenXCodeHelper adapted to ruby 1.9*. Retrieved from <http://github.com/premosystems/DoxygenXCodeHelper> :octicons-link-external-16:

TeX Users Group. (30 May 2013). *MacTeX-2013 Distribution*. Retrieved from <http://www.tug.org> :octicons-link-external-16: and <http://www.tug.org/twg/mactex> :octicons-link-external-16:

Waffle Software. (25 July 2012). *ThisService 3*. Retrieved from <http://wafflesoftware.net/thisservice> :octicons-link-external-16:

## Other tools and references

Alverson, D. P. (28 June 2012). *ZTerm 1.2*. Retrieved from <http://www.dalverson.com/zterm/index.html> :octicons-link-external-16:

ARM Ltd,. (09 February 2011). *Cortex-M Debug Connectors*. Retrieved from <http://infocenter.arm.com/help/topic/com.arm.doc.faqs/ka13634.html> :octicons-link-external-16:

Baeldung. (9 August 2020). *What Is the LD_PRELOAD Trick?*. Retrieved from <https://www.baeldung.com/linux/ld_preload-trick-what-is> :octicons-link-external-16:

Bjoern. (05 November 2015). *Signed Mac OS Driver for Winchiphead CH340 serial bridge*. Retrieved from <https://blog.sengotta.net/signed-mac-os-driver-for-winchiphead-ch340-serial-bridge> :octicons-link-external-16:

Carnation Software. (11 May 2014). *MacWise version 14.2*. Retrieved from <http://www.macwise.com> :octicons-link-external-16:

Davidson, T. maintained by Pattee, J. (11 December 2014). *Artistic Style 2.05 &ndash; A Free, Fast, and Small Automatic Formatter for C, C++, C++/CLI, Objective-C, C#, and Java Source Code*. Retrieved from <http://astyle.sourceforge.net> :octicons-link-external-16:

Gredeskoul, K. (31 December 2014). *How To Use Cheap Chinese Arduinos That Come With CH340G / CH341G Serial/USB Chip. (Windows & Mac OS-X)*. Retrieved from <http://kig.re/2014/12/31/how-to-use-arduino-nano-mini-pro-with-CH340G-on-mac-osx-yosemite.html> :octicons-link-external-16:

Howell, M., website by Prévost, R. (20 May 2009). *Homebrew*, original code. Retrieved from <http://mxcl.github.com/homebrew> :octicons-link-external-16: and <https://github.com/mxcl/homebrew> :octicons-link-external-16:

Joyent, Inc. (17 December 2014). *node.js 0.10.34*. Retrieved from <http://nodejs.org> :octicons-link-external-16:

Labby.co.uk. (18 January 2015). *Intel Edison Linux: Upload Arduino via Ethernet, WiFi or Network*. Retrieved from <http://labby.co.uk/wp-content/uploads/2015/01/clupload_linux.sh> :octicons-link-external-16:

Lady Ada, Adafruit. (16 March 2016). *Proper Debugging of ATSAMD21 Processors*. Retrieved from <https://learn.adafruit.com/proper-step-debugging-atsamd21-arduino-zero-m0> :octicons-link-external-16:

Liechti, C. (02 November 2011). *pyserial 2.6: Python Serial Port Extension*. Retrieved from <http://pypi.python.org/pypi/pyserial> :octicons-link-external-16:

MacPorts Project, The. (10 October 2013). *MacPorts 2.2.1*. Retrieved from <http://www.macports.org> :octicons-link-external-16:

Mangmesap, A. (03 October 2017). *Bring telnet back on macOS high Sierra*. Retrieved from <https://medium.com/ayuth/bring-telnet-back-on-macos-high-sierra-11de98de1544> :octicons-link-external-16:

Mayer, A. (27 March 2011). *goSerial 0.3.5*. Retrieved from <http://www.furrysoft.de/?page=goserial> :octicons-link-external-16:

Meier, R. (02 September 2013). *CoolTerm release 1.4.3*. Retrieved from <http://freeware.the-meiers.org> :octicons-link-external-16:

Mike's PBX Cookbook. (). *Mac's and serial TTY's* and *OS X Serial Port Apps*. Retrieved from <https://pbxbook.com/other/mac-tty.html#screen> and <https://pbxbook.com/other/mac-ser.html> :octicons-link-external-16:

Palmer, D. (23 September 2012). *Use stty instead of Python script with pySerial installed*. Retrieved from <http://embedxcodeweeblycom/1/post/2012/09/embedxcode-15-with-leonardo-supporthtml#comments> :octicons-link-external-16:

Schneider A. (21 July 2014). *What is preloading?*. Retreived from <https://blog.cryptomilk.org/2014/07/21/what-is-preloading/> :octicons-link-external-16:

Schlueter, I. Z., et al., npm Inc. (29 September 2009). *npm*. Retrieved from <https://www.npmjs.com> :octicons-link-external-16:

Segger GmbH. (21 April 2016). *J-Link / J-Trace User Guide*. Retrieved from <https://www.segger.com/jlink-gdb-server.html> :octicons-link-external-16:

Shawcroft, C., Adafruit. (12 October 2016). *Debugging the SAMD21 with GDB*. Retrieved from <https://learn.adafruit.com/debugging-the-samd21-with-gdb> :octicons-link-external-16:

St John, R. (26 November 2014). *Introducing Bloop: CLI commands for working with Intel Edison*. Retrieved from <http://rexstjohn.com/introducing-bloop-cli-commands-for-working-with-intel-edison> :octicons-link-external-16:

STMicroelectronics. (25 March 2015). *ST-LINK/V2-1 firmware upgrade*. Retrieved from <http://www.st.com/web/en/catalog/tools/PF260217> :octicons-link-external-16:

Stoffregen, P. (01 April 2013). *How to receive serial data from Teensy when it is configured as Disk+Keyboard?*. Retrieved from <https://forum.pjrc.com/threads/23472-How-to-receive-serial-data-from-Teensy-when-it-is-configured-as-Disk-Keyboard?p=30298&viewfull=1#post30298> :octicons-link-external-16:

Stoffregen, P. (02 February 2016). *HID device to COM-Port*. Retrieved from <https://forum.pjrc.com/threads/32862-HID-device-to-COM-Port?p=95224&viewfull=1#post95224> :octicons-link-external-16:

TZAPU, 'Playing with Bits and Bytes'. (24 September 2015). *CH340 CH341 serial adapters fix for El Capitan OS X*. Retrieved from <http://tzapu.com/2015/09/24/making-ch340-ch341-serial-adapters-work-under-el-capitan-os-x/> :octicons-link-external-16:

Vilo, R. (22 August 2016). *Segger J-Link Software*. Retrieved from <https://embeddedcomputing.weebly.com/segger-j-link-software.html> :octicons-link-external-16:

Vilo, R. (08 September 2017). *Segger J-Link Programmer-Debugger*. Retrieved from <https://embeddedcomputing.weebly.com/segger-j-link-programmer-debugger.html> :octicons-link-external-16:

WCH. (19 November 2015). *CH340/CH341 Driver for Mac OS X* release 1.2. Retrieved from <http://www.wch.cn/download/CH341SER_MAC_ZIP.html> :octicons-link-external-16:

Welte, H. for the original code, Schmidt, S., & Volden, T. for maintenance. (14 April 2012). *dfu-util - Device Firmware Upgrade Utilities*. Retrieved from <http://dfu-util.sourceforge.net> :octicons-link-external-16: and <https://gitorious.org/dfu-util> :octicons-link-external-16:

Wise, J. (20 October 2014). *HoRNDIS release 7*. Retrieved from <http://joshuawise.com/horndis#mavericks> :octicons-link-external-16:

## Other references

Andy of 'Stuff Andy Makes'. (05 April 2014). *embedXcode: A Better Way to Develop for Arduino on the Mac using Xcode*. Retrieved from <http://stuffandymakes.com/2014/04/05/embedxcode-a-better-way-to-develop-for-arduino-on-the-mac-using-xcode> :octicons-link-external-16:

Apple Education. (12 May 2015). *iBooks Author Starter Kit*. Retrieved from <https://itunes.apple.com/us/book/ibooks-author-starter-kit> :octicons-link-external-16:

Beckman, M. (20 September 2012). *Top 20 OS X Command-Line Secrets for Power Users*. Retrieved from <http://www.infoworld.com/article/2614879/mac-os-x/mac-os-x-top-20-os-x-command-line-secrets-for-power-users.html> :octicons-link-external-16:

James, M. of the 'Open Source Hardware Group'. (02 April 2014). *Use embedXcode to program multiple development boards with Arduino code*. (podcast). Retrieved from <http://opensourcehardwaregroup.com/oshgroup-040-use-embedxcode-to-program-multiple-development-boards-with-arduino-code> :octicons-link-external-16:

Joe at iAchieved.it. (01 March 2015). *Getting Started with Arduino and Xcode*. Retrieved from <http://dev.iachieved.it/iachievedit/getting-started-with-arduino-and-xcode> :octicons-link-external-16:

Joe at iAchieved.it. (03 March 2015). *Bluetooth Low Energy, Arduino and Xcode*. Retrieved from <http://dev.iachieved.it/iachievedit/btle-arduino-and-xcode> :octicons-link-external-16:

Kessler T. (08 July 2020). *How to manage OS X Gatekeeper from the command line*. Retreived from <https://www.cnet.com/news/how-to-manage-os-x-gatekeeper-from-the-command-line/>  :octicons-link-external-16:

Mahmud, Z. (01 June 2013). *Setting-up embedXcode for Arduino, Development in Mac using Xcode IDE for Auto-Code-Completion*. (video). Retrieved from <http://www.youtube.com/watch?v=b4lnz6ixvgU> :octicons-link-external-16:

McKesson, N. and Witwer, A., O'Reilly Media / Tools of Change. (10 February 2012). *Publishing with iBooks Author &ndash; An Introduction to Creating E-books for the iPad*. Retrieved from <http://shop.oreilly.com/product/0636920025597> :octicons-link-external-16:

Preston-Werner, T. (2013). *Semantic Versioning 2.0.0*. Retrieved from <http://semver.org/spec/v2.0.0.html> :octicons-link-external-16:

Wolfe, B. M. (04 Otober 2019). *How to open apps from unidentified developers on Mac in macOS Catalina*. Retreived from <https://www.imore.com/how-open-apps-anywhere-macos-catalina-and-mojave> :octicons-link-external-16:

## Contributions from users

James, J. (21 April 2013). *Configuration file for chipKIT uC32*.

Roberts, M. (15 January 2013). *Support for Arduino Due*.

A warm *Thank you!* to the users who tested new boards and reported them!
