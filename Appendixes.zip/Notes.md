# Read the emCode {{ version }} release notes

Starting 1st January 2022, embedXcode is renamed emCode.

emCode runs on Linux, including [Windows Linux System](https://docs.microsoft.com/en-us/windows/wsl/) :octicons-link-external-16: (WSL).

## Scope

For emCode after embedXcode,

* Release 12.1.18 updates support for Raspberry Pi RP2040 boards and Arduino mbed boards.
* Release 12.1.17 updates support for Raspberry Pi RP2040 boards.
* Release 12.1.16 updates support for Teensy boards.
* Release 12.1.15 adds support for Seeeduino Xiao nRF52840.
* Release 12.1.14 adds optional path to user's library.
* Release 12.1.13 updates support for Adadruit SAMD and Arduino AVR boards.
* Release 12.1.12 updates support for Raspberry Pi RP2040 boards.
* Release 12.1.11 adds support for Raspberry Pi W RP2040 board.
* Release 12.1.10 updates support for Raspberry Pi RP2040 boards.
* Release 12.1.9 updates support for Espressif ESP32 boards.
* Release 12.1.8 updates support for Adafruit Feather M0, M4, nRF52 and RP2040 boards.
* Release 12.1.7 updates the compiler for LaunchPad Cortex-M boards.
* Release 12.1.6 updates support for Raspberry Pi RP2040 boards.
* Release 12.1.5 updates support for Raspberry Pi RP2040 boards.
* Release 12.1.4 updates support for Raspberry Pi RP2040 boards.
* Release 12.1.3 updates support for Raspberry Pi RP2040 boards.
* Release 12.1.2 adds support for iLabs Challenger RP2040 LoRa
* Release 12.1.1 updates support for ESP32 boards.
+ Release 12.1.0 refactors the names of the variables.
