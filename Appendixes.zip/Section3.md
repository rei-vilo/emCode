# Visit the official websites

Here are the links for embedXcode, forums, frameworks and tools websites.

## embedXcode links

Here are the links for embedXcode.

![](img/Logo-064-eX-All.png) | **embedXcode** | . | . | . | .
---- | :---- | ---- | :---- | ---- | :----
![Screenshot](img/color-link-48.png)| [Website](https://embedxcode.weebly.com) :octicons-link-external-16: | ![Screenshot](img/color-download-48.png)| [Download](https://embedxcode.weebly.com/download) :octicons-link-external-16: | ![Screenshot](img/colour-contribute-48.png)| [Contribute](https://embedxcode.weebly.com/contribute) :octicons-link-external-16:
![Screenshot](img/color-question-48.png)| [Tutorial](https://embedxcode.weebly.com/tutorial.html) :octicons-link-external-16: | ![Screenshot](img/color-letter-48.png) | [Support](https://embedxcode.weebly.com/support) :octicons-link-external-16: | ![Screenshot](img/color-at-48.png) | [Mailing list](http://eepurl.com/b1q-Kb) :octicons-link-external-16:
![Screenshot](img/color-rss-48.png)| [RSS feed](https://embedxcode.weebly.com/1/feed) :octicons-link-external-16: | ![Screenshot](img/color-linkedin-48.png)| [LinkedIn](https://www.linkedin.com/in/rei-vilo-02490555) :octicons-link-external-16:

Join the conversation around embedXcode at the main portal or at one of the dedicated forums available for each platform.

. | **Platform** | **Forum**
---- | ---- | ----
![](img/Logo-064-Adafruit.png) | Adafruit | <http://forums.adafruit.com/viewtopic.php?f=25&t=26257&p=134845#p134845> :octicons-link-external-16:
![](img/Logo-064-ArduinoCC.png) | Arduino | <http://forum.arduino.cc/index.php/topic,49956.html> :octicons-link-external-16:
![](img/Logo-064-chipKIT.png) | chipKIT | <http://www.chipkit.org/forum/viewtopic.php?f=6&t=796> :octicons-link-external-16:
![](img/Logo-064-Digistump-3.png) | Digistump | <http://digistump.com/board/index.php/topic,539.0.html> :octicons-link-external-16:
![](img/Logo-064-Energia-1.png) | Energia | <http://forum.43oh.com/topic/2042-embedxcode> :octicons-link-external-16:
![](img/Logo-064-Espressif-Systems.png) | ESP8266 | <http://www.esp8266.com/viewtopic.php?f=6&t=2513> :octicons-link-external-16:
![](img/Logo-064-Intel-IDE.png) | Intel | <https://communities.intel.com/message/245077> :octicons-link-external-16:
![](img/Logo-064-Microduino.png) | Microduino | <http://www.microduino.cc/Forum%20Application/35-embedxcode-microduino-xcode> :octicons-link-external-16:
![](img/Logo-064-Spark.png) | Particle | <http://community.spark.io/t/spark-core-on-xcode-with-embedxcode/8928> :octicons-link-external-16:
![](img/Logo-064-Teensy-2.png) | Teensyduino | <http://forum.pjrc.com/threads/169-embedXcode-Teensy-3-0-on-Xcode> :octicons-link-external-16:
![](img/Logo-064-Wiring.png) | Wiring | <http://forum.wiring.co/index.php?topic=82.0> :octicons-link-external-16:

## Wiring / Arduino framework links

This following section provides the links to the website, download, wiki and forum for each platform running on the Wiring / Arduino framework.

![](img/Logo-064-ATtinyCore-alpha.png) | **ATtinyCore**
---- | ----
IDE | Arduino 1.8
Website | <http://drazzy.com/e/tiny841.shtml> :octicons-link-external-16:
Download | <https://github.com/SpenceKonde/ATTinyCore/releases> :octicons-link-external-16:
Reference | <https://github.com/SpenceKonde/ATTinyCore> :octicons-link-external-16:

![](img/Logo-064-Processing.png) | **Processing**
:---- | ----
IDE | Processing
Website | <http://www.processing.org> :octicons-link-external-16:
Download | <http://www.processing.org/download/> :octicons-link-external-16:
Wiki | <http://wiki.processing.org/w/Main_Page> :octicons-link-external-16:
Forum | <http://forum.processing.org> :octicons-link-external-16:

## Tools links

The following section lists the tools used with embedXcode.
