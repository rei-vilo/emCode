
# Change the board

The board has been defined initially during the creation of the project.

<center>![](img/282-01-420.png)</center>

However, it can be easily changed.

To change the board,

+ Select the **Project navigator**, then the project, here `embed1`.

<center>![](img/283-01-200.png)</center>

On the **Info** pane, select the project under **Project** and then the **Info** pane.

<center>![](img/283-02-420.png)</center>

+ Select **Configuration > Debug**, then the name of the project, here `embed1`.

<center>![](img/283-03-360.png)</center>

All the targets are displayed under the name of the project. In this example, the name of the project is embed1 and the active board Arduino Uno.

+ Click on the name of the board: a drop-down list shows the boards available.

<center>![](img/284-01-360.png)</center>

+ Just select one.

If the board isn't listed,

+ Check first with the **Finder** the board configuration file is already on the `Configurations` sub-folder of the project.

+ Follow the procedure Add New Boards Missing after an Update to add it to the project.

:octicons-plus-circle-16: Otherwise for embedXcode+,

+ Create a new configuration file with the procedure Add a [Add a Configuration File for a New Board](../../Chapter3/Section5) :octicons-link-16:.

:octicons-plus-circle-16: When the board is selected and a build process launched, embedXcode+ manages and updates the file `main.cpp` of the project automatically.

<center>![](img/284-02-420.png)</center>
