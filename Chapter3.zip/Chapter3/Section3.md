
# Add code and header files

To add a file,

+ Call the menu **File > New > New File...** or press ++cmd+n++.

+ Select the **macOS** option.

<center>![](img/254-01-420.png)</center>

+ Scroll down and look for the **embedXcode** or **embedXcode+** group.

<center>![](img/255-01-420.png)</center>

+ Select one of the options proposed, one per framework.

The Task Energia MT is described in the next section.

## Add a C++ code file or library

Based on the options selected during the installation, the **embedXcode** group of templates include different options.

The **C++ Code** provides a standard C++ file and optionally, adds a header file and creates a library.

<center>![](img/Logo-064-eX-All.png)</center>

The C++ code file and library is available for the Wiring / Arduino framework.

<center>![](img/256-01-420.png)</center>

The second window asks for the name and the option for a header file.

<center>![](img/256-02-420.png)</center>

+ Enter the `Name` of the C++ code file.

As a general rule and as for the standard IDEs,

+ Avoid space and special characters in the files Name field.

However, embedXcode manages the entered name and transforms it into a legal C-style name. The header file comes with the `#include` pre-processing statements.

Because the `iCloud` drive contains special characters, it is recommended not to store projects inside.

:octicons-plus-circle-16: Optionally on the embedXcode+ edition,

Provide a **Description** of the file.

<center>![](img/257-01-420.png)</center>

On all versions,

+ Optionally, check the box **Include a header file** to create an associated header file and obtain a library.

<center>![](img/257-02-420.png)</center>

+ Click **Next**.

+ Proceed to Save the new file.

## Add a class library

:octicons-plus-circle-16: This section requires the embedXcode+ edition.

The **Class Library** provides a standard C++ file and its related header file. Both are populated with a template for a class.

The template includes the constructor and various functions as public, and a variable as private.

``` c
///
/// @class      <#Description#>
///
class ClassLibrary
{

public:
///
/// @brief      Constructor
///
ClassLibrary();

///
/// @brief      Initialisation
///
void begin();

///
/// @brief      Who am I?
/// @return     Who am I? string
///
String WhoAmI();

///
/// @brief      <#Description#>
/// @param      data <#data description#>
///
void set(uint8_t data);

///
/// @brief      <#Description#>
/// @details    Read all the measures
///
void get();

///
/// @brief      <#Description#>
/// @details    Get the value of the measure
/// @return     <#return value description#>
///
uint8_t value();

private:
    uint8_t _data;
};
```

The header comes with comments for self-documentation.

For more information on self-documentation,

+ Please refer to section [Comment the code](../../Chapter6/Section3/) :octicons-link-16:.

## Add a header file

The **Header File** option is a standard file.

<center>![](img/Logo-Header.png)</center>
<center>![](img/258-01-420.png)</center>

The second window asks for the name and the optional header file.

<center>![](img/258-02-420.png)</center>

+ Enter the **Name** of the header file.

As a general rule and as for the standard IDEs,

+ Avoid space and special characters in the **Name** field.

:octicons-plus-circle-16: Optionally on the embedXcode+ edition,

+ Provide a **Description** of the header.

<center>![](img/258-03-420.png)</center>

+ Proceed to [Save the new file](../../Chapter3/Section3/#add-a-c-code-file-or-library) :octicons-link-16:.

The header file comes with the `#include` pre-processing statements for the selected platform.

Below, the header file for the Wiring / Arduino framework.

``` c
///
/// @file		newHeader.h
/// @brief		Header
/// @details	Description of the file
/// @n
/// @n @b		Project embed1
/// @n @a		Developed with [embedXcode+](https://embedxcode.weebly.com)
///
/// @author		Rei Vilo
/// @author		http://embeddedcomputing.weebly.com
///
/// @date		sept. 30, 2017 11:07
/// @version	<#version#>
///
/// @copyright	(c) Rei Vilo, 2017
/// @copyright	<#licence#>
///
/// @see		ReadMe.txt for references
///

// Core library for code-sense - IDE-based
#if defined(WIRING) // Wiring specific
#include "Wiring.h"
#elif defined(MAPLE_IDE) // Maple specific
#include "WProgram.h"
#elif defined(ROBOTIS) // Robotis specific
#include "libpandora_types.h"
#include "pandora.h"
#elif defined(MPIDE) // chipKIT specific
#include "WProgram.h"
#elif defined(DIGISPARK) // Digispark specific
#include "Arduino.h"
#elif defined(ENERGIA) // LaunchPad specific
#include "Energia.h"
#elif defined(LITTLEROBOTFRIENDS) // LittleRobotFriends specific
#include "LRF.h"
#elif defined(MICRODUINO) // Microduino specific
#include "Arduino.h"
#elif defined(TEENSYDUINO) // Teensy specific
#include "Arduino.h"
#elif defined(REDBEARLAB) // RedBearLab specific
#include "Arduino.h"
#elif defined(RFDUINO) // RFduino specific
#include "Arduino.h"
#elif defined(SPARK) // Spark specific
#include "application.h"
#elif defined(ARDUINO) // Arduino 1.0 and 1.5 specific
#include "Arduino.h"
#else // error
#error Platform not defined
#endif // end IDE

#ifndef newHeader_h
///
/// @brief	Release
///
#define newHeader_h

#endif // newHeader_h
```

## Save the new file

+ Select the folder or create a **New Folder**.

<center>![](img/260-01-420.png)</center>

The folder is where the file is going to be saved on the disk. You can access this file at that location with the Finder.

+ Define to which group the file belongs to by selecting the **Group** in the pull-down list.

<center>![](img/260-02-300.png)</center>

The group is where the file is going to be displayed on the project, on the left side.

+ On the **Targets** list, check the **Index** to ensure code-sense.

<center>![](img/260-03-300.png)</center>

+ Click on **Create**.
