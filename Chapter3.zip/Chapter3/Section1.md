
# Write the sketch

The newly created project contains various files:

```
Template/
├── .builds
├── .gitignore
├── .vscode
├── Doxyfile.dox
├── LocalLibrary
├── main.cpp
├── Makefile
├── ReadMe.md
└── Template.ino
```

+ The file `main.cpp` calls the appropriate core libraries, initialises the board, includes the sketch. The `main()` function calls the `setup()` and `loop()` functions from the sketch. Do not alter this file.

+ The `Template.ino` file is where you write the sketch, with the `setup()` and `loop()` functions and all the additional ones.

+ The files `LocalLibrary.h` and `LocalLibrary.cpp` are the header and the code for the `LocalLibrary` library. They are provided as example.

+ The folder `.vscode` contains the parameters for Visual Studio Code.

+ The folder `.builds` contains the build and link files.

+ The file `.gitignore` lists the files and folders to omit for the source control manager Git.

+ The file `Makefile` is the entry for the compilation processes. 

+ The file `ReadMe.md` is a notepad in Markdown. 

+ The file `Doxyfile.dox` lists the parameters for the documentation generator Doxygen.

The files you can play with are the `Template.ino` file for the sketch, the `LocalLibrary.h` header and `LocalLibrary.cpp` code for the `LocalLibrary` library.

A project can only have one `.ino` file, except for Energia MT on the LaunchPad MSP432 and CC3200.

If the repository is initialised for the source control, the project will contain the additional folder `.git`. 

```
Template/
├── .builds
├── .gitignore
├── .git
├── .vscode
├── Doxyfile
├── LocalLibrary
├── main.cpp
├── Makefile
├── ReadMe.md
└── Template.ino
```

## Use help links

Other files also feature help links, including the main `Makefile` and the `Doxygen` file.

  | **Main sketch template** |
  | ---- |
  | [Include core library on main sketch](https://embedxcode.com/site/Chapter7/Section1/#include-core-library-on-main-sketch) :octicons-link-16: |
  | [Declare functions prototypes on main sketch](https://embedxcode.com/site/Chapter7/Section1/#declare-functions-prototypes-on-main-sketch) :octicons-link-16: |
  | [Write specific code for multiple platforms](https://embedxcode.com/site/Chapter3/Section7/#write-specific-code-for-multiple-platforms) :octicons-link-16: |

  | **Local library template** |
  | ---- |
  | [Write comments for projects and files](https://embedxcode.com/site/Chapter6/Section3/#write-comments-for-projects-and-files) :octicons-link-16: |
  | [Include core library on main sketch](https://embedxcode.com/site/Chapter7/Section1/#include-core-library-on-main-sketch) :octicons-link-16: |
  | [Comment a function](https://embedxcode.com/site/Chapter6/Section3/#comment-a-function) :octicons-link-16: |

  | **Task template** |
  | ---- |
  | [Add a task](https://embedxcode.com/site/Chapter3/Section4/#add-a-task) :octicons-link-16:

  | **Board configuration file template** |
  | ---- |
  | [Define a new board for the Wiring / Arduino framework](https://embedxcode.com/site/Chapter3/Section5/#define-a-new-board-for-the-wiring-arduino-framework) :octicons-link-16: |
  | [Define a specific programmer for a new board](https://embedxcode.com/site/Chapter3/Section5/#define-a-specific-programmer-for-a-new-board) :octicons-link-16: |

  | **Main Makefile** |
  | ---- |
  | [Select the Application Libraries](https://embedxcode.com/site/Chapter4/Section2/#select-the-application-libraries) :octicons-link-16: |
  | [Select the User's Libraries](https://embedxcode.com/site/Chapter4/Section2/#select-the-users-libraries) :octicons-link-16: |
  | [Select the local libraries](https://embedxcode.com/site/Chapter4/Section2/#select-the-local-libraries) :octicons-link-16: |
  | [Exclude libraries](https://embedxcode.com/site/Chapter4/Section2/#exclude-libraries) :octicons-link-16: |
  | [Select scope for warning messages](https://embedxcode.com/site/Chapter4/Section7/#define-warning-statements) :octicons-link-16: |
  | [Define compiler options](https://embedxcode.com/site/Chapter4/Section1/#define-compiler-options) :octicons-link-16: |
  | [Change the path for standard IDEs](https://embedxcode.com/site/Develop/Section2/#change-the-path-for-standard-ides) :octicons-link-16: |
  | [Manage the serial console after upload](https://embedxcode.com/site/Chapter4/Section1/#manage-the-serial-console-after-upload) :octicons-link-16: |
  | [Set Teensy USB type and keyboard layout](https://embedxcode.com/site/Develop/Section2/#set-usb-type-and-keyboard-layout) :octicons-link-16: |
  | [Set Teensy CPU speed and optimisation](https://embedxcode.com/site/Develop/Section2/#set-cpu-speed-and-optimisation) :octicons-link-16: |
  | [Change the upload serial port](https://embedxcode.com/site/Chapter4/Section4/#change-the-upload-serial-port) :octicons-link-16: |
  | [Change the serial console speed](https://embedxcode.com/site/Chapter4/Section4/#change-the-serial-console-speed) :octicons-link-16: |
  | [Change the optimisation options ](https://embedxcode.com/site/Chapter4/Section4/#change-the-optimisation-options) :octicons-link-16: |

  | **Doxyfile** |
  | ---- |
  | [Select the output format](https://embedxcode.com/site/Chapter6/Section4/#select-the-output-format) :octicons-link-16: |

## Use Visual Studio Code native features

Visual Studio Code includes the following features natively: auto-completion, contextual help, colour syntaxing, code live check, source control; and with extensions: code beautifier, documentation generation, debugging. 

+ Please refer to the []() :octicons-link-external-16:.

