
# Add libraries to the project

There are four kinds of libraries:

+ The **core libraries** include all the basic functions required for development. Each platform provides its own set compatible with the Wiring and Arduino framework. One single `#include` statement in the main sketch and in the header files includes all of them.

+ The **application libraries** are optional libraries to provide additional features, like managing the specific I&sup2;C and SPI ports. They require to be explicitly mentioned with the `#include` statement on the main sketch and listed on the main `Makefile` after the `APP_LIBS_LIST` variable.

+ The **user's libraries** are developed, or downloaded and installed, by the user, and stored under the `Library` sub-folder on the sketchbook folder. They require to be explicitly mentioned with the `#include` statement on the main sketch and listed on the main `Makefile` after the `USER_LIBS_LIST` variable.

+ The **local libraries** are part of the project and located on the same folder as the main sketch. They require to be explicitly mentioned by the `#include` statement on the main sketch. By default, all the local libraries are included.

:octicons-plus-circle-16: The embedXcode+ edition lists all the application and user's libraries for the selected platform on the main `Makefile`. It also allows to create folders for local libraries and select them.

:octicons-plus-circle-16: The embedXcode+ edition introduces a variant for the local libraries, the pre-compiled libraries.

+ Instead of using the source code, the **pre-compiled libraries** are already built and ready to use. Just like the local libraries, they are part of the project and located on the same folder as the main sketch, they require to be explicitly mentioned by the `#include` statement on the main sketch and they are all included by default.

## Where to find the libraries in embedXcode and in the finder

Each kind of library is located in a specific group or sub-group in embedXcode and in a specific folder in the finder.

There are slight different structures for embedXcode standard edition and embedXcode+ edition.

### Identify the different structures

The embedXcode standard edition has a separate **Sketchbook** group for the users's libraries, while the **Resources** group lists all the other core and application libraries.

The **Resources** group of the embedXcode+ edition includes all the core, application and user's libraries.

<center>![](img/245-01-420.png)
*embedXcode and embedXcode+*</center>
### Locate the Core and Application Libraries

The core and application libraries are located under the **Resources** group in embedXcode and protected inside the IDE applications on the `/Applications` folder.

<center>![](img/246-01-420.png)</center>
<center>*Core and application libraries in embedXcode and in the Finder*</center>

For the boards managed by the Arduino 1.6.5 and later, those libraries are also located under the `~/Library/Arduino15/packages` folder.

Same logic applies for Energia 1.6.10E18 with libraries located under the `~/Library/Energia15/packages` folder.

The exact path to the libraries includes a release number, listed in the `About.mk` file.

Once the debugging session is terminated, some boards require a specific procedure to restore the initial mode.

For more information,

+ Please refer to the section [Check and update the boards reference list](../../Chapter4/Section2/#check-and-update-the-boards-reference-list) :octicons-link-16:.

### Locate the user's libraries

On embedXcode standard edition, the user's libraries are listed below the **Sketchbook** group in embedXcode, and stored on the `Libraries` or `libraries` sub-folder under the sketchbook folder.

<center>![](img/247-01-420.png)</center>
<center>*User's library in embedXcode and in the Finder*</center>

:octicons-plus-circle-16: On the embedXcode+ edition edition, the user's libraries are listed below the **Sketchbook** sub-group of the **Resources** group in embedXcode, and stored on the `Libraries` or `libraries` sub-folder under the sketchbook folder.

<center>![](img/247-02-420.png)</center>
<center>*User's library in embedXcode+ and in the Finder*</center>

The users' libraries should comply with the [Arduino IDE 1.5: Library specification](https://github.com/arduino/Arduino/wiki/Arduino-IDE-1.5:-Library-specification) :octicons-link-external-16:.

### Locate the local libraries

The local libraries are listed on the main group in embedXcode, `embed1` in the example, and stored on the same folder where the main sketch in located, `embed1/embed1` in the example.

<center>![](img/248-01-420.png)</center>
<center>*Local libraries in embedXcode and in the Finder*</center>

:octicons-plus-circle-16: The embedXcode+ edition allows to have dedicated folders for the local libraries.

:octicons-plus-circle-16: The embedXcode+ edition allows to include and manage pre-compiled libraries. For more information on pre-compiled libraries,

+ Please refer to [Locate the pre-compiled libraries](../../Chapter3/Section2/#locate-the-pre-compiled-libraries) :octicons-link-16:.

The local libraries are then listed on the dedicated **LocalLibrary** sub-group under the main **embed1** group in embedXcode, and stored on the `LocalLibrary` sub-folder under the folder where the main sketch in located, `embed1/embed1/LocalLibrary` in the example.

<center>![](img/248-02-420.png)</center>
<center>*Local libraries in embedXcode and in the Finder for embedXcode+*</center>

Using a library requires adding an `#include` statement on the main sketch or the header file and listing it on the main `Makefile`.

### Locate the pre-compiled libraries

:octicons-plus-circle-16: This section requires the embedXcode+ edition.

The embedXcode+ edition allows to include and manage pre-compiled libraries.

To do so,

+ Place the pre-compiled libraries with extension `.a`, their header files with extension `.h`, and additional file `.board`, into the main folder of the project or within a sub-folder of the project.

<center>![](img/249-01-420.png)</center>
<center>*Pre-compiled local libraries in embedXcode and in the Finder for embedXcode+*</center>

In the example shown above, the `LocalLibrary` sub-folder contains: `LocalLibrary.a` is the pre-compiled library, `LocalLibrary.h` the corresponding header file and `arduino_zero_native.board` for the board the library has been compiled against.

+ Check no code file with extension `.cpp` or other is on the same location.

+ Ensure the pre-compiled library is consistent with the target. To do so, check the file `.board`. refers to the same board as the current target.

The embedXcode+ edition checks the consistency of the pre-compiled libraries with the current board based on the file `.board`, and includes the pre-compiled libraries with extension `.a` during linking.

!!! warning
    A pre-compiled library can't be debugged, as the code source isn't provided.

For more information on how to generate pre-compiled libraries,

+ Please refer to [Generate the pre-compiled libraries](../../Chapter4/Section3/#generate-pre-compiled-libraries) :octicons-link-16:.

## Include libraries to the main sketch and header files

Just like any other IDE, including a library to the project is done by specifying an `#include` statement on the main sketch.

Additionally, the library needs to be mentioned on the main `Makefile` to be compiled.

=== "Core libraries"

    All the **core libraries** are included for compilation using one single `#include` statement on the main sketch. The same `#include` statement is also required on the header files.

    For Arduino, the core library statement is

    ``` c
    // Core library for code-sense - IDE-based
    #include "Arduino.h"
    ```

=== "Application libraries"

    The **application libraries** require to be explicitly mentioned with the `#include` statement on the main sketch and listed on the main `Makefile`.

    The include statement for the `Wire` or I&sup2;C library is

    ``` c
    // Core library for code-sense - IDE-based
    #include <Wire.h>
    ```

=== "User's libraries"

    The **user's libraries** require to be explicitly mentioned with the `#include` statement on the main sketch and listed on the main `Makefile`.

    The include statement for a user's library is

    ``` c
    // Include application, user and local libraries
    #include "myLibrary.h"
    ```

=== "Local libraries"

    Finally, the **local libraries** require to be explicitly mentioned by the `#include` statement on the main sketch. By default, all the local libraries are included.

    The include statement for a local library is

    ``` c
    // Include application, user and local libraries
    #include "LocalLibrary.h"
    ```

## List the libraries on the main Makefile

By default, the main `Makefile` looks like...

``` CMake
# List standard IDE libraries here
#
APP_LIBS_LIST = 0

# List user's libraries here
#
USER_LIBS_LIST = 0

# List local libraries here
#
LOCAL_LIBS_LIST =
```

...with the following options:

+ All the core libraries are included.

+ No application library is included.

+ No user's library is included.

+ All the local libraries are included.

If a library has been included in the main sketch or in a header file, it needs to be listed on the main `Makefile` to be compiled. This is a standard procedure

:octicons-plus-circle-16: With the embedXcode+ edition, the makefile comes populated with the list of the core, application and user's libraries. This list is added during the preparation and for the selected platform of the project.

An example of the list of the application libraries for Arduino.

``` CMake
# List standard IDE libraries here
# !!! Help: https://bit.ly/2hYLBDC
# default = 0 = none
#
# ARDUINO = Bridge EEPROM Esplora Ethernet
#   Firmata GSM LiquidCrystal SD Servo
#   SoftwareSerial SPI Stepper WiFi Wire
#
APP_LIBS_LIST = Wire
```

### List the core libraries on the main Makefile

All the core libraries are included for compilation by default, so there no need to list them on the main `Makefile`.

### List the application libraries on the main Makefile

The folders of the application libraries require to be listed on the main `Makefile` after the `APP_LIBS_LIST` variable.

+ In case of one library, mention the name of the folder of the library.

``` CMake
# List standard IDE libraries here
#
APP_LIBS_LIST = Wire
```

In the example above, the `APP_LIBS_LIST` variable lists the `Wire` or I&sup2;C library.

+ In case of multiple libraries, separate the names of the folders of the libraries with a space.

``` CMake
# List standard IDE libraries here
#
APP_LIBS_LIST = Wire SPI
```

In the example above, the `APP_LIBS_LIST` variable lists the `Wire` or I&sup2;C and `SPI` libraries.

+ To use all the libraries, leave the line empty after the `APP_LIBS_LIST` variable.

``` CMake
# List standard IDE libraries here
#
APP_LIBS_LIST =
```

### List the user's libraries on the main Makefile

The folders of the user's libraries require to be listed on the main `Makefile` after the `USER_LIBS_LIST` variable.

+ In case of one library, mention the name of the folder of the library.

``` CMake
# List user's libraries here
# !!! Help: https://bit.ly/2AEscDx
# default = 0 = none
#
USER_LIBS_LIST = myLibrary
```

In the example above, the `USER_LIBS_LIST` variable list a user's library, here  `myLibrary `.

+ In case of multiple libraries, separate the names of the folders of the libraries with a space.

``` CMake
# List user's libraries here
#
USER_LIBS_LIST = myFirstLibrary mySecondLibrary
```

In the example above, the `APP_LIBS_LIST` variable lists the `myFirstLibrary` and `mySecondLibrary` libraries.

+ To use all the libraries, leave the line empty after the `USER_LIBS_LIST` variable.

``` CMake
# List user's libraries here
#
USER_LIBS_LIST =
```

### List the local libraries on the main Makefile

:octicons-plus-circle-16: This section requires embedXcode+

By default, all the local libraries are taken into account, and all sub-folders of the libraries are take into account. So there is no need to list folders of the local libraries on the main `Makefile` after the `LOCAL_LIBS_LIST` variable.

+ In case of one library, mention the name of the folder of the library.

``` CMake
# List local libraries here
#
LOCAL_LIBS_LIST = LibraryOption1
```

In the example above, the `LOCAL_LIBS_LIST` variable list a local library, here  `LibraryOption1`. If a variant `LibraryOption2` exists, it will not be taken into account.

+ In case of multiple libraries, separate the names of the folders of the libraries with a space.

``` CMake
# List local libraries here
#
USER_LIBS_LIST = myFirstLibrary mySecondLibrary
```

In the example above, the `APP_LIBS_LIST` variable lists the `myFirstLibrary` and `mySecondLibrary` local libraries. All other local libraries are ignored.

+ All the local libraries are included by default. Leave the line empty after the `LOCAL_LIBS_LIST` variable.

``` CMake
# List local libraries here
#
LOCAL_LIBS_LIST =
```

The empty `LOCAL_LIBS_LIST` variable takes all the local libraries.

For libraries with multiple levels below the folder of the project,

+ Use any of the following definitions for `LOCAL_LIBS_LIST`.

``` CMake
# List local libraries here
# !!! Help: https://bit.ly/2juEP91
# default = empty = all
#
LOCAL_LIBS_LIST =
LOCAL_LIBS_LIST = Library
LOCAL_LIBS_LIST = Library/LocalLibrary
```
On the following example, a first sub-folder `Library` of the project contains two second-level sub-folders: `LocalLibrary1` and `LocalLibrary2`.

<center>![](img/249-02-420.png)</center>
<center>*Local libraries in embedXcode and in the Finder*</center>

+ Specify `LOCAL_LIBS_LIST =` to take all local libraries.

+ Specify `LOCAL_LIBS_LIST = Library` to take all libraries inside the `Library` folder, here `LocalLibrary1` and `LocalLibrary2`.

+ Specify `LOCAL_LIBS_LIST = Library/LocalLibrary1` to take  `LocalLibrary1` only inside the `Library` folder.

By default, all the sub-folders of a local library are taken into account, including for example the sub-folders `extras` and `examples`.

If those sub-folders contain code not related to the project,

+ Either delete the sub-folders not related to the project,

+ Or specify `LOCAL_LIBS_LIST = Library/src` to take the `src` sub-folder only from the `Library` folder.

For more information on local libraries,

+ Please refer to [Create folders for local libraries](../../Chapter3/Section2/#create-folders-for-local-libraries) :octicons-link-16: and [Select the local libraries](../../Chapter4/Section2/#select-the-local-libraries) :octicons-link-16:.

## Check the content of the user's libraries

Some libraries include additional folders and files which are not related with the Wiring / Arduino project and may interfere with the compilation.

For example, the [ArduinoJSON library](https://github.com/bblanchon/ArduinoJson) :octicons-link-external-16: contains the usual folders `src` and `examples`, which are consistent with the [Arduino IDE 1.5 Library Specification](https://github.com/arduino/Arduino/wiki/Arduino-IDE-1.5:-Library-specification) :octicons-link-external-16:.

However, the same library also contains the additional folders `fuzzing`, `scripts`, `third-party` and `test`, which interferes with the normal compilation.

<center>![](img/249-02-640.png)</center>

As a solution,

+ Zip those folders.

+ Remove them.

+ Create a new sub-folder `extras` and move `fuzzing`, `scripts`, `third-party` and `test` folders inside.

<center>![](img/249-03-640.png)</center>

## Create folders for local libraries

:octicons-plus-circle-16: The embedXcode+ edition allows to create folders for local libraries and select them.

The `LOCAL_LIBS_LIST` variable lists the `LocalLibrary` library.

``` CMake
# List local libraries here
# !!! Help: https://bit.ly/2juEP91
# default = empty = all
#
LOCAL_LIBS_LIST = LocalLibrary
```

In case of multiple libraries, separate the names of the folders of the libraries with a space.

In the following example, the application `Wire` library, the user's library `myLibrary` and all the local libraries are selected.

``` CMake
# List standard IDE libraries here
#
APP_LIBS_LIST = Wire

# List user's libraries here
#
USER_LIBS_LIST = myLibrary

# List local libraries here
#
LOCAL_LIBS_LIST =
```

For more information about how the libraries are managed during compilation,

+ Please refer to the section [Manage the libraries for compilation](../../Chapter4/Section2/#manage-the-libraries-for-compilation) :octicons-link-16: and [Select the local libraries](../../Chapter4/Section2/#select-the-local-libraries) :octicons-link-16:.
