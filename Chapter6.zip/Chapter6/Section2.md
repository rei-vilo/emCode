# Improve the style of the code

:octicons-plus-circle-16: This section requires the embedXcode+ edition.

The first step consists on formatting the code to improve its readability.

The target **Style** indents, formats and improves the presentation of the code. It is based on one single set of rules used for all the files to provide a consistent presentation across the project.

The parameters are defined in the `style.conf` file, located under `Utilities`. The options are grouped into 8 sections, including bracket style, tabulations, brackets, indentation, padding, formatting and others.

The style option defines how brackets are managed. Here, the `gnu` style is selected.

```
style=gnu
```

For more information about the options,

+ Please refer to the [Documentation](http://astyle.sourceforge.net/astyle.html) :octicons-link-external-16: page on the Artistic Style website.

To launch the automatic style editor,

+ Select the **Style** target.

<center>![](img/432-01-320.png)</center>

+ Call the menu **Product > Build** or press ++cmd+b++ or click on the **Run** icon.

The files with the `.h`, `.c`, `.hpp`, `.cpp` and `.ino` extensions located in the project folder and sub-folders are updated.

Below, an example of code before and after running the **Style** target.

<center>![](img/432-02-420.png)<br>*Before*</center>
<center>![](img/432-03-420.png)<br>*After*</center>
