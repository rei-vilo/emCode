# Use the documentation

:octicons-plus-circle-16: This section requires the embedXcode+ edition.

Once generated and if the `.docset` option has been selected, the documentation is now fully integrated into Xcode and available through multiple ways:

+ directly from the code thanks to **Quick help**,

+ or using the **Documentation and API Reference** window.

## Use the Quick Help

Documentation is available directly from the code thanks to Quick help.

+ Select a function or place the cursor on a function, here `blink`.
<center>![](img/441-01-240.png)</center>

+ Press ++alt++ while the cursor is hovering the function.

The cursor turns into an interrogation mark:

<center>![](img/441-02-240.png)</center>

+ While pressing ++alt++, click on the name of the function `blink`.

A contextual help pops-up.

<center>![](img/441-04-420.png)</center>

If you click on the blue link `LocalLibrary.h` in the help balloon, **Xcode** opens the library at the definition of the function:

<center>![](img/441-03-420.png)</center>

When the cursor selects a function, the **Quick Help** pane on the right provides all the information available for the function, here `blink`.

<center>![](img/444-01-260.png)</center>

+ Click on the blue link `LocalLibrary.h` in the quick help pane. Xcode opens the library at the definition of the function:

<center>![](img/444-02-420.png)</center>

## Use the documentation and API reference

The documentation is also available on the Documentation and API Reference.

+ Call the menu **Help > Documentation and API Reference**.

The Documentation window opens.

On the column on the left, select the documentation, here embed1 Reference Manual and navigates using the sections and the hyperlinks.

<center>![](img/445-01-420.png)</center>

