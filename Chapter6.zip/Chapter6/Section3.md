# Comment the code

:octicons-plus-circle-16: This section requires the embedXcode+ edition.

The second step consists on adding specific comments with defined keywords right into the code.

The comments for self-documentation start with `///` instead of the standard `//` and include keywords with a `@` prefix.

``` c
///
/// @mainpage	embed1
///
/// @details	Description of the project
/// @n
```

This means that standard comments starting with the standard `//` aren't included in the documentation.

Doxygen includes many more options.

+ Please refer to its [documentation](http://doxygen.org) :octicons-link-external-16:.

### Comment a function

Use the Doxygen Helper to speed up and ease the writing of comments for the functions.

+ Just select the code of a function.

<center>![](img/433-01-420.png)</center>

+ Either press ++cmd+shift+d++,

+ Or call the menu **Xcode > Services > Doxygenise**.

<center>![](img/433-02-420.png)</center>

The helper generates a template for the comment lines.

<center>![](img/433-03-420.png)</center>

+ Use the **tab** key to replace the light-blue fields with the comments.

In this example, the comments include the `@brief` description of the function, list all the `@parameters` as well as the @`returned` value.

``` c
///
/// @brief      Blink a LED
/// @details	LED attached to pin is turned on then off
/// @note       Total cycle duration = ms
/// @param      pin pin to which the LED is attached
/// @param      times number of times
/// @param      ms cycle duration in ms
/// @param		level level for HIGH, default=true=positive logic, false=negative logic
///
void blink(uint8_t pin, uint8_t times, uint16_t ms, bool level = true);
```

## Write comments for projects and files

The templates come with comments, most of them populated. Here are the keywords I use the most.

For the main page with details about the author, copyright, licence, references and links.

<center>![](img/435-01-420.png)</center>

Note the `@mainpage` keyword.

For a file with details about the author, copyright, licence, references and links.

<center>![](img/434-02-420.png)</center>

By default, the projects and files templates include self-documenting headers.

+ For a function with details for parameters.
<center>![](img/435-03-360.png)</center>

A result is documented with the keyword @return.

## Use snippets for comments

The snippets for the documentation are under the User list.

<center>![](img/436-01-420.png)</center>

The snippet for different details provides the keywords for note, warning, bug, to-do, test, ...

<center>![](img/436-02-240.png)</center>

The snippet for code allows to include an example of code.

<center>![](img/436-03-240.png)</center>

Doxygen includes many more options. Please refer to its [documentation](http://doxygen.org) :octicons-link-external-16:.
