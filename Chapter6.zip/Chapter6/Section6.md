# Distribute the project

:octicons-plus-circle-16: This section requires the embedXcode+ edition.

Once the code has been formatted and the documentation generated, the project can be distributed.

To distribute the project,

+ Select the **Distribute** target.

<center>![](img/445-01-360.png)</center>

+ Press **Run**.

A new folder `Distribution` is created and contains the documentation if a PDF file if available, and two sub-folders `embed1` and `Builds`. The name of the folder `Distribution` mentions the date and the time, `2017-10-12 11-14-50` here.

The sub-folder `embed1` is named after the project. It contains all the headers `.h`, code files `.cpp` and the main sketch `.pde`, `.ino` or `.cpp`.

The sub-folder `Builds` contains the compiled files `.elf`, `.hex` or `.bin`, and a `.board` file with the name of the board the project was compiled against, `MSP-EXP432P401R` in this example.

<center>![](img/446-01-320.png)</center>

The **All Messages** window provides the list of the files copied to the `Distribution` folder.

<center>![](img/446-02-420.png)</center>

In case the project contains pre-compiled libraries, the `Distribution` folder includes the header file and the pre-compiled libraries, but excludes the renamed code source files, here `LocalLibrary.h` and `LocalLibrary.a` but not `LocalLibrary._cpp`.

<center>![](img/446-03-320.png)</center>

The **All Messages** window provides the list of the files copied to the `Distribution` folder.

<center>![](img/446-04-420.png)</center>

+ Remember the pre-compiled libraries are only valid for the board or MCU they have been compiled against.

**embedXcode** checks the validity based on the `.board` file, in this example `arduino_zero_native`. Do not use them with another board or MCU.

For more information on how to generate pre-compiled libraries,

+ Please refer to [Generate the pre-compiled libraries](../../Chapter4/Section3/#generate-pre-compiled-libraries) :octicons-link-16:.
