# Select the target

:octicons-plus-circle-16: This chapter requires the embedXcode+ edition.

Code readability and documentation are key when publishing a finalised project. The embedXcode+ edition includes the tools to make this task easier.

Target... | Formats | Documents | Shares
---- | :----: | :----: | :----:
Style | :fontawesome-solid-check: | |
Document | | :fontawesome-solid-check: |
Distribute | | | :fontawesome-solid-check:
Share | :fontawesome-solid-check: | :fontawesome-solid-check: | :fontawesome-solid-check:

The process includes three steps:

+ Select the **Style** target to improve the presentation of the code.

Learn more about the format options at [Improve the style of the code](../../Chapter6/Section2/) :octicons-link-16:.

+ Select the **Document** target to build the documentation.

This step includes two procedures: [Comment the code](../../Chapter6/Section3/#comment-the-code) :octicons-link-16: and [Build the documentation](../../Chapter6/Section4) :octicons-link-16:. Additionally, learn how to [Use the documentation](../../Chapter6/Section5) :octicons-link-16:.

+ Select the **Distribute** target to prepare a folder for distribution.

Learn more at [Distribute the project](../../Chapter6/Section6/) :octicons-link-16:.

Finally,

+ Select the **Share** target to perform all the three steps at once.

