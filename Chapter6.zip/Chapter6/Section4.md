# Build the documentation

:octicons-plus-circle-16: This section requires the embedXcode+ edition.

Once the code has been formatted and commented, it's time now to build the documentation. By default, embedXcode generates the documentation under four different formats:

<center>![](img/438-01-360.png)</center>

+ A LateX `.tex` document;

+ A PDF document `.pdf` file, based on the LaTeX document. The LateX and PDF options are linked;

+ An HTML-formatted documentation, with `index.html` as entry;

+ A help file for Xcode called documentation set or `.docset`. The documentation set is incorporated in the Xcode help library. This option requires the HTML-formatted documentation.

## Select the output format

The parameters for the documentation outputs are defined in the doxyfile file, located under Utilities.

<center>![](img/439-02-240.png)</center>

Here are the main settings for selecting the outputs:

```
GENERATE_LATEX         = YES
GENERATE_HTML          = YES
GENERATE_DOCSET        = YES
```

+ `GENERATE_LATEX` prepares the LaTeX `.tex` and PDF document `.pdf` files;

+ `GENERATE_HTML` prepares an HTML-formatted documentation;

+ `GENERATE_DOCSET` creates the documentation set .docset file and incorporates it in the Xcode help library. This option requires `GENERATE_HTML`.

If the local libraries are placed within folders and you want to include them in the documentation,

Check the `RECURSIVE` option is set to `YES`.

```
RECURSIVE              = YES
```

There are many more options available.

For more information about the Doxygen options,

+ Please refer to the [Doxygen Manual](http://www.stack.nl/~dimitri/doxygen/manual/index.html) :octicons-link-external-16:.

## Build the documentation

To build the documentation,

+ Select the **Document** target and

<center>![](img/440-01-320.png)</center>

+ Press **Run**.

Doxygen builds the documentation and issues warnings for undocumented portion of your code.

<center>![](img/440-02-420.png)</center>

The `HMTL` website and the `.docset` files are located on the `html` sub-folder of the build folder, while the LaTeX and PDF files are under the `latex` sub-folder of the build folder. The `xml` sub-folder of the build folder contains the index.

<center>![](img/440-03-240.png)</center>

The documentation is packed in a specific file called `.docset` for documentation set, and added into Xcode documentation and API reference.

<center>![](img/440-04-420.png)</center>

A PDF file is also automatically generated and copied to the project folder as `embed1 - Reference Manual.pdf`, if `embed1` is the name of the project.

Similarly, the link to the `HMTL` website is copied to the project folder as `embed1 - Reference Manual.url`, if `embed1` is the name of the project.

<center>![](img/441-01-320.png)</center>

As an option, the PDF file can be created manually.

To convert the TEX file into a PDF file, a LaTeX-to-PDF converter is needed.

+ Install a LaTeX-to-PDF converter, like the recommended **TeXShop**.

+ Follow the procedures [Install optional self-documentation tools](../../Install/Section5/#install-optional-self-documentation-tools) :octicons-link-16: and [Install TeXShop](../../Install/Section5/#install-texshop) :octicons-link-16:.

<center>![](img/441-02-220.png)</center>

To create the PDF file manually,

+ Double-click on a `.tex` file to launch **TexShop** or the installed LaTeX-to-PDF converter.
