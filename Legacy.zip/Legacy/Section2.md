<style>
.md-typeset h1, .md-typeset h2, .md-typeset h3 { color: #757575; }
</style>

# Install embedXcode Legacy 9

:octicons-plus-circle-16: This section requires the embedXcode+ edition.

## Check the discontinued platforms

Release 10.0 removes the legacy boards listed below for a more compact installation package.

Platform | Boards | Comment
---- | ---- | ----
![](img/Logo-064-LightBlue.png) Punch Through Design | Bean and Bean+ | On hold
![](img/Logo-064-RedBearLab-no-brand.png) RedBear | All | On hold

## Download embedXcode Legacy 9

For legacy systems running Xcode 9 on macOS 10.12 *Sierra* or 10.13 *High Sierra*,

+ Please select the **embedXcode Legacy 9** option. It corresponds to embedXcode release 9.6.8.

<center>![](img/Legacy9.png)</center>

!!! danger
    embedXcode Legacy 9 is deprecated and no longer supported.

As an alternative, the tools can be installed manually.

+ Please refer to [Use discontinued Wiring / Arduino frameworks](../../Legacy/Section4) :octicons-link-16:.

## Install embedXcode Legacy 9

+ Double-click on the **embedXcode** package icon to launch the installation.

<center>![](img/153-01-100.png)</center>

Mac OS X requires the installation packages to be signed.

Because the embedXcode installation package is not signed, the following message may appear.

<center>![](img/153-02-360.png)</center>

Depending on the installed version of Mac OS X or macOS,

+ Open the security parameters defined by calling the menu **:fontawesome-brands-apple: > Preferences > Security & Privacy > General**.

+ Either select **Allow apps downloaded from anywhere**.

<center>![](img/153-03-300.png)</center>

+ Or click on **Open Anyway**.

<center>![](img/153-04-420.png)</center>

As an alternative,

+ Press ++ctrl+left-button++ on the embedXcode package icon to display the contextual menu and select **Open**.

<center>![](img/154-01-260.png)</center>

A window prompts for confirmation.

<center>![](img/154-02-360.png)</center>

+ Answer **Open** to proceed.

The installation starts and displays the welcome screen.

<center>![](img/154-03-400.png)</center>

+ Click on **Continue** to proceed.

The licence is displayed.

<center>![](img/155-01-400.png)</center>

+ Click on **Continue**.

<center>![](img/155-02-360.png)</center>

+ Click on **Agree** to proceed.

<center>![](img/155-03-400.png)</center>

An additional window may ask for the destination.

<center>![](img/156-01-400.png)</center>

+ Select Install for me only to enable the Continue button.

+ Click on **Continue** to proceed.

Next window asks for confirmation of the installation.

<center>![](img/156-03-400.png)</center>

+ Click on **Install** to proceed.

A window prompts for your name and password.

<center>![](img/157-01-360.png)</center>

+ Enter both and click on **Install Software**.

The installation goes on.

<center>![](img/157-02-400.png)</center>

If the mbed framework has been selected, an additional dialogue box asks for the folder where the mbed projects are saved.

<center>![](img/157-03-420.png)</center>

Similar dialogue boxes ask for the folders where the Particle projects and Yocto projects are saved.

+ Select an existing folder or create a new one with **New Folder**.

+ Click **Choose**.

The installation has been successful.

<center>![](img/158-01-400.png)</center>

+ Click on **Close** to finalise.

A final window asks to delete the installation package.

<center>![](img/158-02-400.png)</center>

+ Click on **Keep** to keep the installation package.

+ Click on **Move to Trash** to delete the installation package.

## Launch the installation manually

In case the automatic installation fails,

+ Open a **Terminal** window.

+ Launch the command

``` bash
sudo installer -pkg embedXcode-231.pkg -target /
```

## Install OpenOCD with MacPorts

The installation of some utilities like **OpenOCD** can be done using either Homebrew or MacPorts.

However, **Homebrew** is recommended over **MacPorts**. Similarly, use only one among those tools.

To install **OpenOCD** with **MacPorts**,

<center>![](img/081-01-260.png)</center>

+ Download and install [MacPorts](http://www.macports.org/install.php) :octicons-link-external-16:.

+ Open a **Terminal** window.

+ Launch the following command to install **libusb**.

``` bash
$ sudo port install libusb
```

+ Launch the following command to install **OpenOCD**.

``` bash
$ sudo port install openocd +ti
```

