<style>
.md-typeset h1, .md-typeset h2, .md-typeset h3 { color: #757575; }
</style>

# Check the obsolescence notice

Because hardware and software evolve, some boards, tools and features are becoming obsolete. As a consequence, development and support are either put on hold or discontinued.

+ For **on hold boards**, embedXcode features the boards and provides limited technical support. Development may resume when the manufacturer updates the hardware or software, or when embedXcode users renew their interest on those boards.

+ For **discontinued boards**, usually declared end-of-life by the manufacturer, embedXcode may still feature the boards but development is halted and technical support is no longer available.

Usually, a board is first put on hold for a while before being discontinued.

<center>![](img/077-01-640.png)</center>

Please refer to the other sections of this chapter for additional information.

## Check the last embedXcode versions

The tables below provide the last version of embedXcode supporting the platform before it was declared on hold or discontinued.

For example, the last version of embedXcode supporting the ArduCAM platform is version 8.4.2. The platform was discontinued with embedXcode release 9.

### Check the on hold platforms

| | Platform | On Hold After | | Platform | On Hold After
---- | ---- | ---- | ---- | ---- | ----
![](img/Logo-064-Intel-IDE.png) | Intel Curie | 9.6.8 | ![](img/Logo-064-Microsoft.png) | Microsoft IoT DevKit | 11.4.0
![](img/Logo-064-Moteino.png) | Moteino | 11.4.0 | | |

:octicons-plus-circle-16: To use a board running on the Wiring / Arduino framework but listed as on hold,

+ Select the template **embedXcode+ All**.

### Check the discontinued platforms

| | Platform | Discontinued After | | Platform | Discontinued After
---- | ---- | ---- | ---- | ---- | ----
![](img/Logo-064-ArduCAM.png) | ArduCAM | 8.4.2 | ![](img/Logo-064-Arduino-IDE.png) | Arduino STM32F4 | 10.3.0
![](img/Logo-064-chipKIT.png) | chipKIT | 11.9.11 | ![](img/Logo-064-4D-Systems.png) | 4D Systems | 11.6.0
![](img/Logo-064-Cosa.png) | Cosa framework | 9.6.8 | ![](img/Logo-064-Digistump-3.png) | Digistump | 9.6.8
![](img/Logo-064-ftDuino.png) | ftDuino | 10.9.9 | ![](img/Logo-064-Glowdeck.png) | Glowdeck | 9.6.8
![](img/Logo-064-Intel-IDE.png) | Intel for Wiring / Arduino | 8.4.2 | ![](img/Logo-064-Intel-IDE.png) | Intel Edison Yocto | 8.4.2
![](img/Logo-064-Intel-IDE.png) | Intel Edison MCU | 8.4.2 | ![](img/Logo-064-LightBlue.png) | Punch Through Design | 10.9.9
![](img/Logo-064-Launchpad.png) | LaunchPad C2000 | 11.2.5 | ![](img/Logo-064-Launchpad.png) | LaunchPad CC2650 | 11.2.5
![](img/Logo-064-Little-Robot-Friend.png) | Little Robot Friends | 8.4.2 | ![](img/Logo-064-Maple.png) | Maple | 8.4.2
![](img/Logo-064-ARM-mbed-enabled.png) | mbed SDK | 4.5.9 | ![](img/Logo-064-LinkIt.png) | Mediatek LinkIt | 11.9.11
![](img/Logo-064-Microduino.png) | Microduino | 11.9.11 | ![](img/Logo-064-panStamp.png) | panStamp STM32L4 | 11.2.5
![](img/Logo-064-panStamp.png) | panStamp AVR | 10.9.5 | ![](img/Logo-064-panStamp.png) | panStamp NRG | 10.9.5
![](img/Logo-064-RedBearLab-no-brand.png) | RedBear | 10.9.9 | ![](img/Logo-064-RFduino.png) | RFduino | 10.6.4
![](img/Logo-064-Simblee.png) | Simblee | 10.6.4 | ![](img/Logo-064-Spark.png) | Particle Core | 9.6.8
![](img/Logo-064-STM32duino_old.png) | STM32duino | 11.9.11 | ![](img/Logo-064-TinyCircuits.png) | TinyCircuits | 11.9.11
![](img/Logo-064-Robotis.png) | Robotis CM | 9.6.8 | ![](img/Logo-064-UDOO.png) | Udoo Neo | 11.9.11
![](img/Logo-064-Wiring.png) | Wiring | 8.4.2 | | | |

:octicons-plus-circle-16: To use a board running on the Wiring / Arduino framework but listed as discontinued,

+ Select the template **embedXcode+ All**.

To use a board running on other frameworks like the mbed SDK, the Cosa framework, the Intel Edison Yocto or MCU SDKs,

+ Install the corresponding release of embedXcode+.

## Check boards

Some boards age and are no longer supported by their standard IDEs.

![](img/Logo-064-Arduino-IDE.png) The Arduino Otto board was never released officially, although the corresponding boards package is available through the **Boards Manager**.

Support for this board is put on hold and will be discontinued mid-2019.

A [dedicated page](https://store.arduino.cc/arduino-genuino/retired) :octicons-link-external-16: lists all the retired products, which are no longer available for sale. The list includes the Arduino M0 and Arduino M0 Pro boards, the Arduino Y&uacute;n and Tian boards, the Arduino Primo and Primo Core boards.

![](img/Logo-064-Launchpad.png) Energia 16 no longer supports the LaunchPad MSP430G2 with MSP430G2231 and MSP430G2452 MCUs.

+ Please refer to the [Migrate Previous MSP430 Board Package to Energia 18](../../Chapter1/Section4/#migrate-previous-msp430-board-package-to-energia-18) :octicons-link-16: section to continue using these boards.

!!! Warning
	Energia 18 no longer supports the LaunchPad C2000, the SensorTag CC2650.

+ Please refer to the sections [Migrate the LaunchPad C2000 Boards to Energia 18](../../Legacy/Section4/#migrate-the-launchpad-c2000-boards-to-energia-18) :octicons-link-16: and [Migrate the CC2650 SensorTag to Energia 18](../../Legacy/Section4/#migrate-the-cc2650-sensortag-to-energia-18) :octicons-link-16: to continue using these boards.

The LaunchPad MSP432 comes in two releases, a pre-series in black and the final series in red.

<center>![](img/078-01-420.png)</center>
<center><i>Black for pre-series and red for final series</i></center>

There are two corresponding board packages. The Energia MSP432 EMT Red boards package supports the red final series board only, while the Energia MSP432 EMT boards package supports both the pre-series black board and the final series red board.

<center>![](img/078-02-420.png)</center>

The two editions of embedXcode support both boards packages, Energia MSP432 EMT and Energia MSP432 EMT Red.

However, the pre-series LaunchPad board in black and the corresponding boards package are obsolete and no longer maintained by Energia.

As a consequence, embedXcode no longer supports the black pre-series LaunchPad MSP432.

+ Select the `LaunchPad MSP432P401 Red EMT` board configuration file for the final series red board.

Should you need the black pre-series LaunchPad MSP432,

+ Add the following URL to the list of boards as per the procedure [Add URLs for new boards](../../Chapter1/Section4/#add-urls-for-new-boards) :octicons-link-16:.

```
https://energia.nu/packages/package_msp432_black_index.json
```

The `LaunchPad MSP432P401 EMT` board configuration file has been removed from the list of the boards.

+ Create and call a new file `LaunchPad MSP432P401 EMT.xcconfig` under the Configurations folder of the project.

+ Copy the following content and save it.

```
//
//  LaunchPad MSP432P401 EMT.xcconfig
//  Board configuration file
//  ----------------------------------
//  Developed with embedXcode
//
//  Part of embedXcode
//  Embedded Computing on Xcode
//
//  Created by  Rei Vilo on 24 Oct 2012
//  Copyright   (c) 2010-2022 https://embedXcode.weebly.com
//  Licence     All rights reserved
//
// Last update: 25 Sep 2018 release 10.0.6

// Board identifier
// See Boards.txt for <tag>.name=Arduino Uno (16 MHz)
//
BOARD_TAG  = MSP-EXP432P401R
BOARD_TAG_18 = MSP-EXP432P401R
MSP432_COLOUR = BLACK_OR_RED

// Port (optional)
// most common are /dev/tty.usbserial*, /dev/tty.usbmodem* or /dev/tty.uart*
//
BOARD_PORT = /dev/tty.usbmodem*

// References for Xcode code-sense
// See Boards.txt for <tag>.build.mcu=<GCC_PREPROCESSOR_DEFINITIONS>
//
GCC_PREPROCESSOR_DEFINITIONS = __MSP432P401R__ ENERGIA ENERGIA_MT

// Specify the full path and name of the application
// with /Contents/Java/** after
//
HEADER_SEARCH_PATHS = $HOME/Library/Energia15/packages/energia/hardware/msp432/**

// Maximum RAM size in bytes
// given by <tag>.upload.maximum_ram_size in boards.txt for Maple and Teensy
//
MAX_RAM_SIZE = 65536

MULTI_INO    = 1

CONFIG_NAME = LaunchPad MSP432P401 EMT

WARNING_MESSAGE = $(CONFIG_NAME) is no longer supported by Energia.
```

+ Select the `LaunchPad MSP432P401 EMT` board configuration file for the pre-series black board.

![](img/Logo-064-chipKIT.png) Digilent and chipKIT haven't released any new boards for a while now. Furthermore, the future of the PIC32 platform looks uncertain after Microchip acquired Atmel in January 2016.

The chipKIT uC32 board replaces the chipKIT Uno32 board.

Development for the chipKIT platform is put on hold.

![](img/Logo-064-4D-Systems.png) The PICadillo board from 4D Systems relies on a PIC32 MCU.

Development for the PICadillo board is put on hold.

![](img/Logo-064-Digistump-3.png) Development for the Digistump platform is discontinued.

The Digistump platform suffers from many stability issues, especially for the Oak board.

![](img/Logo-064-Glowdeck.png) Development for the Glowdeck platform is discontinued.

+ Please refer to the [Use discontinued Wiring / Arduino frameworks](../../Legacy/Section4/) :octicons-link-16: section.

![](img/Logo-064-Intel-IDE.png) Intel no longer supports the Curie, Galileo and Edison boards since December 2017.

As a consequence, development is halted. Support for the Galileo and Edison boards is discontinued. However, support for the Curie board is put on hold.

+ Please refer to the [Use discontinued Wiring / Arduino frameworks](../../Legacy/Section4/) :octicons-link-16: and [Use discontinued Intel Edison SDKs](../../Legacy/Section5/#use-discontinued-intel-edison-sdks) :octicons-link-16: sections.

![](img/Logo-064-LightBlue.png) Punch Through Design has discontinued the Bean boards.

Development is halted. Support for the Bean boards is put on hold.

![](img/Logo-064-Little-Robot-Friend.png) Development for the Little Robot Friends platform is discontinued.

Little Robot Friends no longer supports the first generation of boards with the release of the second generation.

![](img/Logo-064-Maple.png) Support for Maple boards is discontinued.

Leaflabs no longer supports the [Maple boards](https://www.leaflabs.com/maple) :octicons-link-external-16:.

The Maple IDE still lacks very basic but critical libraries such as stream and strings. The board is now supported by the STM32duino boards package compatible with the Arduino 1.6.5 **Boards Manager**.

+ Please refer to [Install the STM32duino platform](../../Chapter1/Section4/#install-the-stm32duino-platform) :octicons-link-16:.

![](img/Logo-064-panStamp.png) panStamp has discontinued the AVR and NRG boards.

Development for the panStamp AVR and NRG platforms is halted.

Similarly, the new generation panStamp Quantum platform hasn't been launched yet. Support is put on hold.

![](img/Logo-064-Robotis.png) The Robotis IDE relies on the Maple IDE, which is no longer maintained.

The STM32duino boards package provides a viable alternative and is compatible with the Arduino 1.6.5 **Boards Manager**.

+ Please refer to [Install the STM32duino platform](../../Chapter1/Section4/#install-the-stm32duino-platform) :octicons-link-16:.

![](img/Logo-064-RedBearLab-no-brand.png) RedBear will no longer sell its boards on March 2019 and will terminate support on September 2019, as a consequence of its acquisition by Particle.

Development is halted. Support for the RedBear boards is put on hold and will be discontinued in March 2019.

The nRF5 boards package provides a viable alternative for the RedBear nRF-based boards and is compatible with the Arduino 1.6.5 **Boards Manager**.

+ Please refer to the [Install the nRF5 boards platform](../../Chapter1/Section4/#install-the-nrf5-boards-platform) :octicons-link-16: section.

![](img/Logo-064-RFduino.png) The RFduino platform is discontinued.

In June 2016, Heptagon bought RF Digital, the manufacturer of the RFduino and Simblee boards. Then in October 2016, ams AG bought Heptagon. In June 2018, ams AG announced all the products were discontinued.

As a consequence, development is halted and support is discontinued.

![](img/Logo-064-Simblee.png) The RFduino platform is discontinued.

In June 2016, Heptagon bought RF Digital, the manufacturer of the RFduino and Simblee boards. Then in October 2016, ams AG bought Heptagon. In June 2018, ams AG announced all the products were discontinued.

As a consequence, development is halted and support is discontinued.

![](img/Logo-064-STM32duino.png) Development for the STM32duino platform has transitioned.

<center>![](img/Logo-064-STM32duino_old.png) ![](img/Logo-064-STM32duino.png)</center>
<center><i>Spot the difference!</i></center>

The initial project STM32duino has been renamed Arduino STM32. The new STM32duino project is maintained by STMicroelectronics.

Development for the Arduino STM32 platform is discontinued. Development for the STM32duino platform is active.

+ Please refer to the section [Install the STM32duino platform](../../Chapter1/Section4/#install-the-stm32duino-platform) :octicons-link-16:.

![](img/Logo-064-Wiring.png) Support for Wiring boards is discontinued.

Wiring is said to be working on a new release, called Wiring++, but with no specific release date.

Support for the Wiring boards will resume when an updated IDE is available.

## Check IDEs and plug-ins

![](img/Logo-064-Arduino-IDE.png) Support for Arduino.CC and Arduino.ORG IDEs is discontinued.

The unified Arduino 1.8.0 IDE corresponds to release 1.8.0 and supports all the boards from former Arduino.CC and Arduino.ORG.

All releases of the Arduino IDE prior to 1.8, including 0023, 1.0 and 1.5, and series 1.6 and 1.7, are deprecated and not longer supported.

The Arduino **Boards Manager** replaces previous plug-ins.

The Adafruit, chipKIT, Cosa, Digistump, ESP8266, Intel, Little Robot Friends, panStamp, RedBear, RFduino boards used to require plug-ins or specific IDEs.

They are now managed by the **Boards Manager** of the Arduino 1.6.5 IDE. The previous stand-alone IDEs and plug-ins are no longer supported.

![](img/Logo-064-MPIDE.png) Support for MPIDE is discontinued.

The chipKIT boards are now managed by the **Boards Manager** of the Arduino 1.6.5 IDE. The previous stand-alone IDE, MPIDE, is no longer supported.

![](img/Logo-064-Energia-1.png) Support for Energia prior to 1.6.10E18 is discontinued.

Release 1.6.10E18 features the same clean management of additional boards as Arduino 1.6.5 with the **Boards Manager**.

The versions of Energia IDE prior to release 1.6.10E18 are obsolete and no longer supported.

## Check frameworks

![](img/Logo-064-Arduino-IDE.png) Support for Arduino 0023, 1.0, 1.5, 1.6 prior to release 1.6.5 is discontinued.

Arduino 0023, 1.0 and 1.5 are deprecated. Arduino 1.6.5 offers a clean management of additional boards, widely adopted by third-party boards manufacturers.

The Arduino IDE versions prior to release 1.8.0 are obsolete and no longer supported.

![](img/Logo-064-Beagle.png) Support for BeagleBone is discontinued.

Most of the development tools for BeagleBone are designed for a main computer running on Linux. Building a tool-chain from scratch on Mac OS X is overtly difficult, and very few ready-to-use binaries are available for Mac OS X.

![](img/Logo-064-Cosa.png) Support for the Cosa framework is discontinued.

The latest release is dated 30 January 2016 and the project doesn't seem to be maintained anymore.

+ Please refer to the [Use discontinued Cosa framework](../../Legacy/Section6/) :octicons-link-16: section.

![](img/Logo-064-ARM-mbed-enabled.png) Support for mbed is discontinued.

The mbed SDK is going through a major reshuffle, with the release of Mbed-OS, leaving some issues unattended on today's version, rebranded mbed Classic. Furthermore, the latest mbed Classic updated releases are incompatible and unstable. Latest stable release of the mbed SDK with Bluetooth capabilities is 92.

![](img/Logo-064-Spark.png) Development for the Particle platform is discontinued.

Particle has discontinued the Particle Core board.

For the Photon and Electron boards, Particle strongly promotes its on-line IDE. Unfortunately, the command line tools don't offer the required level of stability.

Development for the Particle platform is discontinued.

## Check macOS and Xcode

The table below lists the macOS and Xcode versions corresponding to the  releases of embedXcode.

| | macOS Release and Name | Xcode Release | embedXcode Package | embedXcode Release | Comment
---- | --- | ---- | ---- | ---- | ----
![](img/Logo-064-macOS-11.0-BigSur.png) | macOS 11.0 *Big Sur* | Xcode 12 | | | Not supported
![](img/Logo-064-macOS-10.15-Catalina.png) | macOS 10.15 *Catalina* | Xcode 11 | Release     | 11.11 LTS | Active
![](img/Logo-064-macOS-10.15-Catalina.png) | macOS 10.15 *Catalina* | Xcode 11 | Release 11 | 11.9.11 | Limited support
![](img/Logo-064-macOS-10.14-Mojave.png) | macOS 10.14 *Mojave* | Xcode 10 | Legacy 10 | 10.9.9 | No support
![](img/Logo-064-macOS-10.13-High-Sierra.png) | macOS 10.13 *High Sierra* | Xcode 9 | | 9.6.8 |
![](img/Logo-064-macOS-10.12-Sierra.png) | macOS 10.12 *Sierra* | Xcode 9 | | 8.4.2 |
![](img/Logo-064-macOS-10.12-Sierra.png) | macOS 10.12 *Sierra* | Xcode 8 | | 7.6.8 |
![](img/Logo-064-macOS-10.11-El-Capitan.png) | OS X 10.11 *El Capitan* | Xcode 7 | | 4.5.9 |
![](img/Logo-064-macOS-10.10-Yosemite.png) | OS X 10.10 *Yosemite* | Xcode 7 | | 3.0.5 |
![](img/Logo-064-macOS-10.10-Yosemite.png) | OS X 10.10 *Yosemite* | Xcode 6 | | 2.9.8 |
![](img/Logo-064-macOS-10.9-Mavericks.png) | OS X 10.9 *Mavericks* | Xcode 5 | | 1.7.5 |
![](img/Logo-064-macOS-10.8-Mountain-Lion.png) | OS X 10.8 *Mountain Lion* | Xcode 4 | | 1.0.9 |
![](img/Logo-064-macOS-10.7-Lion.png) | OS X 10.7 *Lion* | Xcode 3 | | 0.6.1 |

![](img/Logo-064-macOS-10.15-Catalina.png) Both macOS 10.15 *Catalina* and Xcode 11 are available as free updates for systems introduced from mid-2012.

For more information,

+ Please refer to the [Get Ready for macOS Catalina](https://support.apple.com/macos/catalina) :octicons-link-external-16: page on Apple support.

For all embedXcode editions,

![](img/Logo-064-macOS-10.15-Catalina.png) A legacy edition is available for systems running Xcode 11 on macOS 10.14 *Mojave* and 10.15 *Catalina*. **embedXcode Legacy 11** corresponds to release 11.9.11.

!!! warning
    embedXcode Legacy 11 is no longer developed and has limited support.

For more information,

+ Please refer to [Install embedXcode Legacy 11](../../Legacy/Section11/) :octicons-link-16:.

:octicons-plus-circle-16: For the embedXcode+ edition,

![](img/Logo-064-macOS-10.14-Mojave.png) A legacy edition is available for systems running Xcode 10 on macOS 10.13 *High Sierra* and 10.14 *Mojave*. **embedXcode Legacy 10** corresponds to release 10.9.9.

!!! danger
    embedXcode Legacy 10 is deprecated and no longer supported.

For more information,

+ Please refer to [Install embedXcode Legacy 10](../../Legacy/Section10/) :octicons-link-16:.

All previous releases of embedXcode are deprecated and no longer available.
