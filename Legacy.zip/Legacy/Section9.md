<style>
.md-typeset h1, .md-typeset h2, .md-typeset h3 { color: #757575; }
</style>

# Install embedXcode Legacy 4

## Check the discontinued platforms

With embedXcode release 5.0, support for the mbed SDK and the BeagleBone board has been discontinued.

!!! danger
    embedXcode Legacy 4 is deprecated and no longer supported.

Release 4 of embedXcode is the last release with support for the mbed SDK and the BeagleBone board. Install first embedXcode release 4 and then the desired framework.

+ Please refer to the [Install the mbed Framework](../../Legacy/Section8/#install-the-mbed-framework) :octicons-link-16: and [Use the mbed Framework](../../Legacy/Section8/#use-the-mbed-framework) :octicons-link-16: sections.

+ Please refer to the [Install the BeagleBone Board](../../Legacy/Section7/#install-the-beaglebone-board) :octicons-link-16: and [Use the BeagleBone Board sections](../../Legacy/Section7/#use-the-beaglebone-board) :octicons-link-16:.

## Install embedXcode and select the options

On the Install embedXcode procedure with embedXcode release 4, select the options for the mbed framework and the BeagleBone board.

The next window presents different options for the installation.
<center>![](img/531-01-400.png)</center>

The options allow to select the frameworks you want to work with. When a framework is selected, the installer checks whether the corresponding tool-chain and SDK are already installed. If needed, it downloads and installs them.

+ Check **Install for mbed** if you want to use the mbed SDK.

The mbed framework shares the same 76 MB for the GCC tool-chain, and adds 20 MB for the SDK.

+ Check **Install for BeagleBone** if you want to use the BeagleBone board.

The BeagleBone sums 132 MB for the Linaro tool-chain.

## Manage the update policy

:octicons-plus-circle-16: For embedXcode+ releases prior to 7.0, projects rely on an update policy. This procedure is no longer required on embedXcode+ release 7.0 and later.

The update policy checks two elements. Is there a newer release of embedXcode? Does the project uses an old template?

Newer releases of embedXcode+ no longer uses this method.

The update policy is defined during the creation of a new project and can be edited afterwards.

### Define the Update Policy

When creating a new project with embedXcode+, the second window with the parameters of the project asks for the Update Policy.
<center>![](img/532-01-400.png)</center>

:octicons-plus-circle-16: On embedXcode+, the update policy can be defined among three options.

<center>![](img/533-01-420.png)</center>

+ Select the **Download and Update** option to download a newer release of embedXcode and update the project automatically.

<center>![](img/533-02-420.png)</center>

During the first compilation of the project and in case a newer version of embedXcode is available, a dialog box asks for downloading it. Also during compilation, in case the project uses an old template, another dialog box asks for updating the project.

+ Please refer to sections [Download New Release](../Chapter2/Section2/#download-new-release) :octicons-link-16: and [Update Project Automatically](../../Legacy/Section2/#update-project-automatically) :octicons-link-16: for more details.

+ Select the **Update only** option to update the project automatically.

<center>![](img/533-03-420.png)</center>

During compilation and in case the project uses an old template and a newer one has already been installed, a dialog box asks for updating the project. Please refer to the section [Update Project Automatically](../../Legacy/Section2/#update-project-automatically) :octicons-link-16: for more details.

+ Select the last option **(None)** to perform none of the above procedures.

<center>![](img/533-04-420.png)</center>

This option allows a distraction-free development.

This setting can be changed later on.

+ Please refer to the procedure [Set Update Policy](../../Legacy/Section2/#change-the-update-policy) :octicons-link-16:.

On embedXcode, the **Update only** option is the default update policy. During compilation and in case the project uses an old template and a newer one has already been installed, a dialog box asks for updating the project.

+ Please refer to the section [Update Project Automatically](../../Legacy/Section2/#update-project-automatically) :octicons-link-16: for more details.

### Change the update policy

:octicons-plus-circle-16: This is the manual procedure for defining the update policy set during the creation of the new project with embedXcode+.

This procedure is no longer active on embedXcode+ release 7.0 and later.

To change the update policy, proceed as follow:

+ Select the project on top of the leftmost list,

+ Select the project under the **PROJECT** list,

+ Select the **Build Settings** pane.

+ Scroll down at the very bottom and look for `UPDATE_POLICY` under the **User-Defined** section.

<center>![](img/534-01-420.png)</center>

+ Double-click on `UPDATE_POLICY`, and

<center>![](img/534-02-420.png)</center>

+ Set the value to `2` for **Download and Update**,

+ Set the value to `1` for **Update only**,

+ Set the value to `0` for **None** of the above.

For more information about the different options,

+ Please refer to section [Define the Update Policy](../../Legacy/Section9/#define-the-update-policy) :octicons-link-16:.

## Upgrade projects to embedXcode+ and new release of Xcode

:octicons-plus-circle-16: This section requires embedXcode+.

This procedure has been superseded by [Update Projects to embedXcode+ and New Release of Xcode](../../Chapter1/Section6/#update-the-projects) :octicons-link-16: for embedXcode+ release 7.0 and later.

For projects created with embedXcode+ older than release 2, for projects created with embedXcode to be used with embedXcode+, for projects created with a previous version of Xcode, just upgrade the projects using the **Upgrade Projects** utility.

+ Close Xcode.

+ Download and install the latest release of embedXcode+.

+ Open the the `~/Documents/embedXcode` folder.

<center>![](img/535-01-100.png)</center>

+ Double-click on the **Upgrade Projects** utility.

<center>![](img/535-01-360.png)</center>

A window asks for the folder with the projects to update.

<center>![](img/535-03-420.png)</center>

+ Select the folder that contains the projects to be updated and click on **Choose**.

The **Upgrade Projects** utility updates the version management system for all the projects located under the selected folder.

+ Return to embedXcode and launch the target **Build**.

During the compilation of the project, a dialog box prompts and asks for upgrading the project to embedXcode+.

<center>![](img/536-01-360.png)</center>

+ Click on **Upgrade** to upgrade the project or **Ignore** to ignore.

The dialog box closes automatically after 5 seconds.

A notification confirms the project has been updated

<center>![](img/536-02-360.png)</center>

Xcode may also rise a warning message.

<center>![](img/536-03-360.png)</center>

+ Click on **Read From Disk** to proceed.

The project includes the additional targets and boards.

<center>![](img/536-04-360.png)</center>

The update policy is set to Update only, so the standard update procedures described in the section [Update Project Automatically](../../Legacy/Section2/#update-project-automatically) :octicons-link-16: apply.

For other options as Download and Update or None,

+ Please refer to the procedure Define the Update Policy.

## Update project automatically

:octicons-plus-circle-16: This section requires embedXcode+.

This procedure is no longer active on embedXcode+ release 7.0 and later.

During the first compilation of the project, if the release of the template is more recent than the project, a dialog box prompts and asks for updating the project.

<center>![](img/537-01-360.png)</center>

+ Click on **Update** to update the project or **Ignore** to ignore it.

The dialog box closes automatically after 5 seconds.

+ Launch a new compilation.

The version management system in charge of the automatic update has been introduced with release 2.0 of embedXcode+, and thus requires the project to have been created with embedXcode+ release 2.0 or more recent.

Projects created with an earlier release of embedXcode+ don't feature the automatic update.

In that case,

+ Just upgrade the projects described in the next section Upgrade Projects to embedXcode+ and New Release of Xcode

or

+ Proceed with the manual update procedure detailed in the section Update Projects Manually.

:octicons-plus-circle-16: This procedure can be turned off.

+ Please refer to section Define the Update Policy.

## Add new boards missing after an update

If some new boards are missing after an update,

Select the `Configurations` folder on the left pane.

+ Call the contextual menu.

<center>![](img/538-01-200.png)</center>

+ Call the menu **Add Files to "embed1..."**.

A new window shows the content of the project folder.

<center>![](img/537-01-420.png)</center>

+ Navigate to the `Configurations` sub-folder.

+ Select the boards and click on Add.

To change the board,

+ Please follow the procedure [Change the Board](../Chapter3/Section6) :octicons-link-16:.

