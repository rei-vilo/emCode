---
tags:
    - Discontinued
---

<style>
.md-typeset h1, .md-typeset h2, .md-typeset h3 { color: #757575; }
</style>

# Use discontinued BeagleBone board

With embedXcode release 5.0, support for the mbed SDK and the BeagleBone board has been discontinued.

This section requires embedXcode Legacy 4.

To install embedXcode Legacy 4,

+ Please refer to the section [Install embedXcode Legacy 4](../../Legacy/Section9/#install-embedxcode-release-40) :octicons-link-16:.

The majority of the development tools for BeagleBone are designed for a main computer running on Linux. Building a tool-chain from scratch on Mac OS X is overtly difficult, and very few ready-to-use binaries are available for Mac OS X.

+ Please refer to the [Install the BeagleBone Board](../../Legacy/Section7/#install-the-beaglebone-board) :octicons-link-16: and [Use the BeagleBone Board](../../Legacy/Section7/#use-the-beaglebone-board) :octicons-link-16: sections.

## Install the BeagleBone board

:octicons-plus-circle-16: embedXcode+ release 4.0 allows to develop native applications for the BeagleBone board running on Debian.

<center>![](img/Logo-064-BeagleBone.png)</center>

Debian is the recommended Linux distribution for the BeagleBone.

<center>![](img/Logo-Debian-with-text.png)</center>

The tool-chain is provided by Linaro.

<center>![](img/linaro-logo-web.png)</center>

There are two components to install: the tool-chain and optional tools for easing connection.

Unfortunately, the majority of the development tools for BeagleBone are designed for a main computer running on Linux. Building a tool-chain from scratch on Mac OS X is overtly difficult, and very few ready-to-use binaries are available for Mac OS X.

Support for BeagleBone is discontinued.

### Install the Linaro tool-chain for Debian on BeagleBone

![](img/Logo-064-Linaro.png) The cross-compilation for the BeagleBone board on Debian uses the Linaro tool-chain.

### Install the Tools for BeagleBone Automatically

The installation of the tools for mbed is now included in the embedXcode installation package process.

<center>![](img/578-01-100.png)</center>

If the BeagleBone framework is selected, the installer checks whether the tool-chain and the SDK are already installed. If needed, it downloads and installs them.

The BeagleBone sums 132 MB for the Linaro tool-chain.

For more details on the installation process,

+ Please refer to the section [Install embedXcode Legacy 4](../../Legacy/Section9/#install-embedxcode-release-40) :octicons-link-16:.

The installation can be performed manually, as described in the following section.

### Install the tools for BeagleBone manually

If you plan to install the Linaro tool-chain on Debian manually,

+ Follow the procedure [ARM Cross Compiling with Mac OS X](http://www.welzels.de/blog/en/arm-cross-compiling-with-mac-os-x/) :octicons-link-external-16: by Knut Welzel. The tool-chain is provided as a compiled binary ready to install.

+ Move the `linaro` folder from `/usr/local/linaro to ~/Library/embedXcode/linaro`.

+ Unzip `edison-sdk-macosx-ww05-15.zip`.

+ Optionally, install the advanced sysroot.

Unfortunately, this tool-chain doesn't support debugging nor provides the sysroot folder.

### Install Tools for Connection

The `cu.usbmodem` port gives a limited access.

```
$ ls /dev/cu.*
/dev/cu.usbmodem1413
```

For full access, use instead either WiFi or Ethernet over USB. Ethernet over USB requires the installation of two drivers.

```
$ arp -a
host-001 (192.168.1.223) at aa:bb:cc:dd:ee:ff on en0 ifscope [ethernet]
beagleboneblack (192.168.7.2) at 11:22:33:44:55:66 on en8 ifscope [ethernet]
```

The three addresses, `192.168.1.223`, `192.168.7.2` and `beagleboneblack.local` give access to the board with ssh.

```
$ ssh root@192.168.1.223
$ ssh root@beagleboneblack.local
$ ssh root@192.168.7.2
```

To install Ethernet over USB,

+ Download and install the [Serial driver](http://beagleboard.org/static/Drivers/MacOSX/FTDI/EnergiaFTDIDrivers2.2.18.pkg) :octicons-link-external-16:, actually a FTDI driver.

+ Download and install the [Network driver](http://beagleboard.org/static/Drivers/MacOSX/RNDIS/HoRNDIS.pkg) :octicons-link-external-16:, actually the HoRNDIS driver.

+ Open **System Preferences... > Network**, and check the BeagleBone board appears under the list of connections.

<center>![](img/580-01-420.png)</center>
:octicons-link-external-16:
The default Ethernet over USB address is <http://192.168.7.2> :octicons-link-external-16:.

For more information,

+ Please refer to the procedure [Getting Started with BeagleBone and BeagleBone Black](http://beagleboard.org/getting-started#step2) :octicons-link-external-16:.

## Use the BeagleBone board

To create a new project,

+ Call the menu **File > New > Project...** or press ++cmd+shift+n++.

+ Select the macOS option.

<center>![](img/581-01-420.png)</center>

+ Scroll down and look for the embedXcode or embedXcode+ group.

<center>![](img/581-02-420.png)</center>

+ Select an embedXcode+ for BeagleBone Template

:octicons-plus-circle-16: If embedXcode+ for BeagleBone is installed, one single option is available.

<center>![](img/582-01-420.png)</center>

+ Select the template embedXcode+ BeagleBone for Debian native applications running on the BeagleBone board.

<center>![](img/Logo-064-BeagleBone.png)</center>

+ Click on **Next** to proceed to the next step.

### Upload to BeagleBone board

:octicons-plus-circle-16: This section requires embedXcode+.

![](img/Logo-064-Beagle.png) To upload to the BeagleBone board,

+ Please refer to the procedure [Install the SDKs for Intel Edison](../../Legacy/Section5/#install-the-edison-sdks) :octicons-link-16: and [Upload to Intel Edison Using WiFi or Ethernet over USB](../../Legacy/Section5/#upload-to-intel-edison-using-wifi-or-ethernet-over-usb) :octicons-link-16:.

## Visit the official websites for BeagleBone

The following section lists the names of the tools for the BeagleBone board running on Debian.

![](img/Logo-064-Beagle.png) | BeagleBone
---- | ----
Website | <http://beagleboard.org> :octicons-link-external-16:
Blog | <http://beagleboard.org/blog> :octicons-link-external-16:
Hardware support | <http://beagleboard.org/Support/Hardware+Support> :octicons-link-external-16:
Software support | <http://beagleboard.org/Support:octicons-link-external-16:Software+Support> :octicons-link-external-16:
Help | <http://beagleboard.org/getting-started> :octicons-link-external-16:
Forum | <http://beagleboard.org/Community/Forums> :octicons-link-external-16:

![](img/Logo-064-Debian.png) | Debian
---- | ----
Website | <https://www.debian.org> :octicons-link-external-16:

![](img/Logo-064-Linaro.png) | Linaro
---- | ----
Website | <http://www.linaro.org> ](http://www.linaro.org](http://www.linaro.org) ) :octicons-link-external-16:
Documentation | <https://www.linaro.org/docs> :octicons-link-external-16:
Download | <https://www.linaro.org/downloads> :octicons-link-external-16:
