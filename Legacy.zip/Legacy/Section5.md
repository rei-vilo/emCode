---
tags:
    - Discontinued
---

<style>
.md-typeset h1, .md-typeset h2, .md-typeset h3 { color: #757575; }
</style>

# Use discontinued Intel Edison SDKs

:octicons-plus-circle-16: This section requires the embedXcode+ edition.

!!! info
	Intel has announced it will stop supporting all its boards, including the Galileo, Edison and Curie boards, starting mid-December 2017.

The Intel Edison board features a SoC with one micro-processor and one micro-controller.

<center>![](img/Logo-064-eX+-Edison.png)</center>

The embedXcode+ edition supports the three frameworks of the Intel Edison board. The micro-processor executes sketches based on the Wiring / Arduino framework and native applications running on Yocto, while the micro-controller executes programs based on the MCU SDK.

<center>![](img/Logo-064-Intel-IDE.png) ![](img/Logo-064-Intel-MCU-SDK.png) ![](img/Logo-064-Yocto.png)</center>

### Use the Wiring / Arduino framework

The micro-processor runs sketches based on the Wiring / Arduino framework,

+ Please refer to the [Install the Intel platform](../../Legacy/Section4/#install-the-intel-platform) :octicons-link-16: section.

### Use the Yocto SDK

The micro-processor runs native applications on the recommended Yocto Linux distribution. Intel provides the Yocto SDK, the debugger and all the tools needed.

<center>![](img/027-01-180.png)</center>

To install the platform running on the Yocto framework,

+ Please refer to the [Install the Yocto SDK for Edison board](../../Legacy/Section4/#install-the-intel-edison-for-yocto-sdk) :octicons-link-16: section.

### Use the MCU SDK

The micro-controller executes programs based on the MCU SDK.

To develop applications running on the MCU with the MCU SDK,

+ Please refer to the [Install the MCU SDK for Edison Board](../../Legacy/Section4/Page8) :octicons-link-16: section.

Keep in mind applications running on the MCU are developed in C, not C++, and requires a specific configuration. Similarly, debugging is managed by adding lines to the code and the messages are redirected to a TTY port.

## Install the Edison SDKs

### Install the Edison SDKs Automatically

The installation of the two SDKs for Edison is now included in the embedXcode installation package process.

<center>![](img/Logo-064-Package.png)</center>

If the Edison framework is selected, the installer checks whether the tool-chain and the SDK for each of the two environments, Yocto and MCU, are already installed. If needed, it downloads and installs them.

The Edison frameworks represent 668 MB, with 492 MB for the Yocto environment and 176 MB for the MCU environment.

For more details on the installation process,

+ Please refer to the section Install the template.

The installation can be performed manually, as described in the following sections.

### Install the Edison Yocto SDK Manually

![](img/Logo-064-Yocto-white.png) If you plan to use the Yocto SDK on the Intel Edison board,

+ Download the SDK from the page [Software Downloads for Intel(r) Edison Boards and Compute Modules](http://www.intel.com/support/edison/sb/CS-035180.htm) :octicons-link-external-16:.

<center>![](img/626-01-200.png)</center>

+ Unzip `edison-sdk-macosx-ww18-15.zip`.

+ Copy-paste the folder `sysroots` from `~/Downloads/poky-edison-eglibc-i386-edison-image-core2-32-toolchain-1.6.1` to `~/Library/embedXcode/EdisonYocto/sysroots`.

The debugger for the Edison board isn't included in the SDK but in the IoT Development Kit.

If you plan to debug,

+ Download the [IoT Development Kit from the page Software Downloads for Intel(r) Edison Boards and Compute Modules](http://www.intel.com/support/edison/sb/CS-035180.htm) :octicons-link-external-16:.

+ Unzip `iotdk-ide-mac.tar.bz2`.

+ Copy the file `i586-poky-linux-gdb from ~/Downloads/iotdk-ide-mac/iot-devkit/devkit-debugger/` to `~/Library/embedXcode/EdisonYocto/uploader/`.

### Install the Edison MCU SDK manually

![](img/Logo-064-Edison-MCU.png) If you plan to use the MCU SDK on the Intel Edison board,

+ Download the MCU SDK and API from the page [Software Downloads for Intel Edison Boards and Compute Modules](http://www.intel.com/support/edison/sb/CS-035180.htm) :octicons-link-external-16:.

+ Unzip `edison-mcusdk-macosx64-1.0.10.zip`.

+ Copy-paste the folder `edison-mcusdk-macosx64-1.0.10 from ~/Downloads/` to `~/Library/embedXcode/EdisonMCU`.

+ Download the utility scripts `init_DIG.sh`, `init_i2c8.sh`, `init_mcu_PWM.sh`, `read_DIG.sh`, `set_DIG.sh` and `init_UART1.sh`.

+ Upload utility scripts to the Edison board.

The MCU SDK requires Intel Edison Board Firmware Software Release 2.1.

For more information,

+ Please refer to the [Setup Guide](https://software.intel.com/en-us/creating-applications-with-mcu-sdk-for-intel-edison-board) :octicons-link-external-16: and especially the [Known Limitations](https://software.intel.com/en-us/creating-applications-with-mcu-sdk-for-intel-edison-board) :octicons-link-external-16:.

Debugging requires calling the `debug_print` function on the application code. The messages are sent to the `/dev/ttymcu1` driver.

<center>![](img/627-01-420.png)</center>

## Set the folder for Yocto and MCU projects

The folder where the Yocto projects are saved is defined during installation. However, should this folder change, you need to define the new location.

For example, if the Yocto projects are located on the `~/Documents/Projects/EdisonYocto` folder,

+ Open the `~/Documents/embedXcode` folder.

<center>![](img/628-01-360.png)</center>

+ Double click on **Define path to Edison projects**.

<center>![](img/628-02-100.png)</center>

A window asks for the folder where the Yocto projects are saved.

<center>![](img/628-03-400.png)</center>

+ Select an existing folder or create a new one with **New Folder**.

+ Click **Choose**.

A notification confirms the new path.

<center>![](img/628-04-360.png)</center>

## Install tools for connection

The `cu.usbmodem` port gives a limited access and the `cu.usbserial` port provides full access but requires to plug-in the second USB cable.

``` bash
$ ls /dev/cu.*
/dev/cu.usbmodem1413
/dev/cu.usbserial-A123B456
```

For full access, use instead either WiFi or Ethernet over USB.

``` bash
$ arp -a
host-001 (192.168.1.223) at aa:bb:cc:dd:ee:ff on en0 ifscope [ethernet]
edison (192.168.2.15) at 11:22:33:44:55:66 on en8 ifscope [ethernet]
```

The three addresses, `192.168.1.223`, `192.168.2.15` and `edison.local`, give access to the board with ssh.

``` bash
$ ssh root@192.168.1.223
$ ssh root@edison.local
$ ssh root@192.168.2.15
```

To install Ethernet over USB,

+ Download and install the [HoRNDIS driver](http://joshuawise.com/horndis#available_versions) :octicons-link-external-16:.

+ Open **System Preferences... > Network**, configure IPv4 as **Using DHCP with manual address** and set the **IP address** to `192.168.2.1`.

<center>![](img/629-01-420.png)</center>

The default Ethernet over USB address is <http://192.168.2.15> :octicons-link-external-16:.

For more information,

+ Please refer to the procedure [Intel(r) Edison Connecting Ethernet over USB](https://software.intel.com/en-us/articles/intel-edison-connecting-ethernet-over-usb) :octicons-link-external-16:.

## Create a new project

To create a new project,

+ Call the menu **File > New > Project...** or press ++cmd+shift+n++.

+ Select the macOS option.

<center>![](img/630-01-420.png)</center>

+ Scroll down and look for the embedXcode or embedXcode+ group.

<center>![](img/630-02-420.png)</center>

There are five templates for the Wiring / Arduino framework, and one template for each of the other frameworks, Cosa, Edison Yocto, Edison MCU.

### Select an embedXcode+ for Intel Edison Template

:octicons-plus-circle-16: If embedXcode+ for Intel Edison is installed and selected, two options are available.

+ Select the template **embedXcode+ Edison Yocto** for Yocto native applications running on the Edison board.

<center>![](img/631-01-420.png)</center>

+ Select the template **embedXcode+ Edison MCU** for projects running on the Edison MCU.

<center>![](img/631-02-420.png)</center>

For the Arduino / Wiring framework on the Intel Edison board, select the templates embedXcode+ or embedXcode+ Arduino.

+ Click on **Next** to proceed to the next step.

+ Continue with [Define the parameters of the new project](../../Chapter2/Section1/#define-the-parameters-of-the-new-project) :octicons-link-16:.

## Add code and header files

+ Scroll down and look for the **embedXcode** or **embedXcode+** group.

<center>![](img/255-01-420.png)</center>

+ Select one of the options proposed, one per framework.

### Add a C++ code file or library

Based on the options selected during the installation, the embedXcode group of templates include different options.

:octicons-plus-circle-16: The embedXcode+ edition provides more options for the C++ File Edison Yocto and C File Edison MCU, based on the options selected during the installation

<center>![](img/Logo-064-eX+Edison.png)</center>

The header can be adapted to the framework.

<center>![](img/258-04-420.png)</center>

+ Select **Default** for all the boards running on the Wiring / Arduino framework.

:octicons-plus-circle-16: On the embedXcode+ edition,

+ Select **Edison Yocto** for the Intel Edison board running on Yocto.

+ Select **Edison MCU** for the Intel Edison board running on the MCU.

+ Click **Next**.

+ Continue with [Save the new file](../../Chapter3/Section3/#save-the-new-file) :octicons-link-16:.

## Define the settings for Edison MCU

![](img/Logo-064-Edison-MCU.png) If the application targets the Edison MCU and uses GPIO or PWM pins, I&sup2;C or UART ports, the ports need to be configured on the Linux side.

+ Open the main `Makefile` and edit the line `MCU_CONFIGURATION` with the settings.

+ Add the scripts among `init_DIG.sh`, `init_i2c8.sh`, `init_mcu_PWM.sh`, `read_DIG.sh`, `set_DIG.sh` and `init_UART1.sh` and specify the parameters.

The settings are automatically executed remotely on the Edison board during the upload process, as described at the section [Upload MCU Application](../../Legacy/Section4/#upload-mcu-application) :octicons-link-16:.

For more information,

+ Please refer to the page [Sample scripts for the MCU SDK](https://software.intel.com/en-us/node/557356) :octicons-link-external-16:.

## Visit the official website for Intel Edison

The following section lists the tools for the Yocto SDK environment and the MCU SDK and API available for the Intel Edison board.

![](img/Logo-064-Intel-IDE.png) | Intel
---- | ----
Website | <http://www.intel.com/content/www/us/en/do-it-yourself/maker.html> :octicons-link-external-16:
Galileo | <http://www.intel.com/support/maker/galileo> :octicons-link-external-16:
Edison | <http://www.intel.com/support/maker/edison> :octicons-link-external-16:
Download | <http://www.intel.com/content/www/us/en/do-it-yourself/downloads-and-documentation.html> :octicons-link-external-16:
Forum | <http://www.intel.com/content/www/us/en/do-it-yourself/forums-and-support.html> :octicons-link-external-16:

![](img/Logo-064-Edison-MCU.png) | Intel MCU
---- | ----
Documentation | <https://software.intel.com/en-us/node/557537> :octicons-link-external-16:
Guides | <https://www-ssl.intel.com/content/www/us/en/support/edison-documents-and-guides.html> :octicons-link-external-16:
Download | <https://software.intel.com/en-us/iot/hardware/edison/downloads> :octicons-link-external-16:

![](img/Logo-064-Yocto-white.png) | Yocto
---- | ----
Download | <https://software.intel.com/en-us/iot/hardware/edison/downloads> :octicons-link-external-16:
Website | <https://www.yoctoproject.org> :octicons-link-external-16:

