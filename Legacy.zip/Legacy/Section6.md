---
tags:
    - Discontinued
---

<style>
.md-typeset h1, .md-typeset h2, .md-typeset h3 { color: #757575; }
</style>

# Use discontinued Cosa framework

:octicons-plus-circle-16: This section requires the embedXcode+ edition.

The   embedXcode+ edition also supports the Cosa framework.

<center>![](img/Logo-064-eX+-Cosa.png)</center>

The Cosa framework is an interesting alternative to the Wiring / Arduino framework. It offers an object-oriented framework that runs on AVR-based boards.

It requires the previous installation of the Wiring / Arduino framework and runs only on AVR-based boards.

For more information about the Cosa framework,

+ Please refer to the official [online documentation](http://dl.dropboxusercontent.com/u/993383/Cosa/doc/html/index.html) :octicons-link-external-16: at the Cosa website.

## Install the Cosa framework

![](img/Logo-064-Cosa.png) If you plan to use the Cosa framework,

+ Download and install the supported versions of the Arduino IDE under the `/Applications` folder, as described in the section [Install the Arduino platform](../../Chapter1/Section4/Arduino) :octicons-link-16:.

+ Launch it.

+ Define the path of the sketchbook folder in the menu **Arduino > Preferences > Sketchbook location**.

<center>![](img/634-01-420.png)</center>

+ Avoid spaces in the name and path of the sketchbook folder.

+ Follow the procedure Install additional boards.

+ Call the **Boards Manager** and check the Cosa platform is listed.

<center>![](img/634-02-420.png)</center>

If the Cosa platform isn't listed on the **Boards Manager**,

+ Open the **Preferences** and add the following URL on a separate line, as described in section [Add URLs for new boards](../../Chapter1/Section4/#add-urls-for-new-boards) :octicons-link-16:.

```
https://raw.githubusercontent.com/mikaelpatel/Cosa/master/package_cosa_index.json
```

+ Select the board and click on **Install**.

For more information about the installation of Cosa,

+ Please refer to the [Installing Cosa](http://cosa-arduino.blogspot.fr/2013/02/installing-cosa.html) :octicons-link-external-16: page on the Cosa website.

Once installation is completed,

+ Check that the **Tools > Boards** menu on the Arduino IDE mentions the Cosa-supported boards.

<center>![](img/635-01-400.png)</center>

For more information about the Cosa framework,

+ Please refer to the official online [documentation](http://dl.dropboxusercontent.com/u/993383/Cosa/doc/html/index.html) :octicons-link-external-16: at the Cosa website.

## Create a new project

To create a new project,

+ Call the menu **File > New > Project...** or press ++cmd+shift+n++.

+ Select the macOS option.

<center>![](img/636-01-420.png)</center>

+ Scroll down and look for the embedXcode or embedXcode+ group.

<center>![](img/636-02-420.png)</center>

There are five templates for the Wiring / Arduino framework, and one template for each of the other frameworks, Cosa, Edison Yocto, Edison MCU.

## Select an embedXcode+ for Cosa template

:octicons-plus-circle-16: If **embedXcode+ for Cosa** is installed and selected, another option is available.

<center>![](img/Logo-064-eX+-Cosa.png)</center>

+ Select the template embedXcode+ Cosa for the AVR-based boards running on the object-oriented Cosa framework.

<center>![](img/637-01-420.png)</center>

+ Click on **Next** to proceed to the next step.

+ Continue with [Define the parameters of the new project](../../Chapter2/Section1/#define-the-parameters-of-the-new-project) :octicons-link-16:.

## Add code and header files

+ Scroll down and look for the **embedXcode** or **embedXcode+** group.

<center>![](img/255-01-420.png)</center>

+ Select one of the options proposed, one per framework.

### Add a C++ code file or library

Based on the options selected during the installation, the embedXcode group of templates include different options.

:octicons-plus-circle-16: The embedXcode+ edition provides an option for the C++ File Cosa, based on the options selected during the installation

<center>![](img/Logo-064-eX+-Cosa.png)</center>

+ Continue with [Add a C++ code file or library](../../Chapter3/Section3/#add-a-c-code-file-or-library) :octicons-link-16:.

## Visit the official websites

The following section lists the name of the tools for the Cosa framework, to be installed on top of the Arduino environment.

![](img/Logo-064-Cosa.png) | Cosa
---- | ----
IDE | Arduino with Boards Manager
Website | <http://cosa-arduino.blogspot.fr> :octicons-link-external-16:
Download | <https://github.com/mikaelpatel/Cosa> :octicons-link-external-16:
Wiki | <http://dl.dropboxusercontent.com/u/993383/Cosa/doc/html/index.html> :octicons-link-external-16:
Forum | <http://forum.arduino.cc/index.php?topic=150299> :octicons-link-external-16:
