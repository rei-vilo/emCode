---
tags:
    - Discontinued
---

<style>
.md-typeset h1, .md-typeset h2, .md-typeset h3 { color: #757575; }
</style>

# Use discontinued mbed SDK

With embedXcode release 5.0, support for the mbed SDK and the BeagleBone board has been discontinued.

This section requires embedXcode Legacy 4.

To install embedXcode Legacy 4,

+ Please refer to [Install embedXcode Legacy 4](../../Legacy/Section9/#install-embedxcode-release-40) :octicons-link-16:.

The mbed SDK is going through a major reshuffle, with the release of Mbed-OS. Today's release has been rebranded mbed Classic. Furthermore, the latest mbed Classic releases are incompatible and unstable. Obviously, developers are focusing on Mbed-OS, leaving some issues unattended on mbed Classic.

+ Please refer to the [Install the mbed Framework](../../Legacy/Section8/#install-the-mbed-framework) :octicons-link-16: and [Use the mbed Framework](../../Legacy/Section8/#use-the-mbed-framework) :octicons-link-16: sections.

## Install the mbed framework

embedXcode also supports the mbed framework.

<center>![](img/Logo-064-eX+-mbed.png)</center>

The mbed framework is a more advanced framework specifically designed for the ARM MCU-based boards.

<center>![](img/543-01-200.png)</center>

Once solely online, it is now available for download and can work offline with the GCC tool-chain and the OpenOCD debugger.

To install the platforms running on this framework,

+ Please refer to the [Install the mbed Framework](../../Legacy/Section8/#install-the-mbed-framework) :octicons-link-16: section.

### The mbed-enabled boards

The boards compatible with the mbed framework are labelled with the logo mbed Enabled or ARM mbed enabled.

<center>![](img/Logo-064-ARM-mbed-enabled-square.png) ![](img/Logo-064-mbed-Enabled.png)</center>

Various manufacturers offer boards compatible with mbed, as Freescale, Nordic Semiconductors, NXP, RedBear, STMicroelectronics among others.

<center>![](img/Logo-064-Freescale.png) ![](img/Logo-064-Nordic.png) ![](img/Logo-064-NXP.png) ![](img/Logo-064-RedBearLab-no-brand.png) ![](img/Logo-064-STM.png)</center>

The boards feature Cortex-M0, M0+, M3 or M4 MCUs.

When the board is plugged in, the USB connection provides three services:

+ The board is mounted as a standard USB volume. Program the board with a drag-and-drop of the executable.

+ A virtual port offers a serial terminal.

+ An interface allows programming and debugging with offline tools.

The official firmware requires release 10.10.3 of Mac OS X Yosemite. Unfortunately, prior releases of Mac OS X Yosemite don't work properly.

For more information and firmware updates,

+ Please refer to the page dedicated to the board on the [Platform page](http://developer.mbed.org/platforms/) :octicons-link-external-16: of the mbed website.

### The tools for the mbed framework

However, contrary to the different platforms based on the Wiring / Arduino framework, the mbed framework doesn't come with an all-in-one proprietary application.

The embedXcode package downloads and installs the tool-chain and the framework for mbed..

<center>![](img/578-01-100.png)</center>

+ Please refer to the section [Install the tools for mbed](../../Legacy/Section8/#install-the-tools-for-mbed) :octicons-link-16:.

The mbed framework or mbed SDK provides a set of libraries and acts as a hardware abstraction layer so the same code can run on different boards.

<center>![](img/544-01-200.png)</center>

For more information,

+ Please refer to the [ARM mbed website](http://developer.mbed.org) :octicons-link-external-16:.

The mbed framework runs on the GCC ARM tool-chain, which includes different compilers, a linker and utilities.

<center>![](img/545-02-100.png)</center>

This is the same tool-chain used for most of the platforms running on the Wiring / Arduino framework, but adapted to the ARM MCUs.

:octicons-plus-circle-16: All the mbed-enabled boards feature a built-in hardware debugger based on OpenOCD.

This last component requires a manual installation.

<center>![](img/545-02-360.png)</center>

Please refer to the procedure at [Install OpenOCD for mbed-Supported Boards with Homebrew](../../Legacy/Section8/#install-openocd-for-mbed-enabled-boards-with-homebrew) :octicons-link-16:.

## Select your platform

. | . | . | . | . | .
---- | ---- | ---- | ---- | ---- | ----
![](img/Logo-064-mbed-blue.png) | ![](img/Logo-064-Freescale.png) | ![](img/Logo-064-Nordic.png) | ![](img/Logo-064-NXP.png) | ![](img/Logo-064-RedBearLab-no-brand.png) | ![](img/Logo-064-STM.png)
[mbed](../../Legacy/Section8/#install-the-mbed-framework) :octicons-link-16: | [Freedom](../../Legacy/Section8/#install-the-freedom-platform) :octicons-link-16: | [Nordic](../../Legacy/Section8/#install-the-nordic-platform) :octicons-link-16: | NXP | [RedBear](../../Legacy/Section8/#install-the-redbear-platform-for-mbed) :octicons-link-16: | [Nucleo](../../Legacy/Section8/#install-the-nucleo-platform) :octicons-link-16:

### Install the tools for mbed

![](img/Logo-064-mbed-blue.png) Contrary to the Wiring / Arduino framework which comes bundled in applications or the Cosa framework that goes on top of the Wiring / Arduino framework, the mbed framework requires the installation of different components.

There are three main components: the framework, the tool-chain and the debugger.

The mbed platform has been tested with the following software configuration:

+ Mac OS X 10.11 *El Capitan*,

+ GCC ARM Embedded 4.9-2015q2 tool-chain,

+ mbed SDK version 104,

+ OpenOCD version 0.8.0 compiled with specific parameters,

on the following boards:

+ Nucleo F401RE from STMicroelectronics, and

+ Freedom FL25Z board from Freescale, with restrictions on the debugger.

Some platforms require specific settings. Please refer to their corresponding sections.

:octicons-plus-circle-16: All the mbed-enabled boards feature a built-in hardware debugger based on OpenOCD. This is an optional tool.

### Install the tools for mbed automatically

The installation of the tools for mbed is now included in the embedXcode installation package process.

<center>![](img/544-01-100.png)</center>

If the mbed framework is selected, the installer checks whether the tool-chain and the SDK are already installed. If needed, it downloads and installs them.

The mbed framework weights up to 96 MB, with 76 MB for the GCC tool-chain and 20 MB for the SDK.

For more details on the installation process,

+ Please refer to the section [Install embedXcode Legacy 4](../../Legacy/Section9/#install-embedxcode-release-40) :octicons-link-16:.

The installation can be performed manually, as described in the following section.

+ Check the result of the installation.

Once the installation has been completed, the folder `~/Library/embedXcode` contains the following files.

<center>![](img/548-01-300.png)</center>

### Install the tools for mbed manually

:octicons-plus-circle-16: This section requires embedXcode+.

As an alternative, here is the manual procedure:

+ Open the Finder and go to the `~/Library` folder.

To do so,

+ Press ++cmd+shift+g++ and enter the path `~/Library`.

<center>![](img/549-01-360.png)</center>

+ Click on **Go**.

Alternatively,

+ Press ++ alt++ while clicking on the **Go** menu and select Library.

<center>![](img/549-02-300.png)</center>

On the `~/Library` folder,

+ Create a new folder inside and name it embedXcode to obtain `~/Library/embedXcode`.

To install the mbed SDK,

<center>![](img/544-01-200.png)</center>:octicons-link-external-16:

+ Download the [mbed SDK](https://github.com/mbedmicro/mbed) :octicons-link-external-16: from the GitHub repository and unzip it into ~/Library/embedXcode.

+ If needed, rename the new folder to obtain `~/Library/embedXcode/mbed`.

To allow version management,

+ Open the file `~/Library/embedXcode/mbed/libraries/mbed/api/mbed.h`.

+ Find the version number after MBED_LIBRARY_VERSION

```
#define MBED_LIBRARY_VERSION 89
```

+ Open **TextEdit** and create a new text file.

+ Enter the version number, in this case `89`.

```
89
```

+ Save it as `~/Library/embedXcode/mbed/version.txt`.

To define the folder where the mbed projects are stored,

+ Open **TextEdit** and create a new text file.

+ Add the following line and specify the path to the desired folder, `~/Documents/mbed` in this example.

```
sketchbook.path=~/Documents/mbed
```

+ Save it as `~/Library/embedXcode/mbed/preferences.txt`.

Optionally, to save space,

+ Erase all the directories and files except the `~/Library/embedXcode/mbed/libraries` folder and the `LICENSE` file.

For more information about the installation of the mbed SDK,

+ Please refer to the [ARM mbed Handbook](http://developer.mbed.org/handbook/Homepage) :octicons-link-external-16: page.

The mbed framework doesn't come with the pre-compiled distributions for boards under the `mbed/build` folder. To build the pre-compiled distributions for boards,

. Please refer the [Tools: How to Setup and Use the Build System](http://developer.mbed.org/handbook/mbed-tools) :octicons-link-external-16: page.

Because the mbed framework is hosted and maintained in a GitHub repository, the code evolves on a regular basis. Unfortunately, there is no official release scheme with version numbers. This may rise issues if new or modified code goes untested.

For ease of use and stability, embedXcode relies on the pre-compiled distributions installed by the Tools for mbed package under the `mbed/build` folder.

However, the embedXcode+ edition can also use the source code under the `mbed/firmware` folder. This allows adding new mbed-enabled boards easily.

To install the GCC for ARM tool-chain,

<center>![](img/545-02-100.png)</center>

+ Download the [GCC for ARM tool-chain](https://launchpad.net/gcc-arm-embedded/+download) :octicons-link-external-16: release `gcc-arm-none-eabi-4_8-2014q3-20140805-mac`.

+ Unzip it into `~/Library/embedXcode`.

For more information about the installation of the GCC tool-chain,

+ Please refer to the [GNU Tools for ARM Embedded Processors](https://launchpad.net/gcc-arm-embedded) :octicons-link-external-16: page.

### Install the uploader for mbed boards

Releases of Mac OS X *Yosemite* prior to 10.10.3 are not compatible and raise an error message.

<center>![](img/552-01-360.png)</center>

+ Please update Mac OS X Yosemite to release 10.10.3.

As a work-around for releases of Mac OS X Yosemite prior to 10.10.3, install the manual utility.

+ Download the `mbed-on-Yosemite` script from the [Yosemite file copier for HDK-based mbed](https://developer.mbed.org/users/okano/notebook/mbed-on-yosemite/) :octicons-link-external-16: page on the mbed website.

<center>![](img/552-01-100.png)</center>

+ Install it on the `Desk` for easy access.

This procedure is required for all boards.

To use the uploader utility,

+ Locate the executable `embededcomputing.hex` under the Builds sub-folder of the project.

<center>![](img/552-03-300.png)</center>

+ Drag-and-drop `embededcomputing.hex` on the **mbed-on-Yosemite** script.

<center>![](img/552-04-120.png)</center>

A first window asks for confirmation.

<center>![](img/553-01-360.png)</center>

+ Click on **Run**.

<center>![](img/553-02-360.png)</center>

+ Enter the password and confirm on **OK**.:octicons-link-external-16:

## Install the Freedom platform

![](img/Logo-064-Freescale.png) The Freedom boards from Freescale run on the mbed framework.

The tested board is the [Freedom KL25Z](https://developer.mbed.org/platforms/KL25Z/) :octicons-link-external-16: and the [Freedom K64F](https://developer.mbed.org/platforms/FRDM-K64F) :octicons-link-external-16:.

If you plan to use the Freedom boards:

+ First, follow the Install the Tools for mbed Framework procedure.

Depending on the boot-loader and the firmware versions of the board, you may need to update the USB services.

### Install the Freedom KL25Z Board

To check the boot-loader and the firmware versions.

+ Press the `RESET` button on the board and connect the USB plug.

+ Open the `BOOTLOADER` volume.

+ Click on `SDA-INFO.HTM`.

+ A window shows the different versions:

<center>![](img/554-01-360.png)</center>

If no volume shows up or if the boot-loader is prior to version 1.11, you need a PC running on Windows XP or Windows 7 to update the boot-loader. Freescale redirects to the PEmicro website for the updated boot-loader and firmware.

<center>![](img/554-02-100.png)</center>

First,

+ Follow the instructions detailed on the page OpenSDA Support from PEmicro and update the boot-loader named `BOOTUPDATEAPP_Pemicro_v111.SDA`. :octicons-link-external-16:

+ Then, once the boot-loader has been updated,

+ Proceed with the update of the [OpenSDA firmware (MSD & Debug)](http://www.pemicro.com/opensda/) :octicons-link-external-16: using the firmware `MSD-DEBUG-FRDM-KL25Z_Pemicro_v114.SDA` from PEmicro.

This firmware from PEmicro provides an USB drive named FRDM-KL25Z and a serial port but no debugging on Mac OS X.

The official firmware from mbed, named `20140530_k20dx128_kl25z_if_opensda.s19` and available at the Firmware [FRDM KL25Z](https://os.mbed.com/handbook/Firmware-FRDM-KL25Z) :octicons-link-external-16: page, requires Mac OS X Yosemite release 10.10.3 and later. Prior versions of Mac OS X are not compatible.

### Install the Freedom K64F board

:octicons-plus-circle-16: This section requires embedXcode+.

To check the boot-loader and the firmware versions.

+ Connect the board to the USB plug.

+ Open the `BOOTLOADER` volume.

+ Click on `DETAILS.TXT`.

A window shows the installed version of the firmware:

<center>![](img/555-01-360.png)</center>

if the boot-loader is prior to version 226, you need to upgrade it. Please follow the step-by-step firmware upgrade instructions available at the [Firmware FRDM K64F](https://developer.mbed.org/handbook/Firmware-FRDM-K64F) :octicons-link-external-16: page.

## Install the Nordic platform

:octicons-plus-circle-16: This section requires embedXcode+.

![](img/Logo-064-Nordic.png) The Nordic boards feature the nRF51822 SoC, which combines a Bluetooth Low Energy radio with a Cortex-M0 MCU.

The tested board is the [Nordic nRF51822](http://developer.mbed.org/platforms/RedBearLab-nRF51822/) :octicons-link-external-16:.

If you plan to use the Nordic and RedBear boards,
:octicons-link-external-16:
+ Follow the Install the Tools for mbed Framework procedure.

### Select the Recommended mbed SDK for Bluetooth Low Energy

The Bluetooth Low Energy implementation on mbed consists on two libraries: the mbed Bluetooth Low Energy API provides an abstract layer to work with the Bluetooth Low Energy controllers, while the Nordic nRF51822 library includes stack and drivers for the mbed BLE API.

However, the BLE implementation requires a close compatibility between the mbed SDK and the BLE libraries. Latest releases of the mbed SDK doesn't match with the BLE libraries.

The recommended configuration uses [release 92](https://github.com/mbedmicro/mbed/releases/tag/mbed_lib_rev92) :octicons-link-external-16: of the mbed SDK with a specific release of the libraries included in the mbed BLE Libraries.zip.

A dedicated template is available during the installation of embedXcode.

+ Select the option **Install for mbed BLE**.:octicons-link-external-16:

<center>![](img/555-01-400.png)</center>

All the tests have been performed with this template.

### Install the Recommended mbed SDK for Bluetooth Low Energy Manually

As an alternative, here are the manual procedures.

To install [release 92](https://github.com/mbedmicro/mbed/releases/tag/mbed_lib_rev92) :octicons-link-external-16: of the mbed SDK,

+ Follow the Manual Procedure.

To install the BLE libraries,

+ Open the `~/embedXcode` folder.

<center>![](img/557-02-120.png)</center>:octicons-link-external-16:

+ Unzip the compressed file `mbed BLE Libraries.zip`. :octicons-link-external-16:

+ Copy the `BLE_API` and `nRF51822` folders into the `Library` sub-folder of the folder for mbed.

<center>![](img/558-01-360.png)</center>

Or,

+ Download and unzip the [mbed Bluetooth Low Energy stack](https://github.com/mbedmicro/BLE_API) :octicons-link-external-16:.

+ Download and unzip the [Nordic nRF51822 library](https://github.com/mbedmicro/nRF51822) :octicons-link-external-16:.

+ Copy the `BLE_API` and `nRF51822` folders into the `Library` sub-folder of the folder for mbed.

<center>![](img/558-02-360.png)</center>

Please note some users have reported issues with the downloaded libraries and more recent releases of the mbed SDK.

### Install the Bluetooth Low Energy utility

The software service in charge of the Bluetooth stack needs to be merged with the executable file. To do so, we use the [SRecord utility](http://srecord.sourceforge.net) :octicons-link-external-16:.

<center>![](img/559-01-100.png)</center>

To install the utility,

+ Open a **Terminal** window.

+ Launch the following command to install Homebrew, if it isn't already available.

```
$ /usr/bin/ruby -e "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/master/install)"
```

+ Run the command.

```
$ brew install srecord
```

## Install the Nucleo platform

![](img/Logo-064-STM.png) The Nucleo boards from STMicroelectronics run on the mbed framework.

The tested boards are the [Nucleo F401RE](https://developer.mbed.org/platforms/ST-Nucleo-F401RE/) :octicons-link-external-16:, the [Nucleo L152RE](https://developer.mbed.org/platforms/ST-Nucleo-L152RE/) :octicons-link-external-16: and the [Nucleo F072RB](https://developer.mbed.org/platforms/ST-Nucleo-F072RB/) :octicons-link-external-16:. embedXcode also supports the [Discovery STM32F429](https://developer.mbed.org/platforms/ST-Discovery-F429ZI/) :octicons-link-external-16: and the [Discovery STM32F746](https://developer.mbed.org/platforms/ST-Discovery-F746NG/) :octicons-link-external-16:.

If you plan to use the Freedom boards:

+ Follow the [Install the Tools for mbed Framework procedure.](../http://127.0.0.1:8000/Legacy/Section8/#install-the-tools-for-mbed) :octicons-link-16:.

The official firmware works fine under Mac OS X Yosemite release 10.10.3 and mounts the USB volume for programming.

### Update the Boards firmware

To update the firmware of the boards,

+ Download and install the ST-LINK/V2-1 firmware upgrade.

Run the application and follow the instructions to update the firmware of the boards.

### Use an alternative uploader

To install the alternative uploader ST-Link,

+ Download the ST-Link uploader package from its [GitHub repository](https://github.com/texane/stlink) :octicons-link-external-16:.

+ Unzip the file and open a Terminal window.

+ Execute the following commands:

```
$ cd ~/Downloads/stlink-master
$ ./autogen.sh
$ ./configure
$ make install
```

As an alternative to install the uploader ST-Link,

+ Open a **Terminal** window.

+ Launch the following command to install **Homebrew**, if it isn't already available.

```
$ /usr/bin/ruby -e "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/master/install)"
```

+ Run the command

```
$ brew install stlink
```

However, this version may not be up-to-date.

The Nucleo boards require no specific settings.

## Install the RedBear platform for mbed

:octicons-plus-circle-16: This section requires embedXcode+.

![](img/Logo-064-RedBearLab-no-brand.png) The RedBear boards run with the Wiring / Arduino framework and with the mbed framework. They feature the nRF51822 SoC from Nordic, which combines a Bluetooth Low Energy radio with a Cortex-M0 MCU.

The tested board is the [RedBear nRF51822](http://developer.mbed.org/platforms/RedBearLab-nRF51822/) :octicons-link-external-16:.

### Install the RedBear platform for Wiring / Arduino

To install the RedBear platform for the Wiring / Arduino framework,

+ Please refer to Install the RedBear Platform for Wiring / Arduino.

### Install the RedBear platform for mbed

If you plan to use the RedBear boards on the mbed framework,

+ Follow the [Install the Tools for mbed SDK](../../Legacy/Section8/#install-the-tools-for-mbed-SDK) :octicons-link-16: procedure.

+ Download and install the [SRecord utility](http://srecord.sourceforge.net) :octicons-link-external-16:.

The recommendations mentioned for using Bluetooth Low Energy on the nRF51822 apply on the RedBear boards.

A dedicated template is available during the installation of embedXcode.

+ Select the option **Install for mbed BLE**.

<center>![](img/555-01-400.png)</center>

All the tests have been performed with this template.

### Install debugging tools for mbed

:octicons-plus-circle-16: This section requires embedXcode+.

The boards supported by mbed also require the installation of OpenOCD. :octicons-link-external-16:

<center>![](img/545-02-360.png)</center>

Most of the ARM-based boards running on mbed include a hardware debugger.

Debugging has been tested successfully on the following boards:

+ Nucleo F401RE board running on mbed.

The installation of OpenOCD can be done using either Homebrew or MacPorts. It is recommended to use only one among those tools.

OpenOCD requires the previous installation of [libusb](http://www.libusb.org) :octicons-link-external-16:, a library that provides an easy access to USB devices.

Some mbed-enabled boards require a specific installation of OpenOCD. This is done by specifying options during the installation.

For example, the mbed-supported Nucleo F401RE requires the following options:

```
$ brew install openocd --enable_ft2232_libftdi --enable-stlink
```

Those options can be combined with those for other boards.

For more information,

+ Please refer to the [OpenOCD documentation](http://openocd.sourceforge.net/documentation) :octicons-link-external-16: and to the websites of the respective manufacturers of the boards.

### Install OpenOCD for mbed-enabled boards with Homebrew

To install OpenOCD with Homebrew,

<center>![](img/080-01-260.png)</center>

+ Open a **Terminal** window.

+ Launch the following command to install Homebrew.

```
$ /usr/bin/ruby -e "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/master/install)"
```

+ Launch the following command to install `libusb`.

```
$ brew install libusb
```

+ Launch the following command to install `openOCD`.

```
$ brew install openocd
```

Some LaunchPad boards require a specific installation of OpenOCD. This is done by specifying options during the installation.

For example, the mbed-supported Nucleo F401RE requires the following options:

```
$ brew install openocd --enable_ft2232_libftdi --enable-stlink
```

Those options can be combined with those for other boards.:octicons-link-external-16:

For more information,

+ Please refer to the [OpenOCD documentation](http://openocd.sourceforge.net/documentation) :octicons-link-external-16: and to the websites of the respective manufacturers of the boards.

### Install OpenOCD for mbed-enabled boards with MacPorts

To install OpenOCD with MacPorts,

<center>![](img/081-01-260.png)</center>

+ Download and install [MacPorts](http://www.macports.org/install.php) :octicons-link-external-16:.

+ Open a **Terminal** window.

+ Launch the following command to install libusb.

```
$ sudo port install libusb
```

+ Launch the following command to install openOCD.

```
$ sudo port install openocd
```

### Set the folder for mbed projects

The folder where the mbed projects are saved is defined during installation. However, should this folder change, you need to define the new location.

For example, if the mbed projects are located on the `~/Documents/Projects/mbed` folder,

+ Open the the `~/Documents/embedXcode` folder.

<center>![](img/565-01-360.png)</center>

+ Double click on **Define path to mbed projects**/

<center>![](img/565-02-100.png)</center>

A window asks for the folder where the mbed projects are saved.

<center>![](img/566-01-400.png)</center>

+ Select an existing folder or create a new one with **New Folder**.

+ Click **Choose**.

A notification confirms the new path.

<center>![](img/566-02-360.png)</center>

## Use the mbed framework

To create a new project,

+ Call the menu **File > New > Project...** or press ++cmd+shift+n++.

+ Select the macOS option.

<center>![](img/567-01-420.png)</center>

+ Scroll down and look for the embedXcode or embedXcode+ group.

<center>![](img/567-02-420.png)</center>

### Select an embedXcode for mbed Template

if embedXcode for mbed or embedXcode+ for mbed is installed, one single option is available.

<center>![](img/Logo-064-eX-mbed.png) ![](img/Logo-064-eX+-mbed.png)</center>

+ Select the template embedXcode mbed or embedXcode+ mbed for all the mbed-enabled boards.

<center>![](img/567-04-420.png)</center>

<center>![](img/567-05-420.png)</center>

+ Click on Next to proceed to the next step.

### Upload to mbed boards

![](img/Logo-064-mbed-blue.png) When plugged-in, the mbed-enabled board appears as a new volume called `MBED`.

<center>![](img/568-01-300.png)</center>

In the case of the Nucleo boards, the volume is called `NUCLEO`.

<center>![](img/568-02-300.png)</center>

To upload a compiled project, the binary is just copied into the volume. This features requires release 10.10.3 of Mac OS Yosemite or later. The board reads the binary, resets and launches it.

Prior releases of Mac OS X Yosemite are not compatible and raise an error message.

<center>![](img/569-01-360.png)</center>

In such a case,

+ Please follow the procedure described at section [Install the Uploader for mbed Boards](../../Legacy/Section8/#install-the-uploader-for-mbed-boards) :octicons-link-16:.

The board reads the binary, resets and launches it. When the board resets, it is disconnected.

This raises an error with the following message:

<center>![](img/569-02-360.png)</center>

+ Just click on **Close** to close the message.

### Upload to the Freedom K64F board

:octicons-plus-circle-16: This section requires embedXcode+.

Contrary to other mbed-enabled boards, the Freedom K64F doesn't perform an automatic reset after the upload.

Once the compiled project has been uploaded, a dialog box appears.

<center>![](img/569-03-360.png)</center>

+ Press the `RESET` button on the board.

The board resets and launches the project.

### Define a new mbed-enabled board

When mbed is selected, the new Board Configuration Settings File comes with an example for the mbed framework.

<center>![](img/570-01-420.png)</center>

<center>*The Board Configuration Setting file for mbed*</center>

Contrary to the boards supported by the Wiring / Arduino framework where the central file boards.txt contains all the parameters of the boards, the boards configuration files for the mbed-enabled boards are self-contained.

This allows to quickly and easily add new boards. All the parameters are required.

The values for most of the following parameters are taken from the makefile when exporting a program from the online IDE using the GCC option.

<center>![](img/562-01_400.png)</center>

+ Specify the name of the volume opened when the board is plugged in. This parameter is used when uploading the compiled sketch to the board.

```
BOARD_VOLUME = /Volumes/NUCLEO
```

+ Specify the name of the board. This parameter is not used for compiling, linking or uploading.

```
BOARD_NAME = ST Nucleo F401RE
```

+ Specify the family of the MCU.

```
MCU = cortex-m4
```

+ Specify the options for the FPU.

```
FPU_OPTIONS = -mfpu=fpv4-sp-d16 -mfloat-abi=hard
```

If the MCU has no FPU, leave the value empty.

```
FPU_OPTIONS =
```

+ Specify the build options.

```
BUILD_OPTIONS = __CORTEX_M4 __FPU_PRESENT NO_EXCEPTIONS
```

+ Specify the name of link script.

```
LDSCRIPT = NUCLEO_F401RE.ld
```

+ Specify the name of the startup assembler file.

```
STARTUP = startup_STM32F40x.s
```

+ Specify the name of the tool-chain used, here GCC.

```
TOOLCHAIN = TOOLCHAIN_GCC_ARM
```

+ Specify the name of the uploader, if it is different from the copy-paste mechanism. Here ST-Link for the Nucleo board.

```
UPLOADER        = stlink
```

+ Specify the name of the software service in charge of Bluetooth Low Energy, here S110 for the nRF51822-based boards.

```
SOFTDEVICE      = s110_nrf51822_7_1_0
```

+ Specify the size of the flash and RAM memory in bytes.

```
MAX_FLASH_SIZE  = 524288
MAX_RAM_SIZE    = 100352
```

+ Specify the elements of the path to the board in the `libraries/mbed/targets/hal/` sub-folder.

```
LEVEL1 = TARGET_STM
LEVEL2 = TARGET_NUCLEO_F401RE
LEVEL3 =
```

This corresponds to the Nucleo F401RE board, which sub-path is `TARGET_STM/TARGET_NUCLEO_F401RE/` from full path

```
~/Library/embedXcode/mbed/libraries/mbed/targets/hal/TARGET_STM/TARGET_NUCLEO_F401RE/.
```

As there are two levels, the `LEVEL3` value is left empty.

```
LEVEL3 =
```

The sub-path for the Freedoom KL25Z board has three levels with `TARGET_Freescale/TARGET_KLXX/TARGET_KL25Z/` from full path `~/Library/embedXcode/mbed/libraries/mbed/targets/hal/TARGET_Freescale/TARGET_KLXX/TARGET_KL25Z/`.

+ Use `LEVEL3` in that case.

```
LEVEL1 = TARGET_Freescale
LEVEL2 = TARGET_KLXX
LEVEL3 = TARGET_KL25Z
```

+ For the pre-compiled distribution, specify the name of the path to the board in the `build/mbed/` sub-folder.

```
LEVEL0 = TARGET_NUCLEO_F401RE
```

This corresponds to the Nucleo F401RE board, which sub-path is `TARGET_NUCLEO_F401RE/` from full path `~/Library/embedXcode/mbed/build/mbed/TARGET_NUCLEO_F401RE/`.

+ Provide additional options used for compiling some specific libraries.

```
MORE_OPTIONS = TARGET_STM32F401RE TOOLCHAIN_GCC
MORE_TARGET_INCLUDE = TARGET_M4
MORE_TOOLCHAIN_INCLUDE = TOOLCHAIN_GCC
```

+ Finally, if the mbed framework is already pre-compiled for the board, set `MBED_MAKE_OPTION` to `FAST`. Otherwise, specify `FULL`.

```
MBED_MAKE_OPTION = FAST
```

embedXcode checks if the pre-compiled distribution is available. Otherwise, it goes through the compilation of the whole mbed framework.

### Read warnings

Those options have been tested with the Freedom KL25Z, Nordic nRF521822, Nucleo F401RE, RedBear nRF51822 boards, with and without pre-compiled distribution of the mbed framework, and with the software releases mentioned at [Install the Tools for mbed SDK](../../Legacy/Section8/#install-the-tools-for-mbed-SDK) :octicons-link-16:.

For the nRF51822-based Nordic and RedBear boards, the tests include the standard `blinky` project and the heart rate monitor application.

Unfortunately, some mbed-enabled boards don't comply with the standard implementation and may require a specific development, as for the Freedom K64F.

## Visit the official websites for the mbed framework

The following section lists the names of the tools for the mbed environment, and the different providers of mbed-enabled boards.

![](img/Logo-064-mbed-blue.png) | **mbed**
---- | ----
Website | <http://mbed.org> :octicons-link-external-16:
Website | <http://developer.mbed.org> :octicons-link-external-16:
Download | <https://github.com/mbedmicro/mbed> :octicons-link-external-16:
Help | <http://developer.mbed.org/handbook> :octicons-link-external-16:
Blog | <http://developer.mbed.org/blog> :octicons-link-external-16:
Forum | <http://developer.mbed.org/forum> :octicons-link-external-16:

![](img/Logo-064-GCC.png) | **GNU Compiler Collection**
---- | ----
Website | <https://gcc.gnu.org> :octicons-link-external-16:
Download | <https://launchpad.net/gcc-arm-embedded> :octicons-link-external-16:
Help | <https://gcc.gnu.org/onlinedocs/> :octicons-link-external-16:
Wiki | <https://gcc.gnu.org/wiki> :octicons-link-external-16:

![](img/Logo-064-OpenOCD.png) | **Open On-Chip Debugger**
---- | ----
Website | <https://gcc.gnu.org> :octicons-link-external-16:
Download | <http://sourceforge.net/projects/openocd> :octicons-link-external-16:
Documentation | <http://openocd.sourceforge.net/documentation> :octicons-link-external-16:
Forum | <http://openocd.sourceforge.net/discussion/forum> :octicons-link-external-16:

![](img/Logo-064-Freescale.png) | **Freedom**
---- | ----
Website | <http://www.freescale.com> :octicons-link-external-16:
Help | <http://www.freescale.com/freedom> :octicons-link-external-16:
Wiki | <http://developer.mbed.org/platforms/?pvend=4> :octicons-link-external-16:

![](img/Logo-064-Nordic.png) | **Nordic**
---- | ----
Website | <https://www.nordicsemi.com> :octicons-link-external-16:
Help | <https://www.nordicsemi.com/eng/Products/Bluetooth-Smart-Bluetooth-low-energy/nRF51822-mKIT> :octicons-link-external-16:
Wiki | <http://developer.mbed.org/platforms/?pvend=11> :octicons-link-external-16:

![](img/Logo-064-STM.png) | **Nucleo**
---- | ----
Website | <http://www.st.com> :octicons-link-external-16:
Help | <http://www.st.com/stonline/stappl/productcatalog/app?page=partNumberSearchPage&levelid=FM141&parentid=1847&resourcetype=HW> :octicons-link-external-16:
Wiki | <http://developer.mbed.org/platforms/?pvend=10> :octicons-link-external-16:

![](img/Logo-064-RedBearLab-no-brand.png) | **RedBear**
---- | ----
Website | <http://redbearlab.com> :octicons-link-external-16:
Download | <https://github.com/redbearlab> :octicons-link-external-16:
Wiki | <http://redbearlab.com/getting-started-nrf51822> :octicons-link-external-16:
Support | <http://developer.mbed.org/platforms/?pvend=19> :octicons-link-external-16:

