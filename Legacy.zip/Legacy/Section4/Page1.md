---
tags:
    - Discontinued
---

<style>
.md-typeset h1, .md-typeset h2, .md-typeset h3 { color: #757575; }
</style>

# Install the ArduCAM platform

:octicons-plus-circle-16: This section requires the embedXcode+ edition.

![](img/Logo-064-ArduCAM.png) The ArduCAM platform includes the ArduCAM ESP8266 and the ArduCAM CC3200 boards.

The installation for the ArduCAM CC3200 board requires the Energia IDE.

The installation for the ArduCAM ESP8266 board requires the **Boards Manager** on the Arduino 1.8 IDE.

## Install the ArduCAM CC3200 Board

If you plan to use the ArduCAM CC3200 board,

+ Download and install the specific release of the [Energia IDE for ArduCAM CC3200](https://github.com/ArduCAM/Energia) :octicons-link-external-16:.

For more information on the installation of the ArduCAM CC3200 board,

+ Please refer to [Getting Started CC3200 with Energia IDE](http://www.arducam.com/arducam_cc3200_uno_energia/) :octicons-link-external-16: on the ArduCAM website.

+ Connect the board

The ArduCAM CC3200 board is under the menu **Tools > Board**.

<center>![](img/046-01-420.png)</center>

## Install the ArduCAM ESP8266 Board

If you plan to use the ArduCAM ESP8266 board,

+ Download and install the supported versions of the Arduino IDE under the `/Applications` folder, as described in the section [Install the Arduino platform](../../Chapter1/Section4/Arduino) :octicons-link-16:. Other releases don't work.

+ Launch it.

+ Define the path of the sketchbook folder in the menu **Arduino > Preferences > Sketchbook location**.

+ Avoid spaces in the name and path of the sketchbook folder.

+ Follow the procedure [Install additional boards on Arduino](../../Chapter1/Section4/#install-additional-boards-on-arduino) :octicons-link-16:.

+ Call the **Boards Manager** and check the ArduCAM platform is listed.

<center>![](img/046-02-420.png)</center>

If the ArduCAM platform isn't listed on the **Boards Manager**,

+ Open the **Preferences**.

+ Add the following URL on a separate line, as described in section [Add URLs for new boards](../../Chapter1/Section4/#add-urls-for-new-boards) :octicons-link-16:.

```
https://www.arducam.com/downloads/ESP8266_UNO/package_ArduCAM_index.json
```

+ Select the boards and click on **Install**.

For more information on the installation of the ArduCAM ESP8266 board,

+ Please refer to [Getting Started ESP8266 with Arduino IDE](http://www.arducam.com/arducam-esp8266-uno-board-arduino-camera/) :octicons-link-external-16: on the ArduCAM website.

+ Connect the board

The ArduCAM ESP8266 board is under the menu **Tools > Board**.

<center>![](img/047-01-420.png)</center>

# Upload to ArduCAM CC3200 Board

:octicons-plus-circle-16: This section requires the embedXcode+ edition.

![](img/Logo-064-ArduCAM.png) The ArduCAM CC3200 board requires a specific procedure.

Proceed as follow:

+ Place the two shunts on `FT-RX` and `FT-TX`.

<center>![](img/331-01-420.png)</center>

+ Remove the camera from the connector.

+ Plug the ArduCAM CC3200 board in.

+ Launch any of the targets **All**, **Upload** or :octicons-plus-circle-16: **Fast**.

+ Plug the camera back into the connector.

## Visit the official websites

![](img/Logo-064-ArduCAM.png) | **ArduCAM**
:---- | ----
IDE for ESP8266 | Arduino with Boards Manager
IDE for CC3200 | Energia
Website | <http://www.arducam.com> :octicons-link-external-16:
Download CC3200 | <https://github.com/ArduCAM/Energia> :octicons-link-external-16:
Wiki CC3200 | <http://www.arducam.com/arducam_cc3200_uno_energia> :octicons-link-external-16:
Wiki ESP8266 | <http://www.arducam.com/arducam-esp8266-uno-board-arduino-camera> :octicons-link-external-16: