---
tags:
    - Discontinued
---

<style>
.md-typeset h1, .md-typeset h2, .md-typeset h3 { color: #757575; }
</style>

# Install the ftDuino platform

![](img/Logo-064-ftDuino.png) The ftDuino platform uses an ATMega328 to drive the fischertechnik models. The installation of the ftDuino platform is performed with the **Boards Manager** on the Arduino 1.8 IDE.

If you plan to use the ftDuino platform,

+ Download and install the supported versions of the Arduino IDE under the `/Applications` folder, as described in the section [Install the Arduino platform](../../Chapter1/Section4/Arduino) :octicons-link-16:.

+ Launch it.

+ Define the path of the sketchbook folder in the menu **Arduino > Preferences > Sketchbook location**.

+ Avoid spaces in the name and path of the sketchbook folder.

+ Follow the procedure [Install additional boards on Arduino](../../Chapter1/Section4/#install-additional-boards-on-arduino) :octicons-link-16:.

+ Call the **Boards Manager** and check the ftDuino platform is listed.

<center>![](img/072-04-420.png)</center>

If the ftDuino platform isn't listed on the **Boards Manager**,

+ Open the **Preferences**.

+ Add the following URL on a separate line, as described in section [Add URLs for new boards](../../Chapter1/Section4/#add-urls-for-new-boards) :octicons-link-16:.

```
https://raw.githubusercontent.com/harbaum/ftduino/master/package_ftduino_index.json
```

+ Select the board and click on **Install**.

For more information on the installation of the Arduino IDE,

+ Please refer to the [Installation](https://github.com/harbaum/ftduino) :octicons-link-external-16: page on the ftDuino website.

## Visit the official websites

![](img/Logo-064-ftDuino.png) | **ftDuino**
:---- | ----
IDE | Arduino with Boards Manager
Website | <https://harbaum.github.io/ftduino/www/en/> :octicons-link-external-16:
Download | <https://github.com/harbaum/ftduino> :octicons-link-external-16:
Forum | <https://forum.ftcommunity.de/viewtopic.php?f=8&t=4509> :octicons-link-external-16: