---
tags:
    - Discontinued
---

<style>
.md-typeset h1, .md-typeset h2, .md-typeset h3 { color: #757575; }
</style>

# Install the Glowdeck platform

:octicons-plus-circle-16: This section requires the embedXcode+ edition.

![](img/Logo-064-Glowdeck.png) If you plan to use the Glowdeck board,

+ Download and install the supported versions of the Arduino IDE under the `/Applications` folder, as described in the section [Install the Arduino platform](../../Chapter1/Section4/Arduino) :octicons-link-16:.

+ Download the Glowdeck plug-in.

+ Launch the **Glowdeck Setup** application.

<center>![](img/589-01-420.png)</center>

+ Proceed with the installation.

+ Launch **Arduino**.

+ Define the path of the sketchbook folder in the menu **Arduino > Preferences > Sketchbook location**.

+ Avoid spaces in the name and path of the sketchbook folder.

The Glowdeck setup install the Glowdeck-specific boards and libraries into the Arduino IDE. It manages the 32-bit ARM architecture.

In order to differentiate this version of Arduino from other releases of the Arduino IDE,

+ Change the name to `Arduino` or `Glowduino` to avoid any confusion with other releases of the Arduino IDE.

embedXcode identifies the IDE automatically among `Arduino` and `Glowduino`.

# Upload to Glowdeck board

:octicons-plus-circle-16: This section requires the embedXcode+ edition.

![](img/Logo-064-Glowdeck.png) Compiled sketches can be uploaded to the Glowdeck board using three methods: over-the-air with Bluetooth, through a USB connection or using the Segger J-Link emulator.

## Upload through Bluetooth

The upload with Bluetooth is the recommended method for the board. Proceed as follow:

+ Check Bluetooth is enabled on the Mac.

+ Check the Glowdeck board is on upload mode. All the LEDs should be blue.

Otherwise, power off the board, press on the front button then power on the board while keeping the front button pressed on.

+ Launch any of the targets **All**, **Upload** or :octicons-plus-circle-16: **Fast**.

A new window opens and scans for the Glowdeck boards.

<center>![](img/590-01-360.png)</center>

If there is one single Glowdeck board, the upload starts automatically. The blue LEDs glow.

If there are more than one Glowdek board,

<center>![](img/592-01-360.png)</center>

+ Select the board on the drop-down-list.

+ Press **Update**.

The upload starts. The blue LEDs glow.

<center>![](img/593-01-360.png)</center>

Once upload is completed, the board resets and runs the sketch.

<center>![](img/593-02-360.png)</center>

For more information,

+ Please refer to the page on the Glowdeck website.

## Upload through USB

The upload through USB requires a configuration. The uploader displays a reminder if the configuration hasn't been done.

```
Glowdeck Firmware Loader for macOS
+ Glowdeck One-Time MSD Configuration Setup *
Please follow these steps to enable direct firmware uploads (via USB) on macOS.
WARNING: Failure to follow these steps exactly as shown can lead to system instability. Proceed carefully.
1. From a Terminal prompt, type (without the quotations): "sudo vifs"
2. Press Enter - type your Mac password if prompted - and a file editor will open.
3. Press the "i" key to activate insert text mode.
4. Use the keyboard arrows to navigate the cursor to the bottom of the file/screen.
5. Add the following 2 lines, exactly as they appear below, to the bottom/end of the file:
LABEL=GLOWDECK_V1 none msdos rw,noauto 0,0
LABEL=GLOWDECK_V2 none msdos rw,noauto 0,0
6. Press the "Esc" key.
7. Type the following characters (without the quotations) ":wq"
8. Press Enter. The one-time setup procedure is now complete.
9. If connected, disconnect and then reconnect Glowdeck from your computer's USB port.
10. Upload your firmware (you will never need to follow these steps again).
```

+ Proceed accordingly.

For more information,

+ Please refer to the page at the Glowdeck website.

To upload,

+ Check the Glowdeck board is on upload mode.

All the LEDs should be blue.

+ Otherwise, power off the board, press on the front button then power on the board while keeping the front button pressed on.

+ Connect the Glowdeck board to the Mac.

+ Launch any of the targets **All**, **Upload** or :octicons-plus-circle-16: **Fast**.

An error message is displayed.

<center>![](img/594-01-360.png)</center>

+ Just ignore it and click on **OK**.

A **Terminal** window opens and asks for the user's password.

```
Glowdeck Firmware Loader for macOS

Scanning...
Password:
Found GLOWDECK_V1...
Mounting Glowdeck...
Uploading firmware to Glowdeck...
Builds/embeddedcomputing.bin: No such file or directory
Finishing upload...
Disk /Volumes/Glowdeck ejected
Please leave Glowdeck attached while macOS is given time to clear the cache...
..........
Success - dismiss the warning and restart Glowdeck to load firmware.
```

+ Type the user's password and press ++enter++.

When the upload is completed, power-cycle the board.

+ Close the **Terminal** window.

## Upload with the Segger J-Link emulator

![](img/Logo-064-J-Link.png) To upload using the Segger J-Link emulator,

+ Always power the Glowdeck first.

+ Connect the Glowdeck board to the Segger J-Link emulator with an adapter cable.

+ Connect the Segger J-Link emulator to the Mac with an USB cable.

+ Press the `RESET` button on the board.

+ Launch any of the targets **All**, **Upload** or :octicons-plus-circle-16: **Fast**.

## Visit the official websites

![](img/Logo-064-Glowdeck.png) | **Glowdeck**
---- | ----
IDE | Glowdeck plug-in for Arduino
Website | <http://www.Glowdeck.com> :octicons-link-external-16:
Download | <http://www.Glowdeck.com> :octicons-link-external-16:
Forum | <http://www.Glowdeck.com> :octicons-link-external-16:
Support | <http://www.Glowdeck.com> :octicons-link-external-16:
