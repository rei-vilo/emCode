---
tags:
    - Discontinued
---

<style>
.md-typeset h1, .md-typeset h2, .md-typeset h3 { color: #757575; }
</style>

# Install the Robotis platform

:octicons-plus-circle-16: This section requires the embedXcode+ edition.

![](img/Logo-064-Robotis.png) If you plan to use the Robotis OpenCM9.04 board:

+ Download and install the Robotis OpenCM IDE under the `/Applications` folder.

+ Launch it.

<center>![](img/129-01-360.png)</center>

+ Define the path of the sketchbook folder in the menu **ROBOTIS > Preferences > Sketchbook location**.

+ Avoid spaces in the name and path of the sketchbook folder.

## Install Java 6

The Robotis OpenCM IDE requires Java 6. If it isn't available, an error message suggests to install it.

<center>![](img/129-02-360.png)</center>

+ Click on **More Info...** or go to [Download Java for OS X 2015-001](https://support.apple.com/kb/DL1572) :octicons-link-external-16: on the Apple website.

+ Download and install the `javaforosx.dmg` package.

+ Relaunch the Robotis OpenCM IDE.

## Define integer standard types

Just like the Maple IDE, Robotis OpenCM only knows `[u]int{8|16|32|64}` types and ignores the C99 standard `[u]int{8|16|32|64}_t` types.

If you plan to use libraries designed for another platform and want to ensure C99 compatibility,

Open the `/Applications/ROBOTIS_OpenCM.app/Contents/Resources/Java/hardware/robotis/cores/robotis/libpandora_types.h` file.

Add this `#include` to the `libpandora_types.h` file, although stdint.h defines other types.

``` c
#include <stdint.h>
```

As an alternative,

+ Open the `/Applications/ROBOTIS_OpenCM.app/Contents/Resources/Java/hardware/robotis/cores/robotis/libpandora_types.h` file.

+ Add the definitions for the `[u]int{8|16|32|64}_t` types.

``` c
// Added C99 Standard Types
#define uint8_t uint8
#define uint16_t uint16
#define uint32_t uint32
#define uint64_t uint64
#define int8_t int8
#define int16_t int16
#define int32_t int32
#define int64_t int64
```

Just like Maple, the Robotis OpenCM environment misses two important libraries: `strings.h` and `stream.h`.

For more information on the installation procedure,

+ Please refer to the [Getting Started](http://emanual.robotis.com/docs/en/software/opencm_ide/getting_started/#getting-started) page on the Robotis website :octicons-link-external-16:.

:octicons-plus-circle-16: The embedXcode+ edition allows to locate the Robotis OpenCM in another folder.

+ Please refer to the section [Set the folder for standard IDEs](../../Chapter1/Section3/#set-the-folder-for-standard-ides) :octicons-link-16:.

# Upload to Robotis OpenCM9.04 board

:octicons-plus-circle-16: This section requires the embedXcode+ edition.

![](img/Logo-064-Robotis.png) The Robotis OpenCM9.04 board requires a specific upload procedure.

Proceed as follow:

+ Plug the Robotis OpenCM9.04 board.

+ Launch any of the targets **All**, **Upload** or :octicons-plus-circle-16: **Fast**.

Before the upload, a window asks you to press on the button on the board to start the process.

+ Press the `RESET` button on the Robotis OpenCM9.04 board.

+ Click **OK** on the message window.

<center>![](img/367-01-360.png)</center>

## Visit the official websites

![](img/Logo-064-Robotis.png) | **Robotis**
:---- | ----
IDE | Robotis OpenCM
Website | <http://support.robotis.com/en/home.htm> :octicons-link-external-16:
Download | <http://support.robotis.com/en/software/robotis_opencm.htm> :octicons-link-external-16:
