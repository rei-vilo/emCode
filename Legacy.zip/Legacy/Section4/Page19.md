---
tags:
    - Discontinued
---

<style>
.md-typeset h1, .md-typeset h2, .md-typeset h3 { color: #757575; }
</style>

# Install the Simblee platform

:octicons-plus-circle-16: This section requires the embedXcode+ edition.

![](img/Logo-064-Simblee.png) The installation of the Simblee board is performed with the **Boards Manager** on the Arduino 1.8 IDE.

!!! warning
    Upload to this board hasn't been tested.

## Install the Simblee platform

If you plan to use the Simblee platform,

+ Download and install the supported versions of the Arduino IDE under the `/Applications` folder, as described in the section [Install the Arduino platform](../../Chapter1/Section4/Arduino) :octicons-link-16:.

+ Launch it.

+ Define the path of the sketchbook folder in the menu **Arduino > Preferences > Sketchbook location**.

+ Avoid spaces in the name and path of the sketchbook folder.

+ Follow the procedure [Install additional boards on Arduino](../../Chapter1/Section4/#install-additional-boards-on-arduino) :octicons-link-16:.

+ Call the **Boards Manager** and check the Simblee platform is listed.

<center>![](img/133-01-420.png)</center>

If the Simblee platform isn't listed on the **Boards Manager**,

+ Open the **Preferences**.

+ Add the following URL on a separate line, as described in section [Add URLs for new boards](../../Chapter1/Section4/#add-urls-for-new-boards) :octicons-link-16:.

```
https://www.simblee.com/package_simblee166_index.json
https://raw.githubusercontent.com/OpenHAK/Simblee/master/package_openhak_index.json
```

+ Alternatively, try one of the following URLs.

```
https://raw.githubusercontent.com/OpenHAK/Simblee/master/package_openhak_index.json
https://openbci.com/arduino/package_simblee166_index.json
```

+ Select the board and click on **Install**.

For more information on the installation of the RFduino board on the Arduino IDE,

+ Please refer to the [Simblee Concepts &ndash; Setting Up Arduino](https://learn.sparkfun.com/tutorials/simblee-concepts/setting-up-arduino) :octicons-link-external-16: page on the Sparkfun website.

+ Alternatively, try [Getting started with Arduino firmware](https://github.com/OpenHAK/Docs/blob/master/Getting%20Started%20With%20Arduino.md) :octicons-link-external-16: from OpenHAK or [Simblee Quickstart Guide](https://openbci.com/arduino/simblee/Simblee_Quickstart_Guide_v1.0.pdf) :octicons-link-external-16: from OpenBCI.

## Connect the board

The Simblee board is under the menu **Tools > Board**.

<center>![](img/134-01-360.png)</center>

## Visit the official websites

![](img/Logo-064-Simblee.png)| **Simblee**
:---- | ----
IDE | Arduino with Boards Manager
Website | <https://www.simblee.com> :octicons-link-external-16:
Documentation | <https://www.simblee.com> :octicons-link-external-16:
Help | <https://learn.sparkfun.com/tutorials/simblee-concepts> :octicons-link-external-16:
Other | <https://github.com/OpenHAK/Docs/blob/master/Getting%20Started%20With%20Arduino.md> :octicons-link-external-16: and <https://openbci.com/arduino/simblee/Simblee_Quickstart_Guide_v1.0.pdf> :octicons-link-external-16: