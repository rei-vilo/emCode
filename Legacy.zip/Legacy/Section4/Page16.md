---
tags:
    - Discontinued
---

<style>
.md-typeset h1, .md-typeset h2, .md-typeset h3 { color: #757575; }
</style>

# Install the RedBear platform for Wiring / Arduino

:octicons-plus-circle-16: This section requires the embedXcode+ edition.

!!! warning
    In March 2018, RedBear announced it was acquired by Particle. As a consequence, RedBear will terminate support for its boards on September 2019.

![](img/Logo-064-RedBearLab-no-brand.png) The RedBear boards feature different connectivities and MCUs. All run with the Wiring / Arduino framework.

There are three families of boards with Bluetooth Low Energy connectivity. Each one features a different MCU. The AVR MCU has a separate Bluetooth Low Energy radio. The nRF51822 SoC from Nordic combines a Bluetooth Low Energy radio with a Cortex-M0 MCU. So does the nRF52832 SoC also from Nordic but with a Cortex-M4 MCU.

The RedBear boards with WiFi connectivity are based on the CC3200 and are supported natively by Energia release 0101E0017 or later. The CC3200 from Texas Instruments combines a WiFi radio with a Cortex-M4 MCU.

The RedBear Duo board provides dual WiFi and Bluetooth Low Energy connectivity and features a Cortex-M3 MCU.

Some of the RedBear boards also support the mbed framework. For more information,

+ Please refer to [Install the RedBear platform for mbed](../../Legacy/Section4/#install-the-redbear-platform-for-mbed) :octicons-link-16:.

The nRF5 boards package provides a viable alternative for the RedBear nRF-based boards and is compatible with the Arduino 1.6.5 **Boards Manager**.

+ Please refer to the [Install the nRF5 boards platform](../../Chapter1/Section4/#install-the-nrf5-boards-platform) :octicons-link-16: section.

## Install the RedBear AVR Platform for Wiring / Arduino

If you plan to use the RedBear AVR boards on the Wiring / Arduino framework,

+ Download and install the supported versions of the Arduino IDE under the `/Applications` folder, as described in the section [Install the Arduino platform](../../Chapter1/Section4/Arduino) :octicons-link-16:.

+ Launch it.

+ Define the path of the sketchbook folder in the menu **Arduino > Preferences > Sketchbook location**.

+ Avoid spaces in the name and path of the sketchbook folder.

+ Follow the procedure [Install additional boards on Arduino](../../Chapter1/Section4/#install-additional-boards-on-arduino) :octicons-link-16:.

+ Call the **Boards Manager** and check the RedBear AVR platform is listed.

<center>![](img/121-01-420.png)</center>

If the RedBear AVR platform isn't listed on the **Boards Manager**,

+ Open the **Preferences**.

+ Add the following URL on a separate line, as described in section [Add URLs for new boards](../../Chapter1/Section4/#add-urls-for-new-boards) :octicons-link-16:.

```
https://redbearlab.github.io/arduino/package_redbearlab_index.json
```

+ Select the boards and click on **Install**.

For more information on the installation of the RedBear boards,

+ Please refer to the [Boards Manager](https://github.com/RedBearLab/Blend/blob/master/Docs/BoardsManager.pdf) :octicons-link-external-16: procedure.

The ReadBear Blend boards require two libraries: the BLE SDK for Arduino and the RBL nRF8001. A third one, BLE Peripheral, is recommended.

+ Follow the procedure [Install additional libraries on Arduino](../../Chapter1/Section4/#install-additional-libraries-on-arduino) :octicons-link-16:.

+ Check the **Library Manager** lists the BLE SDK for Arduino, BLE Peripheral and RBL nRF8001 libraries.

<center>![](img/122-01-420.png)</center>

+ Select the libraries and click on **Install**.

For more information on the installation of the RedBear libraries,

+ Please refer to the [Libraries Manager](https://github.com/RedBearLab/Blend/blob/master/Docs/LibraryManager.pdf) :octicons-link-external-16: procedure.

For more information on the installation of the RedBear boards,

+ Please refer to the [Blend Installation](https://github.com/RedBearLab/Blend) :octicons-link-external-16: section on the RedBear website.

## Install the RedBear nRF51822 platform for Wiring / Arduino

If you plan to use the RedBear boards on the Wiring / Arduino framework,

+ Download and install the supported versions of the Arduino IDE under the `/Applications` folder, as described in the section [Install the Arduino platform](../../Chapter1/Section4/Arduino) :octicons-link-16:.

+ Launch it.

+ Define the path of the sketchbook folder in the menu **Arduino > Preferences > Sketchbook location**.

+ Avoid spaces in the name and path of the sketchbook folder.

+ Follow the procedure [Install additional boards on Arduino](../../Chapter1/Section4/#install-additional-boards-on-arduino) :octicons-link-16:.

+ Call the **Boards Manager** and check the RedBear nRF51822 platform is listed.

<center>![](img/122-02-420.png)</center>

If the RedBear nRF51822 platform isn't listed on the **Boards Manager**,

+ Open the **Preferences**.

+ Add the following URL on a separate line, as described in section [Add URLs for new boards](../../Chapter1/Section4/#add-urls-for-new-boards) :octicons-link-16:.

```
https://redbearlab.github.io/arduino/package_redbearlab_index.json
```

+ Select the boards and click on **Install**.

For more information on the installation of the RedBear boards,

+ Please refer to [Install nRF51822 Arduino Add-on](https://github.com/RedBearLab/nRF51822-Arduino/) :octicons-link-external-16: on the RedBear website.

The RedBear boards based on the nRF51822 can run with the Arduino framework as well as with the mbed framework. However, once used on mbed mode, the boot-loader required by Arduino is no longer available and needs to be restored.

+ Please refer to the section [Restore Arduino Mode on RedBear Boards](../../Legacy/Section4/#restore-arduino-mode-on-redbear-boards) :octicons-link-16:.

The process also installs the library in charge of Bluetooth Low Energy. For more information on the use of the RedBear boards,

+ Please refer to the [Getting Started with nRF51822](http://redbearlab.com/getting-started-nrf51822/) :octicons-link-external-16: page on the RedBear website.

## Connect the nRF51822-based board

The RedBear boards are under the menu **Tools > Board**.

<center>![](img/124-01-420.png)</center>

## Install the RedBear nRF52832 boards

:octicons-plus-circle-16: This section requires the embedXcode+ edition.

If you plan to use the RedBear nRF52832 boards on the Wiring / Arduino framework, the installation process includes three elements: the Arduino IDE, the DFU utility and the BLE stack.

For more information on the RedBear nRF52832 installation,

+ Please refer to [Getting Started - RedBear nRF52832](https://github.com/redbear/nRF5x/tree/master/nRF52832#getting-started) :octicons-link-external-16: page on the RedBear website.

To install the Wiring / Arduino framework,

+ Download and install the supported versions of the Arduino IDE under the `/Applications` folder, as described in the section [Install the Arduino platform](../../Chapter1/Section4/Arduino) :octicons-link-16:.

+ Launch it.

+ Define the path of the sketchbook folder in the menu **Arduino > Preferences > Sketchbook location**.

+ Avoid spaces in the name and path of the sketchbook folder.

+ Follow the procedure [Install additional boards on Arduino](../../Chapter1/Section4/#install-additional-boards-on-arduino) :octicons-link-16:.

+ Call the **Boards Manager** and check the RedBear nRF52832 platform is listed.

<center>![](img/125-01-420.png)</center>

If the RedBear nRF52832 platform isn't listed on the **Boards Manager**,

+ Open the **Preferences**.

+ Add the following URL on a separate line, as described in section [Add URLs for new boards](../../Chapter1/Section4/#add-urls-for-new-boards) :octicons-link-16:.

```
https://redbear.github.io/arduino/package_redbear_nRF5x_index.json
```

+ Select the boards and click on **Install**.

For more information on the installation of the RedBear boards,

+ Please refer to [nRF52 - Arduino Installation Guide](https://github.com/redbear/nRF5x/blob/master/docs/Arduino_Board_Package_Installation_Guide.md) :octicons-link-external-16: page on the RedBear website.

## Install the RedBear Duo board

:octicons-plus-circle-16: This section requires the embedXcode+ edition.

If you plan to use the RedBear Duo board on the Wiring / Arduino framework, the installation process includes three elements: the Arduino IDE, the DFU utility and the BLE stack.

For more information on the RedBear Duo installation,

+ Please refer to the [Getting Started - RedBear Duo](https://github.com/redbear/Duo/blob/master/docs/getting_started.md) :octicons-link-external-16: page on the RedBear website.

+ Please refer to the [Getting Started with Particle Build](https://github.com/redbear/Duo/blob/master/docs/getting_started_with_particle_build.md) :octicons-link-external-16: page on the RedBear GitHub repository.

+ For the colour codes of the RGB LED, please refer to the [Status LED](https://docs.particle.io/tutorials/device-os/led/photon/#safe-mode) :octicons-link-external-16: page on the Particle website.

To install the Wiring / Arduino framework,

+ Download and install the supported versions of the Arduino IDE under the `/Applications` folder, as described in the section [Install the Arduino platform](../../Chapter1/Section4/Arduino) :octicons-link-16:.

+ Launch it.

+ Define the path of the sketchbook folder in the menu **Arduino > Preferences > Sketchbook location**.

+ Avoid spaces in the name and path of the sketchbook folder.

+ Follow the procedure [Install additional boards on Arduino](../../Chapter1/Section4/#install-additional-boards-on-arduino) :octicons-link-16:.

+ Call the **Boards Manager** and check the RedBear Duo platform is listed.

<center>![](img/126-01-420.png)</center>

If the RedBear Duo platform isn't listed on the **Boards Manager**,

+ Open the **Preferences**.

+ Add the following URL on a separate line, as described in section [Add URLs for new boards](../../Chapter1/Section4/#add-urls-for-new-boards) :octicons-link-16:.

```
https://redbear.github.io/arduino/package_redbear_index.json
https://redbearlab.github.io/arduino/package_redbear_index.json
```

+ Select the boards and click on **Install**.

For more information on the installation of the RedBear boards,

+ Please refer to [Setup Arduino IDE](https://github.com/redbear/STM32-Arduino) :octicons-link-external-16: page on the RedBear website.

The Arduino IDE conflicts with the GCC tool-chain installed for the RedBear Duo board. The Arduino IDE looks for any GCC tool-chain, and uses the RedBear's instead of the Arduino's.

+ Rename the folder `~/Library/Arduino15/packages/RedBear/tools/arm-none-eabi-gcc` to `~/Library/Arduino15/packages/RedBear/tools/arm-none-eabi-gcc-redbear`.

+ Edit `~/Library/Arduino15/packages/RedBear/hardware/STM32F2/0.2.7/platform.txt`.

+ Change line 8 from

```
compiler.path={runtime.tools.arm-none-eabi-gcc-4.9-2015-q3.path}/bin/
```

to

```
compiler.path={runtime.tools.arm-none-eabi-gcc-redbear-4.9-2015-q3.path}/bin/
```

For more information,

+ Please refer to [Arduino Zero &ndash; RedBear Duo Conflict](http://discuss.redbear.cc/t/arduino-zero-redbear-duo-conflict/274) :octicons-link-external-16: page on the RedBear forum and the [Arduino 1.6.8 IDE &ndash; Arduino Zero / RedBear Duo Conflict](http://forum.arduino.cc/index.php?topic=391429.msg2698429#msg2698429) :octicons-link-external-16: on the Arduino forum.

To install the uploader `dfu-util`,

+ Open a **Terminal** window.

+ Launch the following command to install **Homebrew**, if it isn't already available.

``` bash
$ /usr/bin/ruby -e "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/master/install)"
```

+ Run the installation of **dfu-util**.

``` bash
$ brew install dfu-util
```

+ Check the installation in the `/usr/local/bin` folder.

``` bash
$ ls /usr/local/bin/dfu*
```

For more information,

+ Please refer to the [DFU Installation Guide](https://github.com/redbear/Duo/blob/master/docs/dfu.md) :octicons-link-external-16: page on the RedBear website.

The RedBear Duo uses the BTstack by [BlueKitchen](http://bluekitchen-gmbh.com/) :octicons-link-external-16: for Bluetooth Low Energy. To install it,

+ Please refer to the [BTstack by BlueKitchen](https://github.com/bluekitchen/btstack) :octicons-link-external-16: page on the BlueKitchen website.

## Connect the RedBear Duo board

The RedBear boards are under the menu **Tools > Board**.

<center>![](img/127-01-420.png)</center>

## Install the RedBear CC3200 Platform for Energia

As for the LaunchPad CC3200, analog inputs are limited to 1,5 V and digital inputs are not 5 V-tolerant. Higher voltages may damage the MCU.

If you plan to use the RedBear boards based on the CC3200 with the Energia IDE, follow the procedure Install the LaunchPad platform.

+ Download and install the Energia IDE release 0101E0017 under the `/Applications` folder.

Energia release 0101E0017 supports the RedBear CC3200-based boards natively, with two frameworks: Energia and Energia Multi Tasking.

+ Launch the Energia IDE.

+ Define the path of the sketchbook folder in the menu **Arduino > Preferences > Sketchbook location**.

+ Connect the CC3200-based board.

The RedBear boards are under the menu **Tools > Board**.

<center>![](img/128-01-420.png)</center>

The RedBear CC3200 and RedBear WiFi mini support two frameworks: Energia and Energia MT based on TI-RTOS.

:octicons-plus-circle-16: The embedXcode+ edition allows to locate the Energia IDE in another folder.

+ Please refer to the section [Set the folder for standard IDEs](../../Chapter1/Section3/#set-the-folder-for-standard-ides) :octicons-link-16:.

# Upload to RedBear CC3200 boards

:octicons-plus-circle-16: This section requires the embedXcode+ edition.

![](img/Logo-064-RedBearLab-no-brand.png) The RedBear CC3200 boards require a specific upload procedure.

Proceed as follow:

+ Plug the RedBear CC3200 board.

+ Launch any of the targets **All**, **Upload** or :octicons-plus-circle-16: **Fast**.

After the upload, a window asks you to press on the button on the board to reset the board.

<center>![](img/361-01-360.png)</center>

+ Press the `RESET` button on the RedBear CC3200 board.

<center>![](img/361-02-420.png)</center>

+ Click **OK** on the message window.

# Upload to RedBear Duo board

:octicons-plus-circle-16: This section requires the embedXcode+ edition.

![](img/Logo-064-RedBearLab-no-brand.png) The RedBear Duo board offers different options for uploading the sketch to the board.

## Upload to RedBear Duo through native USB port

Proceed as follow:

+ Connect the RedBear Duo board to the computer.

+ Select the `RedBear Duo (Native USB Port)` board.

+ Launch any of the targets **All**, **Upload** or :octicons-plus-circle-16: **Fast**.

The serial console uses the Serial port.

## Upload to RedBear Duo through RBLink USB port

Proceed as follow:

+ Place the RedBear Duo board onto the RBLink module.

+ Connect the RedBear RBLink module to the computer.

A new volume called `RBLink` appears.

<center>![](img/365-01-100.png)</center>

+ Select the `RedBear Duo (RBLink USB Port)` board.

+ Launch any of the targets **All**, **Upload** or :octicons-plus-circle-16: **Fast**.

A window may ask for allowing incoming network connections.

<center>![](img/365-02-360.png)</center>

+ Click on **Allow** to proceed.

When disconnecting the RBLink board, a warning notification may appear.

<center>![](img/366-01-360.png)</center>

+ Click on **Close** to close the notification.

A safer way consist on ejecting the volume first.

The serial console uses the `Serial1` port.

## Upload to RedBear Duo through WiFi

To upload a compiled sketch using the Particle Cloud,

Be sure the RedBear Duo has been claimed and configured as described in the [Install the Particle platform](../../Legacy/Section4/Page15) :octicons-link-16: procedure.

+ Power the RedBear Duo board.

+ Check the RedBear Duo is connected to the Particle Cloud with the LED breathing cyan.

+ Optionally, open a **Terminal** window and list the boards available.

``` bash
$ particle list
```

+ Check your board is online.

```
Checking with the cloud...
Retrieving cores... (this might take a few seconds)
myDuo (aabbccddeeffaabbccddeeff) is online
```

+ Select the `RedBear Duo (WiFi)` board.

+ Launch any of the targets **All**, **Upload** or :octicons-plus-circle-16: **Fast**.

The upload may take a while, with the LED blinking magenta then green, and finally breathing cyan.

# Restore Arduino mode on RedBear boards

![](img/Logo-064-RedBearLab-no-brand.png) The RedBear boards run on the Arduino framework as well as on the mbed framework.

However, once the boards have been used in mbed mode, the boot-loader required by Arduino is no longer available. It needs to be restored.

To do so,

+ Plug the board in.

+ The RedBear board appears as a new volume called `MBED`.

<center>![](img/384-01-300.png)</center>

+ Open the **Finder** and navigate to the folder `~/Library/Arduino15/packages/RedBearLab/hardware/nRF51822`, and select the folder with the most recent version, for example `1.0.0`.

+ Open the boot-loaders folder.

<center>![](img/384-02-260.png)</center>

+ Copy the `bootloader.hex` file and paste it into the `mbed` disk.

+ Alternatively, download the from the [nRF51822 for Arduino repository](https://github.com/RedBearLab/nRF51822-Arduino) :octicons-link-external-16:.

Arduino sketches can now be uploaded again to the board.

For more information,

+ Please refer to the procedure described on the [RedBear help portal](https://redbearlab.zendesk.com/entries/71376925-Please-help-cannot-install-nRF51822-Arduino-Add-on-on-Mac-Yosemite-) :octicons-link-external-16:.

## Visit the official websites

![](img/Logo-064-RedBearLab-no-brand.png)| **RedBear**
:---- | ----
IDE | Arduino with Boards Manager
Website | <http://redbearlab.com> :octicons-link-external-16:
Download | <https://github.com/redbearlab> :octicons-link-external-16:
Wiki | <http://redbearlab.com/getting-started-nrf51822> :octicons-link-external-16: and <https://github.com/redbear/Duo/blob/master/docs/getting_started.md> :octicons-link-external-16:
Forum | [https://redbearlab.zendesk.com/home](http://discuss.redbear.cc) :octicons-link-external-16:

