---
tags:
    - On hold
---

<style>
.md-typeset h1, .md-typeset h2, .md-typeset h3 { color: #757575; }
</style>

# Install the Maple platform

:octicons-plus-circle-16: This section requires the embedXcode+ edition.

![](img/Logo-064-Maple.png) The MapleIDE is no longer maintained. Use instead the STM32duino boards package compatible with the Arduino 1.6.5 **Boards Manager**.

+ Please refer to the [Install the STM32duino platform](../../Chapter1/Section4/#install-the-stm32duino-platform) :octicons-link-16: section.

If you plan to use the Maple boards,

+ Download and install MapleIDE 0.0.12 under the `/Applications` folder.

+ Launch it.

<center>![](img/605-01-400.png)</center>

+ Define the path of the sketchbook folder in the menu **MapleIDE > Preferences > Sketchbook location**.

+ Avoid spaces in the name and path of the sketchbook folder.

+ Install Java 6.

The MapleIDE requires Java 6. If it isn't available, an error message suggests to install it.

<center>![](img/605-02-360.png)</center>

+ Click on **More Info...** or go to [Download Java for OS X 2015-001](https://support.apple.com/kb/DL1572) :octicons-link-external-16: on the Apple website.

+ Download and install the `javaforosx.dmg` package.

+ Relaunch **MapleIDE**.

## Install the Uploader Utility

Uploading a compiled sketch to the Maple board requires the utility **PySerial**.

To install PySerial,

<center>![](img/606-01-120.png)</center>

+ Download [pyserial 2.6](http://pypi.python.org/pypi/pyserial) :octicons-link-external-16:.

+ Unzip it, for example in `~/Downloads/pyserial-2.6`.

+ Open a **Terminal** window and launch the following commands, with `~/Downloads/pyserial-2.6` being the path to `pyserial-2.6` in the example.

``` bash
$ cd ~/Downloads/pyserial-2.6
$ sudo su
$ python setup.py install
```

## Define integer standard types

Maple only knows `[u]int{8|16|32|64}` types and ignores the C99 standard `[u]int{8|16|32|64}_t` types.

If you plan to use libraries designed for another platform and want to ensure C99 compatibility,

+ Open the `/Applications/MapleIDE.app/Contents/Resources/Java/hardware/leaflabs/cores/maple/libmaple_types.h` file.

+ Add this `#include` to the `libmaple_types.h` file, although `stdint.h` defines other types.

``` c
#include <stdint.h>
```

As an alternative,

+ Open the `/Applications/MapleIDE.app/Contents/Resources/Java/hardware/leaflabs/cores/maple/libmaple_types.h` file.

+ And add the definitions for the `[u]int{8|16|32|64}_t` types.

``` c
// Added C99 Standard Types
#define uint8_t uint8
#define uint16_t uint16
#define uint32_t uint32
#define uint64_t uint64
#define int8_t int8
#define int16_t int16
#define int32_t int32
#define int64_t int64
```

The Maple environment misses two important libraries: `strings.h` and `stream.h`.

Support for Maple is put on hold until a new version of the IDE or new boards are released.

:octicons-plus-circle-16: The embedXcode+ edition allows to locate the Maple IDE in another folder.

+ Please refer to the section [Set the folder for standard IDEs](../../Chapter1/Section3/#set-the-folder-for-standard-ides) :octicons-link-16:.

The STM32duino platform provides a viable alternative solution for the Maple boards.

+ Please refer to section [Install the STM32duino platform](../../Chapter1/Section4/#install-the-stm32duino-platform) :octicons-link-16:.

## Visit the official websites

![](img/Logo-064-Maple.png) | **Maple**
---- | ----
IDE | MapleIDE
Website | <http://leaflabs.com/devices/> :octicons-link-external-16:
Download | <http://leaflabs.com/docs/download.html> :octicons-link-external-16:
Wiki | <http://wiki.leaflabs.com/index.php> :octicons-link-external-16:
Forum | <http://forums.leaflabs.com> :octicons-link-external-16:
