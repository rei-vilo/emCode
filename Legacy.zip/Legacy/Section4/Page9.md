---
tags:
    - Discontinued
---

<style>
.md-typeset h1, .md-typeset h2, .md-typeset h3 { color: #757575; }
</style>

# Install boards from previous releases of Energia

![](img/Logo-064-Launchpad.png) Although **Energia 1.6.10E18** no longer supports the C2000 LaunchPad platform and the CC2650 SensorTag, the corresponding files can be migrated from the previous release 0101E0017 of Energia.

+ Proceed with [Install Energia 0101E0017 IDE](../../Legacy/Section4/#install-energia-0101e0017-ide) :octicons-link-16:.

+ For the C2000 LaunchPad boards, follow the procedures [Install the LaunchPad C2000 boards](../../Legacy/Section4/#install-the-launchpad-c2000-boards) :octicons-link-16: and [Migrate the LaunchPad C2000 Boards to Energia 18](../../Legacy/Section4/#migrate-the-launchpad-c2000-boards-to-energia-18) :octicons-link-16:.

+ For the CC2650 SensorTag, follow the procedure [Migrate the CC2650 SensorTag to Energia 18](../../Legacy/Section4/#migrate-the-cc2650-sensortag-to-energia-18) :octicons-link-16:.

Similarly, Energia 12 builds a more compact code than Energia 1.6.10E18 against the MSP430G2 boards. This is especially relevant for the MSP430G2553 MCU with only 512 bytes of RAM.

+ Proceed with [Install Energia 0101E0012 IDE](../../Legacy/Section4/#install-energia-0101e0012-ide) :octicons-link-16:.

+ Follow the procedure [Migrate Previous MSP430 Board Package to Energia 18](../../Legacy/Section4/#migrate-previous-msp430-board-package-to-energia-18) :octicons-link-16:.

## Install Energia 0101E0017 IDE

If you plan to use the C2000 LaunchPad or the CC2650 SensorTag,

+ Download and install Energia release 0101E0017 under the `/Applications` folder. Energia is the official IDE for the LaunchPad platform.

<center>![](img/087-01-400.png)</center>

+ Rename `Energia` as `Energia-17.app` to avoid any conflict with the current release of Energia.

+ Launch it.

+ Define the path of the sketchbook folder in the menu **Energia > Preferences > Sketchbook location**.

+ Avoid spaces in the name and path of the sketchbook folder.

<center>![](img/088-01-420.png)</center>

In this example, the sketchbook folder is `/User/ReiVilo/Documents/Projects/Energia`.

For more information on installing Energia,

+ Please refer to the [Energia Quick Start Guide](http://energia.nu/guide/) :octicons-link-external-16:.

Some LaunchPad boards may require the installation of additional tools or the update of the firmware.

Energia manages three architectures: 16-bit MSP430, 16-bit C2000 and 32-bit ARM.

## Install the LaunchPad C2000 boards

If you plan to use the LaunchPad C2000 F28027, F28069 and F28377 boards, you need to install the specific tool-chain.

+ Download Energia release 0101E0017 and install it.

+ Go to the page [Code Generation Tools for Texas Instruments Processors](http://software-dl.ti.com/codegen/non-esd/downloads/download.htm#C2000) :octicons-link-external-16:.

There are two versions of the tools with different licences.

+ Locate the registration-free short-term support v15.3.0.STS C2000 Code Generation Tools section and then select the version for Mac OS X.

+ Download and unzip `ti_cgt_c2000_15.3.0_osx_installer.zip`.

<center>![](img/088-02-240.png)</center>

+ Launch the `ti_cgt_c2000_15.3.0_osx_installer`.

<center>![](img/089-01-420.png)</center>

+ Follow the instructions and note the destination directory.

With macOS 10.13, launching the installer may display the following error message.

<center>![](img/089-02-360.png)</center>

+ Select `ti_cgt_c2000_18.1.0.LTS_osx_installer` in the `Downloads` folder.

+ Call the contextual menu **Show Package Content**.

+ Navigate to sub-folders `Contents` then `MacOS`.

+ Open a **Terminal** window.

+ Drag-and-drop `osx-intel` into the **Terminal** window and press ++enter++.

+ Follow the instructions and note the destination directory.

<center>![](img/089-03-420.png)</center>

As an alternative,

+ Locate the `C2000 Code Generation Tools v6.4.2` section and then select the version for Mac OS X.

+ Go though the registration process. Once the registration is approved, proceed with the download.

+ Open a **Terminal** window and change the directory to where the downloaded file is located.

``` bash
$ cd ~/Downloads
```

+ Change the authorisation of the downloaded file to make it executable.

``` bash
$ sudo chmod +X ti_cgt_c2000_6.4.3_mac_installer.sh
```

+ Launch the installer.

``` bash
$ ./ti_cgt_c2000_6.4.3_mac_installer.sh
```

Once the licence agreement is accepted, the installer unzips the file and creates the folder `c2000_6.4.3`.

Once the C2000 Code Generation Tools are installed,

+ Open the `/Applications` folder and find the Energia-17 application.

+ Select the Energia icon, call the contextual menu and select **Show Package Content**.

<center>![](img/090-01-220.png)</center>

+ Navigate to the `Energia-17.app/Contents/Resources/Java/hardware/tools` folder.

+ Copy the `ti-cgt-c2000_15.3.0` folder or the `c2000_6.4.3` folder and paste it under the tools folder to obtain `Contents/Resources/Java/hardware/tools/ti-cgt-c2000_15.3.0` or `Contents/Resources/Java/hardware/tools/c2000_6.4.3`.

+ Change the name of the `ti-cgt-c2000_15.3.0` folder or the `c2000_6.4.3` folder for `c2000`.

+ Launch Energia and check that the LaunchPad (C2000) with TMS320F28027 (60MHz) board and the board appear on the menu **Tools > Boards**.

<center>![](img/090-02-420.png)</center>

!!! note
    Due to the partial compatibility of the C2000 Code Generation Tools with GCC, some features as click-to-error, warning messages and debugging are not available.

## Migrate the LaunchPad C2000 boards to Energia 18

To migrate the C2000 platform from Energia 17 to Energia 1.6.10E18,

+ Open a **Terminal** window.

+ Create the target folders.

``` bash
$ mkdir -p ~/Library/Energia15/packages/energia/hardware/c2000/0.9.0

$ mkdir -p ~/Library/Energia15/packages/energia/tools/c2000/15.3.0
```

+ Copy the folders into the new ones

``` bash
$ cp -R /Applications/Energia-17.app/Contents/Resources/Java/hardware/c2000/* ~/Library/Energia15/packages/energia/hardware/c2000/0.9.0/

$ cp -R /Applications/Energia-17.app/Contents/Resources/Java/hardware/tools/c2000/*

~/Library/Energia15/packages/energia/tools/c2000/15.3.0
```

The `Energia-17.app` application refers to the Energia 17 IDE.

!!! warning
    The **Energia 1.6.10E18** IDE does not officially support the C2000 platform.

## Migrate the CC2650 SensorTag to Energia 18

To migrate the CC2650 SensorTag from Energia 17 to **Energia 1.6.10E18**,

+ Open a **Terminal** window.

+ Create the target folder.

``` bash
$ mkdir -p /Library/Energia15/packages/energia/hardware/cc26xx/0.9.0/system/
```

+ Copy the folders into the new ones.

``` bash
$ cp -R /Applications/IDE/Energia-17.app/Contents/Resources/Java/hardware/cc2600emt/* /Library/Energia15/packages/energia/hardware/cc26xx/0.9.0/

$ cp -R /Applications/IDE/Energia-17.app/Contents/Resources/Java/hardware/emt/* /Library/Energia15/packages/energia/hardware/cc26xx/0.9.0/system/
```

The `Energia-17.app` application refers to the Energia 17 IDE.

!!! warning
    The **Energia 1.6.10E18** IDE does not officially support the CC2650 SensorTag.

## Install Energia 0101E0012 IDE

If you plan to use the MSP430 board package from Energia 12,

+ Download release 12 from the [Energia Download](http://energia.nu/download/) page :octicons-link-external-16: and install it.

<center>![](img/092-01-360.png)</center>

+ Rename `Energia` as `Energia-12.app` to avoid any conflict with the current release of Energia.

+ Launch it.

+ Define the path of the sketchbook folder in the menu **Energia > Preferences > Sketchbook location**.

## Migrate previous MSP430 board package to Energia 18

To migrate the MSP430 platform from Energia 12 to **Energia 1.6.10E18**,

+ Open a **Terminal** window.

+ Create the target folder.

``` bash
$ mkdir -p ~/Library/Energia15/packages/energia/hardware/msp430/0.1.2
```

+ Copy the folder into the new one.

``` bash
$ cp -R /Applications/Energia-12.app/Contents/Resources/Java/hardware/msp430/* ~/Library/Energia15/packages/energia/hardware/msp430/0.1.2/
```

+ Use the `LaunchPad MSP430G2553 (compact)` board.

The `Energia-12.app` application refers to the Energia 12 IDE.

!!! warning
    The **Energia 1.6.10E18** IDE does not officially support the previous MSP430 boards package.

## Visit the official websites
