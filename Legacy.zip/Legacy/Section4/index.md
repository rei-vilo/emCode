<style>
.md-typeset h1, .md-typeset h2, .md-typeset h3 { color: #757575; }
</style>

# Use discontinued Wiring / Arduino frameworks

Some boards and platforms running on the Wiring / Arduino framework are deprecated and no longer supported by their manufacturers.

The legacy boards are still available on release 8.0, and a warning message is displayed during build.

<center>![](img/582-01-360.png)</center>

Release 8.0 of embedXcode is adapted accordingly. Release 9.0 no longer features those boards.

## Select your platform

. | . | . | . | . | .
:----: | :----: | :----: | :----: | :----: | :----:
![](img/Logo-064-ArduCAM.png) | ![](img/Logo-064-chipKIT.png) | ![](img/Logo-064-4D-Systems.png) | ![](img/Logo-064-Cosa.png) | ![](img/Logo-064-Digistump-3.png) | ![](img/Logo-064-ftDuino.png)
[ArduCAM](../../Legacy/Section4/Page1) :octicons-link-16: | [chipKIT](../../Legacy/Section4/Page2) :octicons-link-16: | [4D Systems](../../Legacy/Section4/Page3) :octicons-link-16: | [Cosa](../../Legacy/Section6/#install-the-cosa-framework) :octicons-link-16: | [Digistump](../../Legacy/Section4/Page5) :octicons-link-16: | [ftduino](../../Legacy/Section4/Page7) :octicons-link-16:
![](img/Logo-064-Glowdeck.png) | ![](img/Logo-064-Intel-IDE.png) | ![](img/Logo-064-Yocto-white.png) | ![](img/Logo-064-Intel-MCU-SDK.png) | ![](img/Logo-064-Launchpad.png) | ![](img/Logo-064-LightBlue.png)
[Glowdeck](../../Legacy/Section4/Page6) :octicons-link-16: | [Intel](../../Legacy/Section4/#install-the-intel-platform_1) :octicons-link-16: | [Yocto](../../Legacy/Section4/Page8) :octicons-link-16: | [MCU SDK](../../Legacy/Section4/Page8) :octicons-link-16: | [LaunchPad](../../Legacy/Section4/Page6) :octicons-link-16: | [LightBlue](../../Legacy/Section4/Page4) :octicons-link-16:
![](img/Logo-064-Little-Robot-Friend.png) | ![](img/Logo-064-Maple.png) | ![](img/Logo-064-LinkIt.png) | ![](img/Logo-064-Microduino.png) | ![](img/Logo-064-panStamp.png) | ![](img/Logo-064-Spark.png)
[Little Robot Friends](../../Legacy/Section4/Page10) :octicons-link-16: | [Maple](../../Legacy/Section4/Page11) :octicons-link-16: | [MediaTek](../../Legacy/Section4/Page12) :octicons-link-16: | [Microduino](../../Legacy/Section4/Page13) :octicons-link-16: | [panStamp](../../Legacy/Section4/Page14) :octicons-link-16: | [Particle](../../Legacy/Section4/Page15) :octicons-link-16:
![](img/Logo-064-RedBearLab-no-brand.png) | ![](img/Logo-064-RFduino.png) | ![](img/Logo-064-Robotis.png) | ![](img/Logo-064-Simblee.png) | ![](img/Logo-064-TinyCircuits.png) | ![](img/Logo-064-UDOO.png)
[RedBear](../../Legacy/Section4/Page16) :octicons-link-16: | [RFduino](../../Legacy/Section4/Page17) :octicons-link-16: | [Robotis](../../Legacy/Section4/Page18) :octicons-link-16: | [Simblee](../../Legacy/Section4/Page19) :octicons-link-16: | [TinyCircuits](../../Legacy/Section4/Page21) :octicons-link-16: | [Udoo Neo](../../Legacy/Section4/Page22) :octicons-link-16:
![](img/Logo-064-Wiring.png) | | | | |
[Wiring](../../Legacy/Section4/Page23) :octicons-link-16: | | | | |

## Visit the official websites

The following section lists the tools for the boards relying on the Wiring / Arduino framework and for which support has been discontinued.

![](img/Logo-064-Protostack.png) | **Protostack**
---- | ----
Website | <http://www.protostack.com> :octicons-link-external-16:

