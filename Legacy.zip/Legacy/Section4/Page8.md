---
tags:
    - Discontinued
---

<style>
.md-typeset h1, .md-typeset h2, .md-typeset h3 { color: #757575; }
</style>

# Install the Intel platform

:octicons-plus-circle-16: This section requires the embedXcode+ edition.

![](img/Logo-064-Intel-IDE.png) The Intel platform includes the Curie, Galileo, Galileo Gen 2 and Edison boards. Those boards support the Wiring / Arduino framework. The installation for the Wiring / Arduino framework is performed with the **Boards Manager** on the Arduino 1.6 IDE.

:octicons-plus-circle-16: The embedXcode+ edition also supports the Yocto SDK and the MCU SDK for the Edison board.

!!! info
	Intel has announced it will stop supporting all its boards, including the Galileo, Edison and Curie boards, starting mid-December 2017.

## Install the Intel platform

If you plan to use the Intel Galileo and Edison boards,

+ Download and install the supported versions of the Arduino IDE under the `/Applications` folder, as described in the section [Install the Arduino platform](../../Chapter1/Section4/Arduino) :octicons-link-16:.

+ Launch it.

+ Define the path of the sketchbook folder in the menu **Arduino > Preferences > Sketchbook location**.

+ Avoid spaces in the name and path of the sketchbook folder.

+ Follow the procedure [Install additional boards on Arduino](../../Chapter1/Section4/#install-additional-boards-on-arduino) :octicons-link-16:.

+ Call the **Boards Manager** and check the two Intel platforms are listed.

<center>![](img/596-01-420.png)</center>

+ Select the boards and click on **Install**.

For more information on the installation process,

+ Please refer to the [Getting Started](https://communities.intel.com/docs/DOC-21838) :octicons-link-external-16: page on the Intel website.
+ Connect and Disconnect the Board

The Intel boards appears under the menu **Tools > Board**.

<center>![](img/598-01-420.png)</center>

Contrary to other boards, the Intel Galileo is not powered through USB.

+ First, always connect the power supply to power the board.

+ Then, check the `Power LED` is on.

+ Finally, connect the board to the computer through USB.

## Power the Intel Galileo

Powering the board directly through USB may damage the board.

Also, there are two versions of the Intel Galileo board, each one with different power requirements, alas incompatible.

For more information,

+ Please refer to [Power Supplies Are Not Interchangeable for Boards and Kits](http://www.intel.com/content/www/us/en/support/boards-and-kits/intel-galileo-boards/000006355.html) :octicons-link-external-16:.

## Power the Intel Edison breakout board

For the Intel Edison Breakout Board, powering the board through USB is possible.

<center>![](img/599-01-420.png)</center>
<center>*Intel Edison on mini breakout board*</center>

Connector ➀ is for power, OTG and uploading Arduino sketches over USB.

Connector ➁ is for serial over USB.

+ Always connect power first to the jack barrel or to connector ➀.

However, an external direct current power supply is recommended. For more information,

+ Please refer to [Powering your Board over USB](https://software.intel.com/en-us/appendix-connectors-on-the-intel-edison-board#powering_your_board) :octicons-link-external-16:.

## Power the Intel Edison Arduino board

The Intel Edison Arduino Board features a separate USB for OTG.

<center>![](img/599-02-420.png)</center>
<center>*Intel Edison on Arduino expansion board*</center>

Connector ➀ is for power, Ethernet over USB and uploading Arduino sketches over USB. Move the switch in device mode position, close to connector ➀.

Connector ➁ is for serial over USB.

Connector ➂ provides OTG. Move the switch in host mode position, close to connector ➂.

+ Always connect power first to the jack barrel or to connector  .

## Plug and unplug the Intel Edison board

When plugged-in, the Intel board appears as a new volume called `EDISON`.

<center>![](img/600-01-300.png)</center>

In that case, it is recommended to unmount the volume before disconnecting the board, otherwise the following message pops-up.

<center>![](img/600-01-360.png)</center>

## Install the Intel Edison for Yocto SDK

![](img/Logo-064-Yocto-alpha.png) :octicons-plus-circle-16: The embedXcode+ edition also supports the Yocto SDK for the Edison board.

+ Find the corresponding procedure at sections [Install the Edison SDKs Automatically](../../Legacy/Section5/#install-the-edison-sdks-automatically) :octicons-link-16: and [Install the Yocto SDK for Intel Edison](../../Legacy/Section5/#install-the-edison-yocto-sdk-manually) :octicons-link-16:.

## Install the Intel Edison for MCU SDK

![](img/Logo-064-Edison-MCU.png) :octicons-plus-circle-16: The embedXcode+ edition also supports the MCU SDK for the Edison board.

+ Find the corresponding procedure at sections [Install the Edison SDKs Automatically](../../Legacy/Section5/#install-the-edison-sdks-automatically) :octicons-link-16: and [Install the Edison MCU SDK Manually](../../Legacy/Section5/#install-the-edison-mcu-sdk-manually) :octicons-link-16:.

# Upload to Intel Edison using WiFi or Ethernet over USB

:octicons-plus-circle-16: This section requires the embedXcode+ edition.

![](img/Logo-064-Intel-IDE.png) Although the Intel Edison board requires no specific procedure, the Ethernet or WiFi network needs to be installed and configured successfully before any upload, and the RSA key fingerprint of the Intel Edison needs to be known by the Mac.

Before uploading, please

+ Check that the router has discovered the Intel Edison and note the IP address.

+ Check the Mac knows the RSA key fingerprint of the Intel Edison.

+ Also, keep the password of the Intel Edison at hand.

It is recommended to proceed with a test of the over-the-air connection through Ethernet or WiFi. Either try establishing a SSH connection on the **Terminal**, or uploading a sketch from the Arduino IDE, to be sure that the Mac recognises the board and knows the RSA key fingerprint of the Intel Edison board.

## Check the SSH connection

The `cu.usbmodem` port gives a limited access and the `cu.usbserial` port provides full access but requires to plug-in the second USB cable.

``` bash
$ ls /dev/cu.*
/dev/cu.usbmodem1413
/dev/cu.usbserial-A123B456
```

For full access, use instead either WiFi or Ethernet over USB. For more information on how to install WiFi and Ethernet over USB,

+ Please refer to the section [Install the Intel platform](../../Legacy/Section4/#install-the-intel-platform_1) :octicons-link-16:.

To identify the IP addresses of the Intel Edison board,

+ Open a **Terminal** window.

+ Run the following command.

``` bash
$ arp -a
host-001 (192.168.1.223) at aa:bb:cc:dd:ee:ff on en0 ifscope [ethernet]
edison (192.168.2.15) at 11:22:33:44:55:66 on en8 ifscope [ethernet]
```

The three addresses, `192.168.1.223`, `192.168.2.15` and `edison.local` give access to the board with ssh.

+ Connect to the board using ssh.

``` bash
$ ssh root@192.168.1.223
$ ssh root@edison.local
$ ssh root@192.168.2.15
```

If the board is unknown, a message asks for confirmation of the RSA key fingerprint.

```
The authenticity of host '192.168.1.2333 (192.168.1.233)' can't be established.
RSA key fingerprint is 00:11:22:33:44:55:66:77:88:99:aa:bb:cc:dd:ee:ff.
Are you sure you want to continue connecting (yes/no)? yes
```

+ Enter `yes` and validate.

A message confirms the RSA key fingerprint has been added to the list of know hosts.

## Enter IP address and password

During the first compilation, embedXcode looks for the Intel Edison board and checks the password.

If the Intel Edison board isn't found on the network, a window asks for the IP address.

<center>![](img/345-01-360.png)</center>

+ Enter the IP address of the Intel Edison board.

+ Click on **OK** to validate or **Cancel** to cancel.

A message box asks for the password.

<center>![](img/345-02-360.png)</center>

+ Enter the password of the Intel Edison board.

+ Click on **OK** to validate or **Cancel** to cancel.

When validated, the IP address and the password are saved on the board configuration file `Intel Edison (WiFi)` in the project.

<center>![](img/346-01-360.png)</center>

The IP address and the password are only asked once.

+ To erase the IP address, just delete the whole line.

+ To edit the IP address, just change the left part after `SSH_ADDRESS =` on the corresponding line.

!!! warning
    The password is not encrypted.

+ To erase the password, just delete the whole line.

+ To edit the password, just change the left part after `SSH_PASSWORD =` on the corresponding line.

For more information about the Intel Edison installation and over-the-air upload,

+ Please refer to the procedure [Intel(r) Edison Connecting Ethernet over USB](https://software.intel.com/en-us/articles/intel-edison-connecting-ethernet-over-usb) :octicons-link-external-16:.

## Upload Wiring / Arduino sketch

![](img/Logo-064-Intel-IDE.png) Once the checks have been successfully performed, proceed as follow:

+ Connect the Intel Edison board to the network through WiFi or Ethernet over USB.

+ Launch any of the targets **All**, **Upload** or :octicons-plus-circle-16: **Fast**.

## Upload Native Yocto application

![](img/Logo-064-Yocto-alpha.png) Once the checks have been successfully performed, proceed as follow:

+ Connect the Intel Edison board to the network through WiFi or Ethernet over USB.

+ Launch any of the targets **All**, **Upload** or :octicons-plus-circle-16: **Fast**.

## Upload MCU application

![](img/Logo-064-Edison-MCU.png) Once the checks have been successfully performed, proceed as follow:

+ Connect the Intel Edison board to the network through WiFi or Ethernet over USB.

+ Launch any of the targets **All**, **Upload** or :octicons-plus-circle-16: **Fast**.

For applications developed with the MCU SDK and API, the process checks the availability of the configuration tools on the Edison board and, if necessary, uploads them.

Similarly, if a configuration command has been defined in the main `Makefile` as described at the section [Define the settings for Edison MCU](../../Legacy/Section5/#define-the-settings-for-edison-mcu) :octicons-link-16:, the process executes it remotely.

Finally, the process reboots the board to launch the MCU application.

Otherwise, the manual procedure requires to:

+ Open a **Terminal** window and connect to the Edison board.

+ Launch the utility scripts among `init_DIG.sh`, `init_i2c8.sh`, `init_mcu_PWM.sh`, `read_DIG.sh`, `set_DIG.sh` and `init_UART1.sh` with the relevant parameters.

+ For example, to define pin `7` as an output, execute

``` bash
# cd ./utilitiesMCU
# sh init_DIG.sh -o 7 -d output
```

+ Finally, reboot the Intel Edison board with the following command to launch the application:

``` bash
# reboot
```

## Find the location of the Wiring / Arduino sketch

![](img/Logo-064-Intel-IDE.png) Each kind of sketch goes to a specific location.

For sketches developed with the Wiring / Arduino framework, the sketch is renamed `sketch.elf` and uploaded under the `/sketch` folder to obtain `/sketch/sketch.elf`.

The boot process loads and runs this sketch automatically.

+ To terminate the `sketch.elf` sketch, run the following command on the Intel Edison board:

``` bash
# killall -q sketch.elf
```

+ To run again the sketch.elf sketch, run the following command on the Intel Edison board:

``` bash
# /sketch/sketch.elf
```

## Find the location of the Yocto Native application

![](img/Logo-064-Yocto-alpha.png) For native applications running on Yocto, a sub-folder with the name of the project is created under `/home/root/Projects` to obtain `/home/root/Projects/embed1` if `embed1` is the name of the project.

The application is renamed `embeddedcomputing` and uploaded under `/home/root/Projects/embed1` to obtain `/home/root/Projects/embed1/embeddedcomputing`.

+ To terminate the `embeddedcomputing` application, run the following command on the Intel Edison board:

``` bash
# killall -q embeddedcomputing
```

+ To run again the `embeddedcomputing` application, run the following command on the Intel Edison board:

``` bash
# /home/root/Projects/embed1/embeddedcomputing
```

## Find the location of the MCU application

![](img/Logo-064-Edison-MCU.png) For applications developed with the MCU SDK and API, the application is renamed `intel_mcu.bin` and uploaded under the `/lib/firmware` folder to obtain `/lib/firmware/intel_mcu.bin`.

!!! note
    In order to load and run the `intel_mcu.bin` application, the Edison board needs to be rebooted. This is normally done automatically during the upload process.

To reboot the Edison board manually,

+ Run the following command on the Intel Edison board:

``` bash
# reboot
```

To terminate the `intel_mcu.bin` application,

+ Run the following command on the Intel Edison board:

``` bash
# rm /lib/firmware/intel_mcu.bin
# reboot
```

## Eject before disconnecting the board

Before disconnecting the Intel Edison board, it is recommended to unmount the volume, otherwise the following message pops-up.

<center>![](img/349-01-360.png)</center>

It is also recommend to power off the board before disconnecting it.

+ Run the following command on the Intel Edison board:

``` bash
# poweroff
```

## Visit the official websites

![](img/Logo-064-Intel-IDE.png) | **Intel**
---- | ----
IDE | Arduino with Boards Manager
Website | <http://www.intel.com/content/www/us/en/do-it-yourself/maker.html> :octicons-link-external-16:
Galileo | <http://www.intel.com/support/maker/galileo> :octicons-link-external-16:
Edison | <http://www.intel.com/support/maker/edison> :octicons-link-external-16:
Arduino for Intel | <https://communities.intel.com/docs/DOC-22226> :octicons-link-external-16:
Forum | <http://www.intel.com/content/www/us/en/do-it-yourself/forums-and-support.html> :octicons-link-external-16:

