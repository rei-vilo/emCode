---
tags:
    - Discontinued
---

<style>
.md-typeset h1, .md-typeset h2, .md-typeset h3 { color: #757575; }
</style>

# Install the LightBlue platform

:octicons-plus-circle-16: This section requires the embedXcode+ edition.

!!! warning
    In June 2018, Punch Through Design announced it was discontinuing the Bean boards.

![](img/Logo-064-LightBlue.png) The installation of the LightBlue platform includes a plug-in and modifies the Arduino IDE.

## Install the LightBlue plug-in

If you plan to use the LightBlue Bean board by Punch Through Design board:

+ Download and install the supported versions of the Arduino IDE under the `/Applications` folder, as described in the section [Install the Arduino platform](../../Chapter1/Section4/Arduino) :octicons-link-16:. Other releases don't work.

+ Download and launch the [Bean Loader](https://punchthrough.com/bean/docs/guides/getting-started/os-x/#install-bean-loader) :octicons-link-external-16:.

As the IDE for LightBlue boards modifies the Arduino IDE, you may want to have a separate modified Arduino IDE for the LightBlue boards.

+ Change the name to `LightBlueIDE` and the icon to avoid any confusion with the standard Arduino.

+ Download and install the Bean Loader App for OS X plug-in release 1.8.1.

+ Launch it.

<center>![](img/095-01-360.png)</center>

+ Click on **Associate**.

+ Select the Arduino 1.0 or the LightBlueIDE application and click on **Associate**.

embedXcode identifies the IDE automatically among Arduino and LightBlueIDE.

For more information on the installation process,

+ Please refer to the [Getting Started](https://punchthrough.com/bean/docs/guides/getting-started/intro/#get-started) :octicons-link-external-16: page on the LightBlue website.

## Install the Bean Command Line Loader

The **Bean Command Line Loader** is a complement for the **Bean Loader**. It provides a command-line interface that eases automation with embedXcode.

+ Download and install the [node.js package](http://nodejs.org) :octicons-link-external-16:.

The package contains `node.js` and `npm`. `node.js` is a platform for network applications.

<center>![](img/096-01-240.png)</center>

And `npm` is a package manager for node.js.

<center>![](img/096-02-160.png)</center>

+ Open a **Terminal** window.

+ Enter the following command to download the Bean Command Line Loader package.

``` bash
$ sudo npm install -g bean-sdk
```

For more information on the Bean Command Line Loader,

+ Please refer to the [Node.js SDK/CLI](https://punchthrough.com/bean/docs/guides/node-sdk/overview/) :octicons-link-external-16: page on the on the LightBlue website.

## Connect the board

The LightBlue board appears under the menu **Tools > Board**.

<center>![](img/097-01-420.png)</center>

:octicons-plus-circle-16: The embedXcode+ edition allows to locate the LightBlueIDE in another folder.

+ Please refer to the section [Set the folder for standard IDEs](../../Chapter1/Section3/#set-the-folder-for-standard-ides) :octicons-link-16:.

# Upload to LightBlue Bean using Bluetooth

:octicons-plus-circle-16: This section requires the embedXcode+ edition.

![](img/Logo-064-LightBlue.png) The LightBlue Bean offers two options for uploading. The LightBlue Bean Loader requires a manual intervention while the Bean Command Line Loader is fully automatic.

The latter option is enabled automatically when embedXcode+ detects Bean Command Line Loader has been installed and is available.

## Upload with the LightBlue Bean Loader

To upload a sketch to a LightBlue Bean board using Bluetooth:

+ Check Bluetooth 4.0 or BLE is turned on.

+ Launch any of the targets **All**, **Upload** or :octicons-plus-circle-16: **Fast**.

The new application **LightBlue Bean Loader** shows the boards available.

<center>![](img/354-01-420.png)</center>

+ Right-click on the line of the board and select **Connect**.

Once the board is connected,  again and select **Program Sketch**.

<center>![](img/355-01-360.png)</center>

A final message confirms the end of the operation.

<center>![](img/355-02-360.png)</center>

The application **LightBlue Bean Loader** provides other services.

For more information,

+ Please refer to Upload to Bean with [Bean Loader for OS X](https://punchthrough.com/bean/docs/guides/getting-started/os-x/#upload-to-bean) :octicons-link-external-16: page at the Punch Through Design website.

## Upload with the Bean Command Line Loader

If embedXcode+ detects that the **Bean Command Line Loader** is available, it opts for this option automatically

During the first compilation with a **Fast** or **All** target, embedXcode+ scans for LightBlue boards. This process can take up to one minute.

```
---- Scanning for LightBlue boards ---
myBean+
---- LightBlue boards scanned ---
```

In case more than one LightBlue boards are detected, a dialogue box asks to choose among the first two.

<center>![](img/355-03-360.png)</center>

The name of the LightBlue board is saved on the board configuration file `LightBlue Bean (Bluetooth)` or `LightBlue Bean+ (Bluetooth)` in the project.

```
BEAN_NAME = myBean+
```

Once the upload is completed, embedXcode+ opens a **Terminal** window with the serial console of the LightBlue board.

For more information,

+ Please refer to the [Upload Sketch with CLI Loader](https://punchthrough.com/bean/docs/guides/getting-started/cli-loader/#upload-sketch) :octicons-link-external-16: page at the Punch Through Design website.

## Visit the official websites

![](img/Logo-064-LightBlue.png) | **LightBlue**
:---- | ----
IDE | LightBlueIDE
Website | <http://punchthrough.com/bean> :octicons-link-external-16:
Download | <http://punchthrough.com/bean/getting-started> :octicons-link-external-16:
Forum | <http://beantalk.punchthrough.com> :octicons-link-external-16: