---
tags:
    - Discontinued
---

<style>
.md-typeset h1, .md-typeset h2, .md-typeset h3 { color: #757575; }
</style>

# Install the Little Robot Friends platform

:octicons-plus-circle-16: This section requires the embedXcode+ edition.

## Install the Little Robot Friends first generation

![](img/Logo-064-Little-Robot-Friend.png) The Little Robot Friends platform consists on two boards, the robot and the dock. The installation of the Little Robot Friends platform is performed with the **Boards Manager** on the Arduino 1.6 IDE.

With the launch of the second generation of boards, the first generation is no longer supported by Little Robot Friends.

### Install the Little Robot Friends platform

If you plan to use the Little Robot Friends platform,

+ Download and install the supported versions of the Arduino IDE under the `/Applications` folder, as described in the section [Install the Arduino platform](../../Chapter1/Section4/Arduino) :octicons-link-16:.

+ Launch it.

+ Define the path of the sketchbook folder in the menu **Arduino > Preferences > Sketchbook location**.

+ Avoid spaces in the name and path of the sketchbook folder.

+ Follow the procedure [Install additional boards on Arduino](../../Chapter1/Section4/#install-additional-boards-on-arduino) :octicons-link-16:.

+ Call the **Boards Manager** and check the Little Robot Friends platform is listed.

<center>![](img/602-01-420.png)</center>

+ If the Little Robot Friends platform isn't listed on the **Boards Manager**, open the **Preferences** and add one of the following URLs on a separate line, as described in section [Add URLs for new boards](../../Chapter1/Section4/#add-urls-for-new-boards) :octicons-link-16:.

```
http://learn.littlerobotfriends.com/downloads/package_littlerobotfriends_index.json
http://learn.littlerobotfriends.com/downloads/package_littlerobotfriends-beta_index.json
```

+ Select the board and click on **Install**.

For more information on the installation of the Arduino IDE,

+ Please refer to the [Getting Started](http://learn.littlerobotfriends.com/reference/getting_started.html) :octicons-link-external-16: page on the Little Robot Friends website.

### Install the Little Robot Friends library

+ Launch the Arduino IDE.

+ Call the menu **Sketch > Include Library > Manage Libraries...**

<center>![](img/603-01-420.png)</center>

A new window lists all the libraries, already installed or available for download.

+ Search the list for the `LittleRobotFriends` library.

<center>![](img/603-02-420.png)</center>

+ Click on **Install**.

The IDE downloads and installs the library.

+ Click on **OK**.

If the library doesn't show up even after adding the URL with the JSON file,

+ Download the [LittleRobotFriends_for_Arduino15_v1.5.zip](http://learn.littlerobotfriends.com/downloads/current15) :octicons-link-external-16:.

+ Unzip the file.

+ Copy the resulting folder as a user's library on the `Libraries` sub-folder of the sketchbook folder.

The user's libraries are stored on the `Libraries` or `libraries` sub-folder under the sketchbook folder.

For more information on the installation of the Little Robot Friends library for Arduino,

+ Please refer to the [Installation](http://learn.littlerobotfriends.com/reference/installation.html) :octicons-link-external-16: page on the Little Robot Friends website.

### Connect the board

Once installation is completed,

+ Check that the **Tools > Boards** menu on the Arduino IDE mentions the Little Robot Friends board.

<center>![](img/604-01-400.png)</center>

# Install the Little Robot Friends second generation

![](img/Logo-064-Little-Robot-Friend.png) The second generation features one board based on the SAMD MCU. The installation is performed manually and requires the Arduino 1.8 IDE.

+ Download the **LRF Arduino Library** 2.2.0 from the [Downloads](https://learn.littlerobotfriends.com/downloads/) :octicons-link-external-16: page of the Little Robot Friends website.

+ Unzip the file.

+ Create the folder `~/Documents/Projets/Arduino/hardware/lrf_arduino/samd`.

+ Copy the resulting folder under `~/Documents/Projets/Arduino/hardware/lrf_arduino/samd` to obtain `~/Documents/Projets/Arduino/hardware/lrf_arduino/samd/samd`.

+ Rename the last `samd` sub-folder to `2.2.0` to obtain `~/Documents/Projets/Arduino/hardware/lrf_arduino/samd/2.2.0`.

## Visit the official websites

![](img/Logo-064-Little-Robot-Friend.png) | **Little Robot Friends**
---- | ----
IDE | Arduino with Boards Manager
Website | <http://www.littlerobotfriends.com> :octicons-link-external-16:
Download | <http://learn.littlerobotfriends.com/reference/installation.html> :octicons-link-external-16:
Support | <http://learn.littlerobotfriends.com/reference/index.html> :octicons-link-external-16:
