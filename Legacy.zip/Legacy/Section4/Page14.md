---
tags:
    - Discontinued
---

<style>
.md-typeset h1, .md-typeset h2, .md-typeset h3 { color: #757575; }
</style>

# Install the panStamp platform

:octicons-plus-circle-16: This section requires the embedXcode+ edition.

![](img/Logo-064-panStamp.png) The panStamp platform features a sub-1 GHz radio and includes three architectures, one 8 bits, another 16 bits and the last 32 bits, each with a dedicated boards package managed by the **Boards Manager** on the Arduino 1.8 IDE.

The 8-bit architecture corresponds to the panStamp AVR with an ATmega328P at 16 MHz and 5V, while the 16-bit architecture corresponds to the panStamp NG based on the MSP430. Both the panStamp AVR and panStamp NG are discontinued. Finally, the 32-architecture corresponds to the panStamp Quantum based on the STM32L4.

## Install the panStamp AVR platform

If you plan to use the panStamp AVR platform,

+ Download and install the supported versions of the Arduino IDE under the `/Applications` folder, as described in the section [Install the Arduino platform](../../Chapter1/Section4/Arduino) :octicons-link-16:.

+ Launch it.

+ Define the path of the sketchbook folder in the menu **Arduino > Preferences > Sketchbook location**.

+ Avoid spaces in the name and path of the sketchbook folder.

+ Follow the procedure [Install additional boards on Arduino](../../Chapter1/Section4/#install-additional-boards-on-arduino) :octicons-link-16:. Call the **Boards Manager** and check the two panStamp platforms are listed.

<center>![](img/116-01-420.png)</center>

If the panStamp platforms aren't listed on the **Boards Manager**,

+ Open the **Preferences**.

+ Add the following URL on a separate line, as described in section [Add URLs for new boards](../../Chapter1/Section4/#add-urls-for-new-boards) :octicons-link-16:.

```
http://panstamp.org/arduino/package_panstamp_index.json
```

+ Select the boards and click on **Install**.

For more information on the installation of the panStamp plug-in,

+ Please refer to the [First Steps](https://github.com/panStamp/panstamp/wiki/First steps) :octicons-link-external-16: page the panStamp website.

## Install the panStamp NRG platform

If you plan to use the panStamp NRG platform,

+ Download and install the supported versions of the Arduino IDE under the `/Applications` folder, as described in the section [Install the Arduino platform](../../Chapter1/Section4/Arduino) :octicons-link-16:.

+ Launch it.

+ Define the path of the sketchbook folder in the menu **Arduino > Preferences > Sketchbook location**.

+ Avoid spaces in the name and path of the sketchbook folder.

+ Follow the procedure [Install additional boards on Arduino](../../Chapter1/Section4/#install-additional-boards-on-arduino) :octicons-link-16:. Call the **Boards Manager** and check the two panStamp platforms are listed.

<center>![](img/116-01-420.png)</center>

If the panStamp platforms aren't listed on the **Boards Manager**,

+ Open the **Preferences**.

+ Add the following URL on a separate line, as described in section [Add URLs for new boards](../../Chapter1/Section4/#add-urls-for-new-boards) :octicons-link-16:.

```
http://panstamp.org/arduino/package_panstamp_index.json
```

+ Select the boards and click on **Install**.

For more information on the installation of the panStamp plug-in,

+ Please refer to the [First Steps](https://github.com/panStamp/panstamp/wiki/First steps) :octicons-link-external-16: page the panStamp website.

# Upload to panStamp AVR and NRG boards

:octicons-plus-circle-16: This section requires the embedXcode+ edition.

![](img/Logo-064-panStamp.png) Upload to the panStamp AVR and NRG boards is done with the panStick USB programmer.

For more information,

+ Please refer to the [panStick page](http://panstamp.com/store/index.php?id_product=39&controller=product) :octicons-link-external-16: at the panStamp website.

## Upload to panStamp AVR board

The panStamp AVR board requires a specific upload procedure.

+ Plug the panStamp AVR on the panStick.

+ Slide the selector to `AVR` close to the `RESET` button.

+ Connect the panStick to the USB port of the computer.

+ Launch any of the targets **All**, **Upload** or :octicons-plus-circle-16: **Fast**.

For more information,

+ Please refer to the [panStamp AVR Technical Details](https://github.com/panStamp/panstamp/wiki/panStamp%20AVR.-Technical%20details) :octicons-link-external-16: page at the panStamp website.

## Upload to panStamp NRG board

The panStamp NRG board requires a specific upload procedure.

Proceed as follow:

+ Plug the panStamp NRG on the panStick.

+ Make sure the 5 pins opposite to the antenna are connected between the board and the programmer.

+ Slide the selector to `NRG` away from the `RESET` button.

+ Connect the panStick to the USB port of the computer.

+ Launch any of the targets **All**, **Upload** or :octicons-plus-circle-16: **Fast**.

For more information,

+ Please refer to the [panStamp NRG Technical Details](https://github.com/panStamp/panstamp/wiki/panStamp%20AVR.-Technical%20details) :octicons-link-external-16: page at the panStamp website.

## Upload to panStamp Quantum board

The panStamp Quantum board requires a specific upload procedure.

## Visit the official websites

![](img/Logo-064-panStamp.png) | **panStamp**
:---- | ----
IDE | Arduino with Boards Manager
Website | <http://www.panstamp.com> :octicons-link-external-16:
Download | <https://github.com/panStamp/panstamp/wiki/Downloads#python-applications> :octicons-link-external-16:
Wiki | <https://github.com/panStamp/panstamp/wiki> :octicons-link-external-16:
Forum | <http://www.panstamp.org/forum> :octicons-link-external-16:
STM32L4 website | <https://grumpyoldpizza.github.io/arduino-STM32L4/> :octicons-link-external-16:
STM32L4 download | <https://github.com/GrumpyOldPizza/arduino-STM32L4> :octicons-link-external-16: