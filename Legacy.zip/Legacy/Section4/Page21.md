---
tags:
    - Discontinued
---

<style>
.md-typeset h1, .md-typeset h2, .md-typeset h3 { color: #757575; }
</style>

# Install the TinyCircuits platform

:octicons-plus-circle-16: This section requires the embedXcode+ edition.

![](img/Logo-064-TinyCircuits.png) The installation for the TinyCircuits platform is performed with the **Boards Manager** and the **Library Manager** on the Arduino 1.6.5 IDE.

## Install the TinyScreen+ Board

If you plan to use the TinyScreen+ board,

+ Download and install the supported versions of the Arduino IDE under the `/Applications` folder, as described in the section [Install the Arduino platform](../../Chapter1/Section4/Arduino) :octicons-link-16:.

+ Launch it.

+ Define the path of the sketchbook folder in the menu **Arduino > Preferences > Sketchbook location**.

+ Avoid spaces in the name and path of the sketchbook folder.

+ Follow the procedure [Install additional boards on Arduino](../../Chapter1/Section4/#install-additional-boards-on-arduino) :octicons-link-16:.

+ Call the menu **Tools > Boards > Boards Manager**.

+ Check the Arduino SAMD platform for Arduino Zero and Arduino MKR1000 is already installed. Otherwise, install the Arduino SAMD platform.

<center>![](img/138-01-420.png)</center>

+ Check the TinyCircuits SAMD platform is listed.

<center>![](img/138-02-420.png)</center>

+ Select the board and click on **Install**.

If the TinyCircuits SAMD platform isn't listed on the **Boards Manager**,

+ Open the **Preferences**.

+ Add the following URL on a separate line, as described in section [Add URLs for new boards](../../Chapter1/Section4/#add-urls-for-new-boards) :octicons-link-16:.

```
http://files.tinycircuits.com/ArduinoBoards/package_tinycircuits_index.json
```

+ Return to the **Boards Manager**.

+ Select the board and click on **Install**.

For more information on the installation of the TinyScreen+ board,

+ Please refer to [TinyScreen+ Setup](https://tinycircuits.com/blogs/learn/158833543-tinyscreen-setup) :octicons-link-external-16: page on the TinyCircuits website.

## Install the TinyScreen Library

To install the TinyScreen Library,

+ Launch the Arduino IDE.

+ Call the menu **Sketch > Include Library > Manage Libraries...**

<center>![](img/139-01-420.png)</center>

A new window lists all the libraries, already installed or available for download.

+ Search the list for the TinyScreen library.

<center>![](img/139-02-420.png)</center>

+ Click on **Install**.

The IDE downloads and installs the library.

+ Click on OK.

If the library doesn't show up even after adding the URL with the JSON file,

+ Download the [TinyScreen Library](https://github.com/TinyCircuits/TinyCircuits-TinyScreen_Lib/archive/master.zip) :octicons-link-external-16:.

+ Unzip the file.

+ Copy the resulting folder as a user's library on the `Libraries` sub-folder of the sketchbook folder.

The user's libraries are stored on the `Libraries` or `libraries` sub-folder under the sketchbook folder.

For more information on the installation of the TinyScreen library,

+ Please refer to the [TinyScreen+ Setup](https://tinycircuits.com/blogs/learn/158833543-tinyscreen-setup) :octicons-link-external-16: page on the TinyCircuits website.

# Upload to TinyScreen+ board

:octicons-plus-circle-16: This section requires the embedXcode+ edition.

![](img/Logo-064-TinyCircuits.png) If the TinyScreen+ board is unresponsive, the serial port isn't listed or the upload fails, the board may require to be reset.

To reset the TinyScreen+ Board,

+ Power the board through either an USB cable of a battery.

+ Turn the board off.

<center>![](img/370-01-420.png)</center>

Then,

+ Press the button ++reset++ closest to the USB port and maintain the button   pressed.

+ While maintaining the button ++reset++ pressed, turn the switch ++reset++ on to power the board.

+ Release the button ++reset++.

For more information on resetting the TinyScreen+ board,

+ Please refer to [Resetting the TinyScreen](http://theowatch.com/start/troubleshooting/reset-tinyscreen/) :octicons-link-external-16: page on the TinyCircuits website.

## Visit the official websites

![](img/Logo-064-TinyCircuits.png) | **TinyCircuits**
:---- | ----
IDE | Arduino with Boards Manager
Website | <https://tinycircuits.com> :octicons-link-external-16:
Documentation | <https://tinycircuits.com/blogs/learn/158833543-tinyscreen-setup> :octicons-link-external-16:
Forum | <http://forum.tinycircuits.com> :octicons-link-external-16:
