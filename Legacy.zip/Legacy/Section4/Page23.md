---
tags:
    - On hold
---

<style>
.md-typeset h1, .md-typeset h2, .md-typeset h3 { color: #757575; }
</style>

# Install the Wiring platform

:octicons-plus-circle-16: This section requires the embedXcode+ edition.

![](img/Logo-064-Wiring.png) If you plan to use the Wiring boards,

+ Download and install Wiring 1.0 build 0101 under the `/Applications` folder.

+ Launch it.

<center>![](img/619-01-400.png)</center>

+ Define the path of the sketchbook folder in the menu **Wiring > Preferences > Sketchbook location**.

+ Avoid spaces in the name and path of the sketchbook folder.

+ Delete the two following files.

```
/Applications/Wiring.app/Contents/Resources/Java/cores/AVR8Bit/program.cpp
/Applications/Wiring.app/Contents/Resources/Java/cores/AVR8Bit/makefile
```

Support for Wiring is put on hold until a new version of the IDE or new boards are released.

:octicons-plus-circle-16: The embedXcode+ edition allows to locate the Wiring IDE in another folder.

+ Please refer to the section [Set the folder for standard IDEs](../../Chapter1/Section3/#set-the-folder-for-standard-ides) :octicons-link-16:.

## Visit the official websites

![](img/Logo-064-Wiring.png) | **Wiring**
---- | ----
IDE | Wiring
Website | <http://wiring.org.co> :octicons-link-external-16:
Download | <http://wiring.org.co/download/> :octicons-link-external-16:
Wiki | <http://wiki.wiring.co/wiki/Main_Page> :octicons-link-external-16:
Forum | <http://forum.wiring.co> :octicons-link-external-16:
