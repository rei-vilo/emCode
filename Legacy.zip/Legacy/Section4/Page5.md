---
tags:
    - Discontinued
---

<style>
.md-typeset h1, .md-typeset h2, .md-typeset h3 { color: #757575; }
</style>

# Install the Digistump platform

:octicons-plus-circle-16: This section requires the embedXcode+ edition.

![](img/Logo-064-Digistump-3.png) The Digistump platform offers different boards. The Digispark is based on the ATtiny85 and requires the installation of a plug-in. The DigiX is fully compatible with the Arduino Due. The Oak is based on the popular ESP8266.

The installation is performed with the **Boards Manager** on the Arduino 1.6 IDE.

Development for the Digistump platform is discontinued.

## Install the Digistump platform

If you plan to use the Digistump boards,

+ Download and install the supported versions of the Arduino IDE under the `/Applications` folder, as described in the section [Install the Arduino platform](../../Chapter1/Section4/Arduino) :octicons-link-16:.

+ Launch it.

+ Define the path of the sketchbook folder in the menu **Arduino > Preferences > Sketchbook location**.

+ Avoid spaces in the name and path of the sketchbook folder.

+ Follow the procedure [Install additional boards on Arduino](../../Chapter1/Section4/#install-additional-boards-on-arduino) :octicons-link-16:.

+ Call the **Boards Manager** and check the Digistump boards are listed.

<center>![](img/587-01-420.png)</center>

If the Digistump boards aren't listed on the Boards Manager,

+ Open the **Preferences** and add the following URL on a separate line, as described in section [Add URLs for new boards](../../Chapter1/Section4/#add-urls-for-new-boards) :octicons-link-16:.

```
http://digistump.com/package_digistump_index.json
```

+ Select the boards and click on Install.
For more information on the installation process,

+ Please refer to the [Connecting and Programming Your Digispark](http://digistump.com/wiki/digispark/tutorials/connecting) :octicons-link-external-16: and [Installing the DigiX Software](http://digistump.com/wiki/digix/tutorials/software) :octicons-link-external-16: pages on the Digistump website.

## Install the Oak board

If you plan to use the Oak board, additional procedures are required.

+ Follow the [Installation Instructions](http://digistump.com/wiki/oak/tutorials/arduino) :octicons-link-external-16: as well as the procedures at the [Connecting your Oak for the first time](http://digistump.com/wiki/oak/tutorials/connecting) :octicons-link-external-16: page on the Digistump website.

+ Setup the Oak and download the system firmware using the: [SoftAP Config App](http://rawgit.com/digistump/OakSoftAP/master/config.html) :octicons-link-external-16:.

+ Download and run the [OakCLI tool](https://github.com/digistump/OakCLI) :octicons-link-external-16:.

+ Check the [release notes](https://github.com/digistump/OakCore/releases) :octicons-link-external-16:.

Many users have failed to get the Digistump Oak board configured properly.

+ Connect the board

The Digistump boards are under the menu **Tools > Board**.

# Upload to Digistump boards

:octicons-plus-circle-16: This section requires the embedXcode+ edition.

![](img/Logo-064-Digistump-3.png) The Digistump boards require specific procedures.

## Upload to Digispark board

To upload to a Digispark board, proceed as follow:

+ Unplug the Digispark board.

+ Launch any of the targets **All**, **Upload** or :octicons-plus-circle-16: **Fast**.

+ Wait for the message window:

<center>![](img/341-01-360.png)</center>

+ Plug the cable from the Digispark board into the USB port.

+ Wait for the final message.

You can also monitor the upload with the **Log Navigator**.

+ Open the **Log Navigator**.

<center>![](img/343-01-420.png)</center>

+ Wait for the message `Plug in device now...`

```
Running Digispark Uploader...
Plug in device now...
```

+ Plug the cable from the Digispark board into the USB port.

```
> Press CTRL+C to terminate the program.
> Device is found!
```

The uploader connects, erases and then writes the sketch on the Digispark board.

```
connecting: 20% complete
erasing: 80% complete
> Starting to upload ...
writing: 80% complete
Wait for the final message.
Writing: 100% complete
>> Micronucleus done. Thank you!
```

For more information,

+ Please refer to the tutorial [Connecting and Programming Your Digispark](https://digistump.com/wiki/digispark/tutorials/connecting) :octicons-link-external-16: available at the Digistump wiki.

For using the serial port,

+ Please refer to the tutorials [Debugging with the Digispark](https://digistump.com/wiki/digispark/tutorials/debugging) :octicons-link-external-16: and [Digispark USB CDC Serial Library](https://digistump.com/wiki/digispark/tutorials/digicdc) :octicons-link-external-16: available at the Digistump wiki.

<center>![](img/343-02-200.png)</center>

## Upload to Oak

:octicons-plus-circle-16: This section requires the embedXcode+ edition.

To upload to an Oak board, proceed as follow:

+ Power the Oak board on.

For more information,

+ Please refer to the tutorial [Connecting and Programming Your Digispark](http://digistump.com/wiki/digispark/tutorials/connecting) :octicons-link-external-16: available at the Digistump wiki.

<center>![](img/343-02-200.png)</center>

## Visit the official websites

![](img/Logo-064-Digistump-3.png) | **Digistump**
---- | ----
IDE | Arduino with Boards Manager
Website | <http://digistump.com> :octicons-link-external-16:
Download | <http://digistump.com/wiki/digispark/tutorials/connecting> :octicons-link-external-16:
Wiki | <http://digistump.com/wiki> :octicons-link-external-16:
Forum | <http://digistump.com/board/> :octicons-link-external-16:
