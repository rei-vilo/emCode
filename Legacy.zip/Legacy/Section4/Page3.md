---
tags:
    - Discontinued
---

<style>
.md-typeset h1, .md-typeset h2, .md-typeset h3 { color: #757575; }
</style>

# Install the 4D Systems platform

:octicons-plus-circle-16: This section requires the embedXcode+ edition.

![](img/Logo-064-4D-Systems.png) The 4D Systems boards combine a colour touch screen with a controller. The IoD boards are powered by an ESP8266 MCU while the PICadillo board runs on a PIC32.

## Install the 4D Systems gen4 IoD boards

If you plan to use the gen4 IoD boards from 4D Systems:

+ First install the ESP8266 platform as described in the procedure [Install the ESP8266 platform](../../Chapter1/Section4/#install-the-esp8266-platform) :octicons-link-16:.

+ Download the graphics library [GFX4d](https://github.com/4dsystems/GFX4d) :octicons-link-external-16: by 4D Systems.

+ Unzip the file.

+ Copy the folders on the `libraries` folder, included in the sketchbook folder.

The gen4 IoD board needs to be added to the list of the boards.

+ Launch the **Finder** and go for the `boards.txt` file of the ESP8266 boards package.

+ Press ++cmd+shift+g++ and enter the path `~/Library/Arduino15/Arduino15/packages/esp8266/hardware/esp8266`.

+ Click on **Go**.

+ Select the folder with the most recent version, for example `2.3.0`.

+ Open the `boards.txt` file.

+ Add the following lines at the end of the `boards.txt` file.

``` c
#############################################################
gen4iod.name=4D Systems gen4 IoD Range
gen4iod.upload.tool=esptool
gen4iod.upload.speed=921600
gen4iod.upload.resetmethod=nodemcu
gen4iod.upload.maximum_size=434160
gen4iod.upload.maximum_data_size=81920
gen4iod.upload.wait_for_upload_port=true
gen4iod.serial.disableDTR=true
gen4iod.serial.disableRTS=true
gen4iod.build.mcu=esp8266
gen4iod.build.f_cpu=160000000L
gen4iod.build.board=GEN4_IOD
gen4iod.build.core=esp8266
gen4iod.build.variant=generic
gen4iod.build.flash_mode=qio
gen4iod.build.flash_size=512K
gen4iod.build.flash_ld=eagle.flash.512k0.ld
gen4iod.build.flash_freq=80
gen4iod.build.debug_port=
gen4iod.build.debug_level=
gen4iod.menu.CpuFrequency.160=160 MHz
gen4iod.menu.CpuFrequency.160.build.f_cpu=160000000L
gen4iod.menu.CpuFrequency.80=80 MHz
gen4iod.menu.CpuFrequency.80.build.f_cpu=80000000L
gen4iod.menu.UploadSpeed.115200=115200
gen4iod.menu.UploadSpeed.115200.upload.speed=115200
gen4iod.menu.UploadSpeed.9600=9600
gen4iod.menu.UploadSpeed.9600.upload.speed=9600
gen4iod.menu.UploadSpeed.57600=57600
gen4iod.menu.UploadSpeed.57600.upload.speed=57600
gen4iod.menu.UploadSpeed.256000.windows=256000
gen4iod.menu.UploadSpeed.256000.upload.speed=256000
gen4iod.menu.UploadSpeed.230400.linux=230400
gen4iod.menu.UploadSpeed.230400.macosx=230400
gen4iod.menu.UploadSpeed.230400.upload.speed=230400
gen4iod.menu.UploadSpeed.460800.linux=460800
gen4iod.menu.UploadSpeed.460800.macosx=460800
gen4iod.menu.UploadSpeed.460800.upload.speed=460800
gen4iod.menu.UploadSpeed.512000.windows=512000
gen4iod.menu.UploadSpeed.512000.upload.speed=512000
gen4iod.menu.UploadSpeed.921600=921600
gen4iod.menu.UploadSpeed.921600.upload.speed=921600
```

+ Save and close.

Unfortunately, the listing provided at section 12.1 Programming the IoD with the Arduino IDE of the [gen4-IoD Datasheet](http://www.4dsystems.com.au/productpages/gen4-IoD/downloads/gen4-IOD_datasheet_R_1_0.pdf) :octicons-link-external-16: is not formatted correctly. Copying-pasting it directly into the `boards.txt` file raises error on macOS.

For more information on the installation of the board,

+ Please refer to the manufacturer documentation on the [gen4 IoD](http://www.4dsystems.com.au/product/gen4_IoD/) :octicons-link-external-16: page on the 4D Systems website.

## Install the 4D Systems PICadillo board

If you plan to use the PICadillo board from 4D Systems:

+ First install the chipKIT platform as described in the procedure [Install the chipKIT platform](../../Chapter1/Section4/#install-the-chipkit-platform) :octicons-link-16:.

+ Download the [DisplayCore library](https://github.com/MajenkoLibraries/DisplayCore) :octicons-link-external-16: by Majenko Technologies.

+ Unzip the file.

+ Copy the folders on the libraries folder, included in the sketchbook folder.

+ Connect the board

The PICadillo-35T board is under the menu **Tools > Board > 4D Systems**.

<center>![](img/066-01-420.png)</center>

For more information on the board,

+ Please refer to the manufacturer documentation on the [PICadillo-35T](http://www.4dsystems.com.au/product/PICadillo_35T/) :octicons-link-external-16: page.

For more information on the library,

+ Please refer to the [DisplayCore](http://displaycore.org) :octicons-link-external-16: website.

## Visit the official websites

![](img/Logo-064-4D-Systems.png) | **4D Systems**
:---- | ----
IDE | Arduino with Boards Manager
Website | <http://www.4dsystems.com.au> :octicons-link-external-16:
Product page | <http://www.4dsystems.com.au/product/PICadillo_35T/> :octicons-link-external-16:
Display library | <https://github.com/MajenkoLibraries/DisplayCore> :octicons-link-external-16:
Forum | <http://forum.4dsystems.com.au> :octicons-link-external-16: