---
tags:
    - Discontinued
---

<style>
.md-typeset h1, .md-typeset h2, .md-typeset h3 { color: #757575; }
</style>

# Install the Arduino STM32 platform

![](img/Logo-064-STM32duino_old.png) The [Arduino STM32](https://github.com/rogerclarkmelbourne/Arduino_STM32) :octicons-link-external-16: provides an easy solution for boards based on the STM32F1xx, STM32F3xx and STM32F4xx MCUs. It comes as a package compatible with the **Boards Manager** of the Arduino 1.8 IDE.

The Arduino STM32 was previously named STM32duino. The name now refers to the STM32duino platform maintained by STMicroelectronics.

For more information about the new STM32duino platform,

+ Please refer to [Install the STM32duino platform](../../Chapter1/Section4/#install-the-stm32duino-platform) :octicons-link-16:.

If you plan to use the Arduino STM32 package,

+ Download and install the supported versions of the Arduino IDE under the `/Applications` folder, as described in the section [Install the Arduino platform](../../Chapter1/Section4/Arduino) :octicons-link-16:.

+ Launch it.

+ Define the path of the sketchbook folder in the menu **Arduino > Preferences > Sketchbook location**.

+ Avoid spaces in the name and path of the sketchbook folder.

+ Follow the procedure [Install additional boards on Arduino](../../Chapter1/Section4/#install-additional-boards-on-arduino) :octicons-link-16:.

+ Call the **Boards Manager** and check the STM32F1xx boards are listed.

<center>![](img/135-01-420.png)</center>

If the STM32F1xx boards aren't listed on the **Boards Manager**,

+ Open the **Preferences**.

+ Add one of the following URLs on a separate line, as described in section [Add URLs for new boards](../../Chapter1/Section4/#add-urls-for-new-boards) :octicons-link-16:.

```
https://dan.drown.org/stm32duino/package_STM32duino_index.json
```

+ Select the boards and click on **Install**.

For more information on the installation of the Arduino IDE,

+ Please refer to the [Arduino STM32](https://github.com/rogerclarkmelbourne/Arduino_STM32) :octicons-link-external-16: page on the GitHub repository.

## Visit the official websites

![](img/Logo-064-STM32duino_old.png) | **Arduino STM32**
:---- | ----
IDE | Arduino with Boards Manager
Website | <https://mcu.selfip.com> :octicons-link-external-16:
Former website | <http://www.stm32duino.com> :octicons-link-external-16:
Download | <https://github.com/rogerclarkmelbourne/Arduino_STM32> :octicons-link-external-16:
Wiki | <https://github.com/rogerclarkmelbourne/Arduino_STM32/wiki> :octicons-link-external-16:
Forum | <http://www.stm32duino.com> :octicons-link-external-16: