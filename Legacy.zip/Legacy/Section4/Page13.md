---
tags:
    - Discontinued
---

<style>
.md-typeset h1, .md-typeset h2, .md-typeset h3 { color: #757575; }
</style>

# Install the Microduino platform

:octicons-plus-circle-16: This section requires the embedXcode+ edition.

![](img/Logo-064-Microduino.png) The Microduino platform includes two architectures, one 8 bits and another 32 bits, each with its dedicated IDE.

The 8-bit ATmega architecture includes the Microduino-Core with an ATmega328P at 16 MHz and 5V, the Microduino-Core+ with an ATmega644PA at 16 MHz and 5V and the Microduino-Core USB with an ATmega32u4 at 16 MHz. Those boards run on a plug-in for the Arduino IDE.

The 32-bit architecture corresponds to the Microduino-Core STM32 board, and uses the MapleIDE or the STM32duino platform for the Arduino 1.6.5 IDE.

## Install the Microduino platform for ATmega

If you plan to use the Microduino-Core with an ATmega328P at 16 MHz and 5V, the Microduino-Core+ with an ATmega644PA at 16 MHz and 5V or the Microduino-Core USB with an ATmega32u4 at 16 MHz,

+ Download and install the supported versions of the Arduino IDE under the `/Applications` folder, as described in the section [Install the Arduino platform](../../Chapter1/Section4/Arduino) :octicons-link-16:.

+ Select the Arduino icon, call the contextual menu and select **Show Package Content**.

<center>![](img/104-01-220.png)</center>

+ Navigate to the `Content/Resources/Java/Hardware` folder for Arduino 1.0.6 or navigate to the `Content/Java/Hardware` folder Arduino 1.6.1 and 1.7.

+ Download the [Microduino plug-in](http://wiki.microduino.cc/index.php?title=Arduino_IDE_Microduino_Configuration) :octicons-link-external-16:.

+ Open the `.zip` file.

+ Copy-paste the unzipped folder Microduino into the `Content/Resources/Java/Hardware` folder for Arduino 1.0.6.

<center>![](img/104-03-240.png)</center>

Similarly, copy-paste the content of the unzipped folder libraries into the `Contents/Resources/Java/libraries` folder for Arduino 1.0.6.

+ Copy-paste the unzipped folder Microduino into the `Content/Java/Hardware` folder Arduino 1.6.1 and 1.7.

<center>![](img/105-01-240.png)</center>

The Microduino folder already contains the libraries.

+ Launch the modified Arduino IDE.

+ Define the path of the sketchbook folder in the menu **Arduino > Preferences > Sketchbook location**.

+ Avoid spaces in the name and path of the sketchbook folder.

For more information about the installation of the Microduino IDE and the drivers,

+ Please refer to the [Getting started: Mac](https://wiki.microduinoinc.com/Getting_started:_Mac) :octicons-link-external-16: page from the Microduio wiki.

## Rename the Microduino IDE

As the IDE for Microduino boards modifies the Arduino IDE, you may want to have a separate modified Arduino IDE for the Microduino boards.

Microduino relies on version 1.8.4 of the Arduino IDE, while the Arduino IDE release 1.8.10 is available. So it is highly recommend to have a dedicated and separated instance of the Arduino IDE called Microduino.

<center>![](img/105-01-540.png)</center>

+ Change the name to `Microduino`.

+ Optionally, update the icon to avoid any confusion with the standard Arduino IDE.

embedXcode identifies the IDE automatically among **Arduino** and **Microduino**.

## Connect the board

The Microduino boards appear under the menu **Tools > Board**.

<center>![](img/105-02-420.png)</center>

:octicons-plus-circle-16: The embedXcode+ edition allows to locate the Arduino or Microduino IDE in another folder.

+ Please refer to the section [Set the folder for standard IDEs](../../Chapter1/Section3/#set-the-folder-for-standard-ides) :octicons-link-16:.

## Install the Microduino platform for STM32

The Microduino-Core STM32 board is compatible with the Maple Mini. The IDE used is the MapleIDE or the STM32duino platform for the Arduino 1.6.5 IDE.

If you plan to use the MapleIDE,

+ Follow the instructions provided at the section Install the Maple platform.

+ Download and install the MapleIDE.

+ Define the path of the sketchbook folder.

+ Install the utility for the uploader.

+ Define the integer standard types.

The Microduino-Core STM32 suffers from the same limitation the Maple environment does: two important libraries, strings.h and stream.h, are not implemented.

If you plan to use the STM32duino platform for the Arduino 1.6.5 IDE,

+ Follow the instructions provided at the section [Install the STM32duino platform](../../Chapter1/Section4/#install-the-stm32duino-platform) :octicons-link-16:.

For more information on the installation of the Microduino-Core STM32,

+ Please refer to the [Core STM32 Startup Guide](https://www.microduino.cc/wiki/index.php?title=Core_STM32_Startup_Guide) :octicons-link-external-16: at the Microduino website.

## Connect the board

Optionally, to replace Maple Mini by Microduino-Core STM32 in the **Tools > Board** menu,

<center>![](img/107-01-420.png)</center>

+ Download the file `boards.txt` from from the [Microduino Tutorials GitHub repository](http://www.apple.com/) :octicons-link-external-16:.

+ Copy the downloaded `boards.txt` file into the `/Applications/MapleIDE.app/Contents/Resources/Java/hardware` folder to replace the existing one.

:octicons-plus-circle-16: The embedXcode+ edition allows to locate the MapleIDE in another folder.

+ Please refer to the section [Set the folder for standard IDEs](../../Chapter1/Section3/#set-the-folder-for-standard-ides) :octicons-link-16:.

The STM32duino platform provides a viable alternative solution for the Maple boards.

+ Please refer to section [Install the STM32duino platform](../../Chapter1/Section4/#install-the-stm32duino-platform) :octicons-link-16:.

## Visit the official websites

![](img/Logo-064-Microduino.png) | **Microduino**
:---- | ----
IDE | Arduino
Website | <http://www.microduino.cc> :octicons-link-external-16:
Download | <http://wiki.microduino.cc/index.php?title=Arduino_IDE_Microduino_Configuration> :octicons-link-external-16:
Wiki | <http://wiki.microduino.cc> :octicons-link-external-16:
Forum | <https://www.microduino.cc/forum> :octicons-link-external-16:
