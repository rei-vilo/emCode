---
tags:
    - Discontinued
---

<style>
.md-typeset h1, .md-typeset h2, .md-typeset h3 { color: #757575; }
</style>

# Install the chipKIT platform

![](img/Logo-064-chipKIT.png) The installation of the chipKIT platform is performed with the **Boards Manager** on the Arduino 1.8 IDE.

!!! danger
    The tool-chain for PIC32 only comes as a 32-bit application, while macOS 10.15 *Catalina* requires 64-bit applications.

The previous stand-alone IDE, MPIDE, is no longer supported.

## Install the chipKIT platform

If you plan to use the chipKIT boards,

+ Download and install the supported versions of the Arduino IDE under the `/Applications` folder, as described in the section [Install the Arduino platform](../../Chapter1/Section4/Arduino) :octicons-link-16:.

+ Launch it.

+ Define the path of the sketchbook folder in the menu **Arduino > Preferences > Sketchbook location**.

+ Avoid spaces in the name and path of the sketchbook folder.

+ Follow the procedure [Install additional boards on Arduino](../../Chapter1/Section4/#install-additional-boards-on-arduino) :octicons-link-16:.

+ Call the **Boards Manager** and check the chipKIT boards are listed.

<center>![](img/062-01-420.png)</center>

If the chipKIT boards aren't listed on the **Boards Manager**,

+ Open the **Preferences**.

+ Add one of the following URLs on a separate line, as described in section [Add URLs for new boards](../../Chapter1/Section4/#add-urls-for-new-boards) :octicons-link-16:.

```
https://github.com/chipKIT32/chipKIT-core/raw/master/package_chipkit_index.json
https://raw.githubusercontent.com/chipKIT32/chipKIT-core/master/package_chipkit_index.json
```

+ Select the boards and click on **Install**.

The procedure also installs the network and WiFi libraries required by the chipKIT WF32 and WiFire boards, and by the chipKIT WiFi shield for other boards.

Some boards like the chipKIT uC32 may require an update of the boot-loader.

+ Please refer to the procedure [Burn the boot-loader after using a programmer on chipKIT boards](../../Chapter4/Section6/#burn-the-boot-loader-after-using-a-programmer-on-chipkit-boards) :octicons-link-16:.

For more information on the installation process,

+ Please refer to the [Install the chipKIT Core](http://chipkit.net/wiki/index.php?title=ChipKIT_core#1.29_Auto_install_via_URL_from_within_Arduino_IDE) :octicons-link-external-16: page on the chipKIT website.

## Install Debugging Tools for chipKIT Boards

:octicons-plus-circle-16: This section requires the embedXcode+ edition.

Debugging has been tested successfully on the following boards:

+ chipKIT Uno32 with the chipKIT PGM programmer-debugger.

Debugging the chipKIT boards requires a compatible programmer like the [chipKIT PGM](http://www.digilentinc.com/Products/Detail.cfm?Prod=chipKIT%20PGM) :octicons-link-external-16: and the official debugger MDB tool, part of the official [Microchip MPLABX](http://www.microchip.com/pagehandler/en-us/family/mplabx) :octicons-link-external-16: IDE.

<center>![](img/063-01-080.png)</center>

+ Download [MPLABX for OS X](http://www.microchip.com/mplab/mplab-x-ide) :octicons-link-external-16: from Microchip, release 2.10 or later.

+ Install **MPLABX** with the default settings.

+ On the **Installation Options** page, set the **Installation Directory** to the folder where all IDEs are located, by default `/Applications/microchip/mplabx/v4.15`.

On the example below, all the IDEs are located under `/Applications/IDE`.

<center>![](img/064-01-640.png)</center>

+ If all the IDEs are located under `/Applications/IDE`, set the **Installation Directory** to `/Applications/IDE/microchip/mplabx/v4.15`.

+ On the **Select Programs** page, select both **MPLAB X IDE** and **MPLAB IPE**.

<center>![](img/064-02-640.png)</center>

The former contains the server for debugging, the latter the utility to reflash the boot-loader.

+ Check the `About.mk` file lists the correct release of **MPLAB**.

+ If needed, update the `About.mk` file accordingly, as described in section [Check and update the boards reference list](../../Chapter4/Section2/#check-and-update-the-boards-reference-list) :octicons-link-16:.

``` CMake
MPLAB_IDE_RELEASE               = v4.15
```

The chipKIT Uno32 board with the chipKIT PGM needs to be added to the list of the boards.

+ Launch the **Finder** and go for the `boards.txt` file of the chipKIT boards package.

+ Press ++cmd+shift+g++ and enter the path `~/Library/Arduino15/Arduino15/packages/chipKIT/hardware/pic32/`.

+ Click on **Go**.

+ Select the folder with the most recent version, for example `2.0.1`.

+ Open the `boards.txt` file.

+ Add the following lines at the end of the `boards.txt` file.

```
###########################################################
uno_pic32_dbg.name=chipKIT UNO32 - MPLAB Debug

# new items
uno_pic32_dbg.platform=pic32
uno_pic32_dbg.board=_BOARD_UNO_
uno_pic32_dbg.compiler.define=-Danything_you_want::-Danything=1
uno_pic32_dbg.ccflags=ffff
uno_pic32_dbg.ldscript=chipKIT-application-32MX320F128-nobootloader.ld
# end of new items

# Use a high -Gnum for devices that have less than 64K of data memory
# For -G1024, objects 1024 bytes or smaller will be accessed by
# gp-relative addressing
uno_pic32_dbg.compiler.c.flags=-O0::-c::-mno-smart-io::-w::-ffunction-sections::-fdata-sections::-G1024::-g::-mdebugger::-Wcast-align
uno_pic32_dbg.compiler.cpp.flags=-O0::-c::-mno-smart-io::-w::-fno-exceptions::-ffunction-sections::-fdata-sections::-G1024::-g::-mdebugger::-Wcast-align

uno_pic32_dbg.upload.protocol=stk500v2
uno_pic32_dbg.upload.maximum_size=126976
uno_pic32_dbg.upload.speed=115200

uno_pic32_dbg.bootloader.low_fuses=0xff
uno_pic32_dbg.bootloader.high_fuses=0xdd
uno_pic32_dbg.bootloader.extended_fuses=0x00
uno_pic32_dbg.bootloader.path=not-supported
uno_pic32_dbg.bootloader.file=not-supported
uno_pic32_dbg.bootloader.unlock_bits=0x3F
uno_pic32_dbg.bootloader.lock_bits=0x0F

uno_pic32_dbg.build.mcu=32MX320F128H
uno_pic32_dbg.build.f_cpu=80000000L
uno_pic32_dbg.build.core=pic32
#uno_pic32_dbg.upload.using=
uno_pic32_dbg.build.variant=Uno32
```

+ Save and close.

# Upload to chipKIT boards using a programmer-debugger

:octicons-plus-circle-16: This section requires the embedXcode+ edition.

![](img/Logo-064-chipKIT.png) To upload to a chipKIT boards with the optional chipKIT PGM programmer-debugger.

Proceed as follow:

+ Plug the chipKIT programmer into the board.

+ Plug the cable into the USB port.

<center>![](img/339-01-420.png)</center>

+ Launch any of the targets **All**, **Upload** or :octicons-plus-circle-16: **Fast**.

embedXcode builds and links the project, and then opens one **Terminal** window.

<center>![](img/339-02-420.png)</center>

The **Terminal** window hosts the programmer-debugger. The tool first connects to the board, then uploads the executable, and finally runs the project.

To quit the session,

+ Type `quit` and press the ++enter++ key.

```
>quit

Halting...
Target Halted
```

+ Always quit the **Terminal** window.

Using the programmer-debugger erases the boot-loader. To upload again without the programmer-debugger,

+ Please refer to the procedure [Burn the boot-loader after using a programmer on chipKIT boards](../../Chapter4/Section6/#burn-the-boot-loader-after-using-a-programmer-on-chipkit-boards) :octicons-link-16:.

# Debug the chipKIT boards with MDB

:octicons-plus-circle-16: This section requires the embedXcode+ edition and a chipKIT board with the optional chipKIT PGM programmer-debugger.

![](img/Logo-064-chipKIT.png) This section applies to the chipKIT boards with the optional chipKIT PGM programmer-debugger.

The debugger is called MDB and is part of the official Microchip [MPLABX](http://www.microchip.com/pagehandler/en-us/family/mplabx/) :octicons-link-external-16: IDE

+ To launch a debugging session, just select the **Debug** target and press **Run**.

<center>![](img/424-01-360.png)</center>

embedXcode builds and links the project, and then opens one **Terminal** window.

## Identify one Terminal window

The **Terminal** window hosts the programmer-debugger. The tool first connects to the board, then uploads the executable and all the breakpoints defined previously, and finally runs the project.

## Run and stop the sketch execution

Here are the most common commands to run, stop and continue the execution of the sketch in a debugging session:

+ Enter the commands after the `>` prompt and validate it by pressing the ++enter++ key.

```
>
```

+ When the debugger stops, type `continue` or simply `c` to continue till the next breakpoint.

```
> continue
> c
```

+ To run the sketch one step to the next line of code to be executed, including the sub-functions called by the current function, type `step` or simply `s`.

```
> step
> s
```

+ To run the sketch to the next line of the current function, without stopping at the sub-functions, type `next` or simply `n`.

```
> next
> n
```

+ To stop the sketch, type `halt`.

```
> halt
```

+ To list the breakpoints defined and loaded, type `info break`.

```
>info break
Num    Enb    Address    What
0    y    0x9D0013A8    at LocalLibrary.cpp:25
```

For more information,

+ Please refer to the [Microchip Debugger (MSB) User's Guide](http://ww1.microchip.com/downloads/en/DeviceDoc/50002102C.pdf) :octicons-link-external-16:.

## Display the value of a variable

To get the value of a variable,

+ Type the command `print` and the name of the variable.

```
>print pin
pin=
0x0D
```

## Display the call stack

To display the stack of the calls,

+ Type the command `backtrace`.

```
>backtrace
#0  blink (pin=0x0D, times=0x03, ms=0x20B2) at /Users/ReiVilo/Documents/Projets/Xcode/embed1/embed1/LocalLibrary.cpp:26
#1  0x9D0013CC in loop () at /Users/ReiVilo/Documents/Projets/Xcode/embed1/embed1/embed1.ino:106
#2  0x9D001404 in main () at /Users/ReiVilo/Documents/Projets/Xcode/embed1/embed1/main.cpp:93
```

The `blink()` function is called by the function `loop()`, and `loop()` is called by the main function `main()`.

The backtrace command also provides the details of the parameters and values passed by `loop()` on to `blink()`.

Here, values are `pin=0x0D`, `times=0x03`, `ms=0x20B2`.

Value `0x0D` corresponds to variable `myLED`.

## End and quit a debugging session

To end the debugging session,

+ Type `halt`.

```
>halt

Halting...
Target Halted

>Stop at
address:0x9d001f1c
```

To quit the debugging session,

+ Type `quit`.

```
>quit
Stop at
address:0x9d001370
file:/Users/ReiVilo/Documents/Projets/Xcode/embed1/embed1/LocalLibrary.cpp
source line:26
```

+ Always quit and close the **Terminal** window.

## Visit the official websites

![](img/Logo-064-chipKIT.png) | **chipKIT**
:---- | ----
IDE | Arduino with Boards Manager
Website | <http://chipkit.net> :octicons-link-external-16:
Installation | <http://chipkit.net/started/> :octicons-link-external-16:
WiFi library for 1.5 | <http://www.digilentinc.com/Products/Detail.cfm?NavPath=2,892,1266&Prod=CHIPKIT-WIFIRE> :octicons-link-external-16:
Wiki | <http://www.digilentinc.com/Products/Catalog.cfm?NavPath=2,892&Cat=18> :octicons-link-external-16:
Forum | <http://www.chipkit.org/forum/> :octicons-link-external-16: