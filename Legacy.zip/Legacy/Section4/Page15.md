---
tags:
    - On hold
---

<style>
.md-typeset h1, .md-typeset h2, .md-typeset h3 { color: #757575; }
</style>

# Install the Particle platform

:octicons-plus-circle-16: This section requires the embedXcode+ edition.

![](img/Logo-064-Spark.png) Unlike the other platforms, the Particle Core board doesn't come with an Arduino-like IDE with everything included.

Particle strongly promotes its [online IDE](https://www.particle.io/build) :octicons-link-external-16:. However, the framework is also available for download. Unfortunately, it is still in beta and doesn't support the Photon.

Installing the Particle platform requires two steps: the first for the framework and the tool-chain, the second for the utilities.

Particle was previously Spark.

The new Particle boards are not supported. As a consequence, development for the Particle platform is put on hold.

## Install the Tools for Particle

The installation of the tools for Particle is now included in the embedXcode installation package process.

<center>![](img/608-01-100.png)</center>

If the Particle framework is selected, the installer checks whether the tool-chain and the SDK are already installed. If needed, it downloads and installs them.

The Particle framework weights 80 MB, with 76 MB for the GCC tool-chain 76 MB and 4 MB for the SDK.
For more details on the installation process,

+ Please refer to the section Install the template.
The installation can be performed manually, as described in the following section.

+ Check the result of the installation

Once the installation has been completed, the folder
`~/Library/embedXcode` contains the following files.

<center>![](img/609-01-300.png)</center>

## Install the utilities

There are two utilities, one in charge of the management of the Particle cloud, namely the Particle Command Line Interface for the Cloud package, and another for the upload of the binaries to the board.

To install the **Particle Command Line Interface**,

+ Download and install the [node.js package](http://nodejs.org) :octicons-link-external-16:.

The package contains `node.js` and `npm`. `node.js` is a platform for network applications.

<center>![](img/Logo-064-nodejs.png)</center>

And `npm` is a package manager for `node.js`.

<center> ![](img/Logo-064-npm.png)</center>

+ Open a **Terminal** window.

+ Enter the following command to download the Particle Command Line Interface for the Cloud package.

``` bash
$ sudo npm install -g particle-cli
```

For more information on the Particle Command Line Interface,

+ Please refer to its [GitHub repository](https://github.com/spark/spark-cli) :octicons-link-external-16:.

To install the uploader **dfu-util**,

+ Open a **Terminal** window.

+ Launch the following command to install **Homebrew**, if it isn't already available.

``` bash
$ /usr/bin/ruby -e "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/master/install)"
```

+ Run the installation of dfu-util.

``` bash
$ brew install dfu-util
```

+ Check the installation in the /usr/local/bin folder.

``` bash
$ ls /usr/local/bin/dfu*
```

## Configure the Particle Core

To configure the Particle Core,

+ Open a **Terminal** window.

+ Enter the following command to create your account.

``` bash
$ particle cloud login
```

+ Follow the instructions and answer the questions.

```
Could I please have an e-mail address?
and a password? *
Got an access token! 12345678901234567890
logged in! { '0': '12345678901234567890' }
Using the setting "access_token" instead
Using the setting "username" instead
```

+ Enter the following command to set your Particle Core.

``` bash
$ particle cloud login
```

+ Follow the instructions and answer the questions.

```
========================================
Setup your account

You are already logged in as
Logged in!
Saving access token: 12345678901234567890

----------------------
Finding your core id

Your core id is: aabbccddeeffaabbccddeeff
```

+ Keep the `core id`: it is required to upload the sketch using the Particle Cloud.

+ Follow the instructions and answer the questions.

```
========================================
Setup your wifi

SSID:
Security 0=unsecured, 1=WEP, 2=WPA, 3=WPA2:
Wifi Password:
Attempting to configure wifi on /dev/cu.usbmodem1421

Thanks! Wait about 7 seconds while I save those credentials...

Serial said: Awesome. Now we'll connect!

If you see a pulsing cyan light, your Spark Core
has connected to the Cloud and is ready to go!

If your LED flashes red or you encounter any other problems,
visit https://www.spark.io/support to debug.

 Particle <3 you!

Done! Your core should now restart.

Please wait until your core is breathing cyan and then press ENTER
```

+ Follow the instructions and answer the questions.

```
========================================
Claiming your core

Please wait until your core is breathing cyan and then press ENTER

Successfully claimed core aabbccddeeffaabbccddeeff
```

+ Follow the instructions and answer the questions.

```
========================================
Shouting rainbows...

Press ENTER if your core is excitedly shouting rainbows
          _ __             _   _      _
         | '_ \  __ _ _ __| |_(_) ___| | ___
         | |_) |/ _` | '__| __| |/ __| |/ _ \
         |  __/| (_| | |  | |_| | (__| |  __/
         |_|    \__,_|_|   \__|_|\___|_|\___|
                          https://particle.io
----------------------
Naming your core

What would you like to call your core?
Naming core.
```

+ Keep the `core name`: it is required to upload the sketch using the Particle Cloud.

For more information about configuring the Particle Core,

+ Please refer to the [Particle CLI page](http://docs.particle.io/cli/) :octicons-link-external-16:.

## Set the Folder for Particle Projects

The folder where the Particle projects are saved is defined during installation. However, should this folder change, you need to define the new location.

For example, if the Particle projects are located on the `~/Documents/Projects/Particle` folder,

+ Open the `~/Documents/embedXcode` folder.

<center>![](img/613-01-300.png)</center>

+ Double click on **Define path to Particle projects**.

<center>![](img/613-02-100.png)</center>

A window asks for the folder where the Particle projects are saved.

<center>![](img/613-03-400.png)</center>

+ Select an existing folder or create a new one with **New Folder**.

+ Click **Choose**.

A notification confirms the new path.

<center>![](img/613-04-360.png)</center>

# Upload to Particle boards

:octicons-plus-circle-16: This section requires the embedXcode+ edition.

![](img/Logo-064-Spark.png) Compiled sketches can be upload to the Particle Core board through an USB connection or using the Particle Cloud.

## Upload through USB connection

To upload a compiled sketch through USB connection, we need to place the Particle Core in DFU mode.

+ Plug the Particle Core USB cable.

+ Launch any of the targets **All**, **Upload** or :octicons-plus-circle-16: **Fast**.

<center>![](img/614-01-360.png)</center>

+ Press and keep the `MODE` button,

+ Press and release the `RESET` button,

+ Keep the `MODE` button pressed on until the LED starts flashing yellow.

+ Release the `MODE` button.

+ Click on **OK** to proceed with the upload.

For more information,

+ Please refer to the [Connecting Your Core](http://docs.spark.io/connect/#appendix-dfu-mode-device-firmware-upgrade) :octicons-link-external-16: page at the Spark website.

## Upload Using the Particle Cloud

:octicons-plus-circle-16: This section requires the embedXcode+ edition.

To upload a compiled sketch using the Particle Cloud,

+ Be sure the Particle Core has been claimed and configured as described in the [Install the Particle platform](../../Legacy/Section4/Page15) :octicons-link-16: procedure.

+ Check the Particle Core is connected to the Particle Cloud with the LED breathing cyan.

+ Optionally, open a **Terminal** window and list the boards available.

``` bash
$ particle list
```

+ Check your board is online.

```
Checking with the cloud...
Retrieving cores... (this might take a few seconds)
mySpark (aabbccddeeffaabbccddeeff) is online
```

+ Launch any of the targets **All**, **Upload** or :octicons-plus-circle-16: **Fast**.

The upload may take a while, with the LED blinking magenta then green, and finally breathing cyan.

For more information,

+ Please refer to the [Getting Started](http://docs.spark.io/connect/#appendix-dfu-mode-device-firmware-upgrade) :octicons-link-external-16: page at the Particle website.
##Follow the Manual Procedure

As an alternative, here is the manual procedure:
Open the Finder and go to the ~/Library folder.

To do so,

+ Press ++cmd+shift+g++ and enter the path `~/Library`.

<center>![](img/616-01-360.png)</center>

+ Click on **Go**.

Alternatively,

+ Press ++alt++ while clicking on the **Go** menu and select `Library`.

<center>![](img/617-01-200.png)</center>

On the `~/Library` folder,

+ Create a new folder inside and name it embedXcode to obtain `~/Library/embedXcode`.

To install the Particle framework,

<center>![](img/Logo-064-Spark.png)</center>

+ Open the [Particle firmware](https://github.com/spark/firmware) :octicons-link-external-16: GitHub repository.

+ Select the feature/hal branch.

+ Download the ZIP file form the GitHub repository and unzip it under `~/Library/embedXcode/Particle`.

+ If needed, rename the new folder to obtain `~/Library/embedXcode/Particle/firmware`.

To allow version management,

+ Open **TextEdit** and create a new text file.

+ Enter the version number, in this case `1`.

```
1
```

+ Save it as `~/Library/embedXcode/Particle/version.txt`.

To define the folder where the Particle projects are stored,

+ Open **TextEdit** and create a new text file.

+ Add the following line and specify the path to the desired folder, `~/Documents/Particle` in this example.
`sketchbook.path=~/Documents/Particle`.

+ Save it as `~/Library/embedXcode/Particle/preferences.txt`.

For more information about the installation of the Particle SDK,

+ Please refer to the [Particle firmware](https://github.com/spark/firmware) :octicons-link-external-16: page.

Because the Particle firmware is hosted and maintained in a GitHub repository, the code evolves on a regular basis. Unfortunately, there is no official release scheme with version numbers. This may rise issues if new and change code goes untested.

For ease of use and stability, embedXcode relies on the pre-compiled distributions installed by the Tools for Particle package under the `Particle/build` folder.

However, the embedXcode+ edition can also use the source code under the `Particle/firmware` folder.

To install the GCC for ARM tool-chain,

<center>![](img/Logo-064-GCC.png)</center>

+ Download the [GCC for ARM tool-chain](https://launchpad.net/gcc-arm-embedded/+download) :octicons-link-external-16: release `gcc-arm-none-eabi-4_8-2014q3-20140805-mac`.

+ Unzip it into `~/Library/embedXcode`.

+ If needed, rename the new folder to `~/Library/embedXcode/gcc-arm-none-eabi-4_8-2014q3`.

For more information about the installation of the GCC tool-chain,

+ Please refer to the [GNU Tools for ARM Embedded Processors](https://launchpad.net/gcc-arm-embedded) :octicons-link-external-16: page.

## Visit the official websites

![](img/Logo-064-Spark.png) | **Particle**
---- | ----
IDE | <https://www.particle.io/build> :octicons-link-external-16:
Website | <https://www.particle.io> :octicons-link-external-16:
Download | <https://github.com/spark> :octicons-link-external-16: and <https://github.com/particleio> :octicons-link-external-16:
Blog | <http://blog.particle.io> :octicons-link-external-16:
Documentation | <http://docs.particle.io> :octicons-link-external-16:
Support | <http://support.particle.io> :octicons-link-external-16:
Forum | <https://community.particle.io> :octicons-link-external-16:
