---
tags:
    - Discontinued
---

<style>
.md-typeset h1, .md-typeset h2, .md-typeset h3 { color: #757575; }
</style>

# Install the MediaTek LinkIt platform

:octicons-plus-circle-16: This section requires the embedXcode+ edition.

!!! danger
    MediaTek Labs seems to have been terminated. The website hasn't been updated since March 2017, the forum is closed and requests through the contact pages on both [MediaTek Labs](https://labs.mediatek.com/en/about/contact) :octicons-link-external-16: and [MediaTek](https://www.mediatek.com/about/contact-us) :octicons-link-external-16: are no longer answered.

![](img/Logo-064-LinkIt.png) The installation for the MediaTek LinkIt boards is performed with the **Boards Manager** on the Arduino 1.8 IDE.

!!! warning
    Some utilities required by the MediaTek LinkIt platform are 32-bits only and do not work on macOS 10.15 *Catalina*. They have not been ported to 64-bit.

To allow the 32-bit utilities to run on macOS 10.15 *Catalina*, a parameter needs to be changed on the NVRAM with `sudo nvram boot-args=”no32exec=0″`.

For more information,

+ Please refer to [Bringing back 32-bit apps to life](http://netkas.org/?p=1491) :octicons-link-external-16:.

## Install the LinkIt One board

If you plan to use the MediaTek LinkIt One board,

+ Download and install the supported versions of the Arduino IDE under the `/Applications` folder, as described in the section [Install the Arduino platform](../../Chapter1/Section4/Arduino) :octicons-link-16:.

+ Launch it.

+ Define the path of the sketchbook folder in the menu **Arduino > Preferences > Sketchbook location**.

+ Avoid spaces in the name and path of the sketchbook folder.

+ Follow the procedure [Install additional boards on Arduino](../../Chapter1/Section4/#install-additional-boards-on-arduino) :octicons-link-16:.

+ Call the **Boards Manager** and check the LinkIt One platform is listed.

<center>![](img/098-01-420.png)</center>

If the LinkIt One platform isn't listed on the **Boards Manager**,

+ Open the **Preferences**.

+ Add one of the following URLs on a separate line, as described in section [Add URLs for new boards](../../Chapter1/Section4/#add-urls-for-new-boards) :octicons-link-16:.

```
http://download.labs.mediatek.com/package_mtk_linkitone_index.json
http://download.labs.mediatek.com/package_mtk_linkit_index.json
```

+ Select the board and click on **Install**.

+ Download and install the USB COM port driver for LinkIt ONE development board :octicons-link-external-16:.

:octicons-plus-circle-16: The embedXcode+ edition allows to locate the Arduino IDE in another folder.

+ Please refer to the section [Set the folder for standard IDEs](../../Chapter1/Section3/#set-the-folder-for-standard-ides) :octicons-link-16:.

## Connect the board

You may need to upgrade the board's firmware, as explained at the [Update your board's firmware](https://docs.labs.mediatek.com/resource/linkit-one/en/getting-started/get-started-on-windows/update-your-boards-firmware) :octicons-link-external-16: page.

<center>![](img/099-01-420.png)</center>

The MediaTek LinkIt One board appears under the menu **Tools > Board**.

<center>![](img/099-02-420.png)</center>

For more information,

+ Please refer to the [Get the hardware and software for Mac OS X](https://docs.labs.mediatek.com/resource/linkit-one/en/getting-started/get-started-on-os-x/get-the-hardware-and-software-for-mac-os-x) :octicons-link-external-16: and [Install the Arduino IDE and LinkIt ONE SDK on OS X](https://docs.labs.mediatek.com/resource/linkit-one/en/getting-started/get-started-on-os-x/install-the-arduino-ide-and-linkit-one-sdk-on-os-x) :octicons-link-external-16: pages on the MediaTek website.

## Install the LinkIt Smart 7688 Duo board

If you plan to use the MediaTek LinkIt Smart 7688 Duo board,

+ Download and install the supported versions of the Arduino IDE under the `/Applications` folder, as described in the section [Install the Arduino platform](../../Chapter1/Section4/Arduino) :octicons-link-16:.

+ Launch it.

+ Define the path of the sketchbook folder in the menu **Arduino > Preferences > Sketchbook location**.

+ Avoid spaces in the name and path of the sketchbook folder.

+ Follow the procedure [Install additional boards on Arduino](../../Chapter1/Section4/#install-additional-boards-on-arduino) :octicons-link-16:.

+ Call the **Boards Manager** and check the LinkIt Smart 7688 Duo platform is listed.

<center>![](img/100-01-420.png)</center>

If the LinkIt Smart 7688 Duo platform isn't listed on the **Boards Manager**,

+ Open the **Preferences**.

+ Add one of the following URLs on a separate line, as described in section [Add URLs for new boards](../../Chapter1/Section4/#add-urls-for-new-boards) :octicons-link-16:.

```
http://download.labs.mediatek.com/package_mtk_linkit_smart_7688_index.json
http://download.labs.mediatek.com/package_mtk_linkit_smart_7688_test_index.json
```

+ Select the board and click on **Install**.

:octicons-plus-circle-16: The embedXcode+ edition allows to locate the Arduino IDE in another folder.

+ Please refer to the section [Set the folder for standard IDEs](../../Chapter1/Section3/#set-the-folder-for-standard-ides) :octicons-link-16:.

## Connect the board

You may need to upgrade the board's firmware, as explained at the [MediaTek LinkIt Smart 7688 Hardware Development Kits](http://labs.mediatek.com/site/global/developer_tools/mediatek_linkit_smart_7688/hdk_intro/index.gsp) :octicons-link-external-16: page.

The MediaTek LinkIt One board appears under the menu **Tools > Board**.

<center>![](img/101-01-420.png)</center>

For more information,

+ Please refer to the Get Started Guide on the [MediaTek LinkIt Smart 7688 Software Development Tools Introduction](http://labs.mediatek.com/site/global/developer_tools/mediatek_linkit_smart_7688/sdt_intro/index.gsp) :octicons-link-external-16: and [Install Arduino IDE with board support package](https://docs.labs.mediatek.com/resource/linkit-smart-7688/en/get-started/get-started-with-the-linkit-smart-7688-duo-development-board/install-arduino-ide-with-board-support-package) :octicons-link-external-16: pages of the MediaTek website.

## Install the LinkIt 7697 board

If you plan to use the MediaTek LinkIt 7697 board,

+ Download and install the supported versions of the Arduino IDE under the `/Applications` folder, as described in the section [Install the Arduino platform](../../Chapter1/Section4/Arduino) :octicons-link-16:.

+ Launch it.

+ Define the path of the sketchbook folder in the menu **Arduino > Preferences > Sketchbook location**.

+ Avoid spaces in the name and path of the sketchbook folder.

+ Follow the procedure [Install additional boards on Arduino](../../Chapter1/Section4/#install-additional-boards-on-arduino) :octicons-link-16:.

+ Call the **Boards Manager** and check the LinkIt Smart 7688 Duo platform is listed.

<center>![](img/102-02-420.png)</center>

If the LinkIt 7697 platform isn't listed on the **Boards Manager**,

+ Open the **Preferences**.

+ Add the following URL on a separate line, as described in section [Add URLs for new boards](../../Chapter1/Section4/#add-urls-for-new-boards) :octicons-link-16:.

```
http://download.labs.mediatek.com/package_mtk_linkit_7697_index.json
```

+ Select the board and click on **Install**.

:octicons-plus-circle-16: The embedXcode+ edition allows to locate the Arduino IDE in another folder.

+ Please refer to the section [Set the folder for standard IDEs](../../Chapter1/Section3/#set-the-folder-for-standard-ides) :octicons-link-16:.

## Visit the official websites

![](img/Logo-064-LinkIt.png) | **MediaTek LinkIt**
:---- | ----
IDE | Arduino with Boards Manager
Website | <http://labs.mediatek.com> :octicons-link-external-16:
Download | <http://labs.mediatek.com/site/global/developer_tools/downloads> :octicons-link-external-16:
Reference | <http://labs.mediatek.com/api/linkit-one/frames.html> :octicons-link-external-16:
Forum | <http://labs.mediatek.com/forums/forums/list.page> :octicons-link-external-16:
