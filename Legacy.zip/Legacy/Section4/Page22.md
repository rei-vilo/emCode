---
tags:
    - Discontinued
---

<style>
.md-typeset h1, .md-typeset h2, .md-typeset h3 { color: #757575; }
</style>

# Install the Udoo Neo Platform

:octicons-plus-circle-16: This section requires the embedXcode+ edition.
![](img/Logo-064-UDOO.png)

The installation for the Udoo Neo platform is performed with the **Boards Manager** on the Arduino 1.6.5 IDE.

## Install the Udoo Neo Platform

If you plan to use the Udoo Neo board,

+ Download and install Arduino IDE 1.6.5 under the `/Applications` folder, as described in section [Install the Arduino platform](../../Chapter1/Section4/Arduino) :octicons-link-16:.

If you don't plan to use the Udoo Neo board with the Arduino IDE, there is no need for installing release 1.6.5 of the Arduino IDE as embedXcode doesn't require it.

Release 1.6.5 is required to use the Arduino IDE, as more recent releases of the Arduino IDE don't support the Udoo Neo platform.

+ Launch it.

+ Define the path of the sketchbook folder in the menu **Arduino > Preferences > Sketchbook location**.

+ Avoid spaces in the name and path of the sketchbook folder.

+ Follow the procedure [Install additional boards on Arduino](../../Chapter1/Section4/#install-additional-boards-on-arduino) :octicons-link-16:.

+ Call the **Boards Manager** and check the Udoo Neo platform is listed.

<center>![](img/141-01-420.png)</center>

If the Udoo Neo platform isn't listed on the **Boards Manager**,

+ Open the **Preferences**.

+ Add the following URL on a separate line, as described in section [Add URLs for new boards](../../Chapter1/Section4/#add-urls-for-new-boards) :octicons-link-16:.

```
https://udooboard.github.io/arduino-board-package/package_udoo_index.json
```
Select the boards and click on **Install**.

For more information on the installation of the Udoo Neo board,

+ Please refer to [Very First Start](http://www.udoo.org/docs-neo/Getting_Started/Very_First_Start.html) :octicons-link-external-16: and [Use as an Arduino](http://www.udoo.org/docs-neo/Getting_Started/Use_as_an_Arduino.html) :octicons-link-external-16: pages on the Udoo website.

+ Install the drivers for Mac OS X as explained at the [USB Direct Connection](http://www.udoo.org/docs-neo/Basic_Setup/Usb_Direct_Connection.html) :octicons-link-external-16: page on the Udoo website.

+ To use the upload of firmware over the air or FOTA, install the drivers as explained at the [Install UDOO FOTA](http://www.udoo.org/docs-neo/Getting_Started/Use_as_an_Arduino.html) :octicons-link-external-16: page on the Udoo website.

## Connect the board

The Udoo Neo board is under the menu **Tools > Board**.

<center>![](img/142-01-320.png)</center>

No serial console is displayed after the upload of the sketch to the board. Use either a SSH or a VNC connection to display the output redirected to /dev/ttyMCC. For more information,

+ Please refer to the [Arduino Difference &ndash; Serials](http://www.udoo.org/docs-neo/Arduino_M4_Processor/Arduino_difference.html) :octicons-link-external-16: on the Udoo website.

# Upload to Udoo Neo board

:octicons-plus-circle-16: This section requires the embedXcode+ edition.

![](img/Logo-064-UDOO.png) Compiled sketches can be uploaded to the Udoo Neo board through an USB connection or using WiFi.

## Upload through USB connection

To upload a compiled sketch through USB connection,

+ Plug the Udoo Neo USB cable.

+ Launch any of the targets **All**, **Upload** or :octicons-plus-circle-16: **Fast**.

## Upload using WiFi

The procedure is the same except the IP address has changed.

+ Be sure the Udoo Neo board is connected to the WiFi network.

+ Edit the Udoo Neo (M4) board configuration file and change the IP address for the new one.

```
BOARD_PORT = 192.168.7.2
```

+ Check your board is online.

+ Launch any of the targets **All**, **Upload** or :octicons-plus-circle-16: **Fast**.

## Open a Serial Console

By default, no serial console is opened. The `Serial` port form the Cortex-M4 MCU is connected to the `/dev/ttyMCC` on the Cortex-A9 MPU.

To display the serial console,

+ Open a **Terminal** window.

+ Connect to the Udoo Neo board with a [Remote Terminal (SSH)](http://www.udoo.org/docs-neo/Basic_Setup/Remote_Terminal_(SSH).html) :octicons-link-external-16:.

``` bash
$ ssh udooer@192.169.1.23
$ ssh udooer@udoo.local
```

In this example, the IP address of the board is `192.169.1.23` and its name `udoo`.

+ Launch the following command

``` bash
$ cat /dev/ttyMCC
```

+ Alternatively, use a [Remote Desktop (VNC)](http://www.udoo.org/docs-neo/Basic_Setup/Remote_Desktop_(VNC).html) :octicons-link-external-16:.

## Visit the official websites

![](img/Logo-064-UDOO.png) | **Udoo Neo**
:---- | ----
IDE | Arduino with Boards Manager
Website | <http://www.udoo.org> :octicons-link-external-16:
Blog | <http://www.udoo.org/blog> :octicons-link-external-16:
Wiki | <http://www.udoo.org/docs-neo/Introduction/Introduction.html> :octicons-link-external-16:
Forum | <http://www.udoo.org/forum> :octicons-link-external-16:
