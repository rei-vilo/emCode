---
tags:
    - Discontinued
---

<style>
.md-typeset h1, .md-typeset h2, .md-typeset h3 { color: #757575; }
</style>

# Install the RFduino platform

:octicons-plus-circle-16: This section requires the embedXcode+ edition.

![](img/Logo-064-RFduino.png) The installation of the RFduino board is performed with the **Boards Manager** on the Arduino 1.8 IDE.

## Install the RFduino platform

If you plan to use the RFduino platform,

+ Download and install the supported versions of the Arduino IDE under the `/Applications` folder, as described in the section [Install the Arduino platform](../../Chapter1/Section4/Arduino) :octicons-link-16:.

+ Launch it.

+ Define the path of the sketchbook folder in the menu **Arduino > Preferences > Sketchbook location**.

+ Avoid spaces in the name and path of the sketchbook folder.

+ Follow the procedure [Install additional boards on Arduino](../../Chapter1/Section4/#install-additional-boards-on-arduino) :octicons-link-16:.

+ Call the **Boards Manager** and check the RFduino platform is listed.

<center>![](img/118-01-420.png)</center>

If the RFduino platform isn't listed on the **Boards Manager**,

+ Open the **Preferences**.

+ Add the following URL on a separate line, as described in section [Add URLs for new boards](../../Chapter1/Section4/#add-urls-for-new-boards) :octicons-link-16:.

```
http://rfduino.com/package_rfduino_index.json
```

+ Select the board and click on **Install**.

For more information on the installation of the RFduino board on the Arduino IDE,

+ Please refer to the [Installation](https://github.com/RFduino/RFduino/blob/master/README.md) :octicons-link-external-16: page on the RFduino website.

## Connect the board

The RFduino board is under the menu **Tools > Board**.

<center>![](img/119-01-340.png)</center>

## Visit the official websites

![](img/Logo-064-RFduino.png) | **RFduino**
:---- | ----
IDE | Arduino with Boards Manager
Website | <http://www.rfduino.com/> :octicons-link-external-16:
Download | <http://www.rfduino.com/download-rfduino-library> :octicons-link-external-16:
Wiki | <http://www.rfduino.com/documentation> :octicons-link-external-16:
Forum | <http://forum.rfduino.com> :octicons-link-external-16: