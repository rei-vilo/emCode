<style>
.md-typeset h1, .md-typeset h2, .md-typeset h3 { color: #757575; }
</style>

# Install embedXcode Legacy 10

## Check the discontinued platforms

:octicons-plus-circle-16: This section requires the embedXcode+ edition.

The table below provides the last version of embedXcode supporting the platform before it was declared on hold then discontinued.

Platform | Boards | On Hold After | Discontinued After
---- | ---- | ---- | ----
![](img/Logo-064-ftDuino.png) ftDuino | ftDuino | 10.6.3 | 10.9.9
![](img/Logo-064-LightBlue.png) Punch Through Design | Bean and Bean+ | 9.6.8 | 10.9.9
![](img/Logo-064-panStamp.png) panStamp | AVR and NRG | 10.9.5 | 10.9.9
![](img/Logo-064-RedBearLab-no-brand.png) RedBear | All boards | 9.6.8 | 10.9.9

## Check the discontinued features

Release 11.0 simplifies the process to check the availability a new release of embedXcode.

embedXcode no longer checks the availability a new release during compilation. As a consequence, the **Allow New Release Check** utility is deprecated.

The procedure is replaced by the new **Check New Release** utility. The utility checks both the standard and plus editions, and prompts a dialogue box to download them. The utility sends the current edition and version of embedXcode anonymously.

<center>![](img/check-100.png)</center>

For more information on the new **Check New Release** utility and procedure,

+ Please refer to [Update embedXcode](../../Chapter1/Section6/) :octicons-link-16: and [Check new release](../../Chapter1/Section6/#check-a-new-release) :octicons-link-16:.

For the previous procedure,

+ Please refer to [Check embedXcode new releases](../../Legacy/Section10/#check-embedxcode-new-releases) :octicons-link-16:.

## Download embedXcode Legacy 10

:octicons-plus-circle-16: This section requires the embedXcode+ edition.

For legacy systems running Xcode 10 on macOS 10.13 *High Sierra* or 10.14 *Mojave*,

+ Please select the **embedXcode Legacy 10** option. It corresponds to embedXcode release 10.9.9.

<center>![](img/Legacy10.png)</center>

!!! warning
    embedXcode Legacy 10 is no longer developed and has limited support.

## Install embedXcode Legacy 10

To install embedXcode Legacy 10,

+ Please refer to [Install embedXcode](../../Chapter1/Section3/#install-embedxcode_1) :octicons-link-16:.

## Check embedXcode new releases

With embedXcode Legacy 10, checking for new releases is performed  automatically but needs to be enabled with the **Allow New Release Check** utility.

### Authorise to check new release

When checking the availability a new release of embedXcode, some information is sent anonymously. It includes current edition and version of embedXcode, and targeted platform. This information is required to generate and customise the answer.

By default, checking new release of embedXcode is disabled. During the first launch of embedXcode, a dialogue box asks for an explicit opt-in.

<center>![](img/Disabled.png)</center>

+ Click on **Enable** to check the availability of new releases of embedXcode.

+ Click on **Disable** otherwise.

!!! warning
    Opting-out turns the automatic procedure off.

The option can be changed anytime. To do so,

+ Launch the **Allow New Release Check** utility located on the `~/Documents/embedXcode` folder.

<center>![](img/utilityAllow.png)</center>

A dialogue box indicates the state of the option and allows to enable or disable it.

<center>![](img/Disabled.png)</center>

In the example above, the option is disabled.

+ Click on **Enable** to check the availability of new releases of embedXcode.

+ Click on **Disable** otherwise.

!!! Warning
    Opting-out turns the automatic [Check and download new release](../../Legacy/Section10/#download-new-release) :octicons-link-16: procedure off.

### Download new release

During the first compilation of the project, a dialogue box prompts if a new release of embedXcode is available.

!!! info
    Due to a change of server, the update message no longer works for versions prior to 7.5.1.

The dialogue box closes automatically after 10 seconds.

<center>![](img/388-01-360.png)</center>

+ Click on **Go to Download** to download the new release or **Ignore** to ignore it.

+ Proceed with the installation.

During the following compilations of the project, the dialogue box is replaced by a notification.

<center>![](img/388-02-360.png)</center>

In all cases, a message is printed on the **Report Navigator**.

```
==== Check project embed1 ====
---- A new release 7.5.3 is available ----
04 Jul 2017 release 7.5.3   Improved stability for compact main.cpp
Template provides release 7.5.2
==== Project embed1 checked ====
```

For embedXcode, the new release of the template only applies for new projects. Existing projects are not updated with the new template.

+ Please refer to the section [Update the projects](../../Chapter1/Section6/#update-the-projects) :octicons-link-16: for more details.

:octicons-plus-circle-16: All the projects created with the embedXcode+ edition use the latest release of the installed template. There is no need to update the projects themselves.

### Select the project update procedure

Depending on the initial project and the edition, different procedures are available.

To update a project with embedXcode standard edition,

+ Follow the procedure [Update the projects](../../Chapter1/Section6/#update-the-projects) :octicons-link-16:.

:octicons-plus-circle-16: Projects created with the embedXcode+ edition always use the latest release of the installed template.

+ There is nothing to do!

:octicons-plus-circle-16: To upgrade a project created with embedXcode standard edition to embedXcode+ edition,

+ Follow the procedure [Upgrade projects from embedXcode to embedXcode+](../../Chapter1/Section6/#upgrade-projects-from-embedxcode-to-embedxcode) :octicons-link-16:.
