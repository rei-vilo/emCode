<style>
.md-typeset h1, .md-typeset h2, .md-typeset h3 { color: #757575; }
</style>

# Install embedXcode Legacy 11

## Check the discontinued platforms

:octicons-plus-circle-16: This section requires the embedXcode+ edition.

The table below provides the last version of embedXcode supporting the platform before it was declared on hold then discontinued.

Platform | Boards | On Hold After | Discontinued After
---- | ---- | ---- | ----
![](img/Logo-064-chipKIT.png) | chipKIT | 11.6.0 | 11.9.11
![](img/Logo-064-4D-Systems.png) | 4D Systems | 11.6.0 | 11.9.11
![](img/Logo-064-panStamp.png) | panStamp STM32L4 | 11.2.5 | 11.9.11
![](img/Logo-064-LinkIt.png) | Mediatek LinkIt | 11.4.0 | 11.9.11
![](img/Logo-064-Microduino.png) | Microduino | 11.4.0 | 11.9.11
![](img/Logo-064-STM32duino_old.png) | STM32duino | 11.4.0 | 11.9.11
![](img/Logo-064-TinyCircuits.png) | TinyCircuits | 11.4.0 | 11.9.11
![](img/Logo-064-UDOO.png) | Udoo Neo | 11.4.0 | 11.9.11

## Check the discontinued features

Release LTS 11.0 is the long-term support version of embedXcode 11.

It targets Xcode 11 on macOS 10.15.6 *Catalina*, provides maintenance, updates and support, and guarantees embedXcode users a stable and reliable tool.

## Download embedXcode Legacy 11

:octicons-plus-circle-16: This section requires the embedXcode+ edition.

For legacy systems running Xcode 11 on macOS 10.14 *Mojave* or 10.15 *Catalina*,

+ Please select the **embedXcode Legacy 11** option. It corresponds to embedXcode release 11.9.11.

<center>![](img/Legacy11.png)</center>

!!! warning
    embedXcode Legacy 11 is no longer developed and has limited support.

## Install embedXcode Legacy 11

To install embedXcode Legacy 11,

+ Please refer to [Install embedXcode](../../Chapter1/Section3/#install-embedxcode_1) :octicons-link-16:.

### Simplified include statement

Starting with release 12, the `#include` statement on the main sketch and the header of libraries has been simplified.

The new `#include` statement lists Energia and Arduino only,

```make
// Core library for code-sense - IDE-based
// !!! Help: https://bit.ly/2AdU7cu
#if defined(ENERGIA) // LaunchPad specific
#include "Energia.h"
#elif defined(ARDUINO) // Arduino 1.0 and 1.5 specific
#include "Arduino.h"
#else // error
#error Platform not defined
#endif // end IDE
```

while the previous statement mentioned other platforms, most of them turned legacy.

```make
// Core library for code-sense - IDE-based
// !!! Help: http://bit.ly/2AdU7cu
#if defined(WIRING) // Wiring specific
#include "Wiring.h"
#elif defined(MAPLE_IDE) // Maple specific
#include "WProgram.h"
#elif defined(ROBOTIS) // Robotis specific
#include "libpandora_types.h"
#include "pandora.h"
#elif defined(MPIDE) // chipKIT specific
#include "WProgram.h"
#elif defined(DIGISPARK) // Digispark specific
#include "Arduino.h"
#elif defined(ENERGIA) // LaunchPad specific
#include "Energia.h"
#elif defined(LITTLEROBOTFRIENDS) // LittleRobotFriends specific
#include "LRF.h"
#elif defined(MICRODUINO) // Microduino specific
#include "Arduino.h"
#elif defined(TEENSYDUINO) // Teensy specific
#include "Arduino.h"
#elif defined(REDBEARLAB) // RedBearLab specific
#include "Arduino.h"
#elif defined(RFDUINO) // RFduino specific
#include "Arduino.h"
#elif defined(SPARK) || defined(PARTICLE) // Particle / Spark specific
#include "application.h"
#elif defined(ESP8266) // ESP8266 specific
#include "Arduino.h"
#elif defined(ARDUINO) // Arduino 1.0 and 1.5 specific
#include "Arduino.h"
#else // error
#error Platform not defined
#endif // end IDE
```
