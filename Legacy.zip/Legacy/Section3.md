<style>
.md-typeset h1, .md-typeset h2, .md-typeset h3 { color: #757575; }
</style>

# Install embedXcode Legacy 8

:octicons-plus-circle-16: This section requires the embedXcode+ edition.

## Check the discontinued platforms

Release 9.0 removes the legacy boards listed below for a more compact installation package.

Platform | Boards | Comment
---- | ---- | ----
![](img/Logo-064-ArduCAM.png) ArduCAM | ESP8266 and CC3200 | Discontinued
![](img/Logo-064-Cosa.png) Cosa | | On hold
![](img/Logo-064-Digistump-3.png) Digistump | Digispark, DigiX and Oak | Discontinued
![](img/Logo-064-Glowdeck.png) Glowdeck | Glowdeck | Discontinued
![](img/Logo-064-Intel-IDE.png) Intel | Galileo, Galileo Gen 2 and Edison | Discontinued, but Curie still supported
![](img/Logo-064-Little-Robot-Friend.png) Little Robot Friends | Little Robot Friends | Discontinued
![](img/Logo-064-Maple.png) Maple | | Discontinued, use STM32duino instead
![](img/Logo-064-Spark.png) Particle | Core | On hold
![](img/Logo-064-Robotis.png) Robotis | | Discontinued, use STM32duino instead
![](img/Logo-064-Wiring.png) Wiring | | Discontinued

## Download embedXcode Legacy 8

For those legacy boards,

+ Select and install the **embedXcode Legacy 8** installation package. It corresponds to embedXcode release 7.6.8.

<center>![](img/Legacy8.png)</center>

!!! danger
    embedXcode Legacy 8 is deprecated and no longer supported.

!!! danger
    embedXcode Legacy 8 is no longer available for download.

As an alternative, the tools can be installed manually.

+ Please refer to [Use discontinued Wiring / Arduino frameworks](../../Legacy/Section4) :octicons-link-16:, [Use discontinued Intel Edison SDKs](../../Legacy/Section5) :octicons-link-16: or [Use discontinued Cosa framework](../../Legacy/Section6) :octicons-link-16:.

## Install embedXcode Legacy 8

If necessary, the installation package downloads and installs the tool-chains and the SDKs.

An internet connection is thus required during the installation process.

+ Double-click on the **embedXcode** package icon to launch the installation.

<center>![](img/153-01-100.png)</center>

Mac OS X requires the installation packages to be signed.

Because the embedXcode installation package is not signed, the following message may appear.

<center>![](img/153-02-360.png)</center>

Depending on the installed version of Mac OS X,

+ Open the security parameters defined by calling the menu **:fontawesome-brands-apple: > Preferences > Security & Privacy > General**.

+ Either select **Allow apps downloaded from anywhere**.

<center>![](img/153-03-300.png)</center>

+ Or click on **Open Anyway**.

<center>![](img/153-04-420.png)</center>

As an alternative,

+ Press ++ctrl+left-button++ on the embedXcode package icon to display the contextual menu and select **Open**.

<center>![](img/154-01-260.png)</center>

A window prompts for confirmation.

<center>![](img/154-02-360.png)</center>

+ Answer **Open** to proceed.

The installation starts and displays the welcome screen.

<center>![](img/154-03-400.png)</center>

+ Click on **Continue** to proceed.

The licence is displayed.

<center>![](img/155-01-400.png)</center>

+ Click on **Continue**.

<center>![](img/155-02-360.png)</center>

+ Click on **Agree** to proceed.

<center>![](img/155-03-400.png)</center>

An additional window may ask for the destination.

<center>![](img/156-01-400.png)</center>

+ Select Install for me only to enable the Continue button.

+ Click on **Continue** to proceed.

The next window presents different options for the installation.

The options allow to select the frameworks you want to work with. When a framework is selected, the installer checks whether the corresponding tool-chain and SDK are already installed. If needed, it downloads and installs them. The downloaded files can represent up to 748 MB.

The Particle framework weights 80 MB, with 76 MB for the GCC tool-chain and 4 MB for the SDK.

The two Edison frameworks represent 668 MB, with 492 MB for the Yocto environment, and 176 MB for the MCU environment.

+ Check or uncheck the options.

<center>![](img/156-02-280.png)</center>

+ Click on **Continue** to proceed.

Next window asks for confirmation of the installation.

<center>![](img/156-03-400.png)</center>

+ Click on **Install** to proceed.

A window prompts for your name and password.

<center>![](img/157-01-360.png)</center>

+ Enter both and click on **Install Software**.

The installation goes on.

<center>![](img/157-02-400.png)</center>

If the mbed framework has been selected, an additional dialogue box asks for the folder where the mbed projects are saved.

<center>![](img/157-03-420.png)</center>

Similar dialogue boxes ask for the folders where the Particle projects and Yocto projects are saved.

+ Select an existing folder or create a new one with **New Folder**.

+ Click **Choose**.

The installation has been successful.

<center>![](img/158-01-400.png)</center>

+ Click on **Close** to finalise.

A final window asks to delete the installation package.

<center>![](img/158-02-400.png)</center>

+ Click on **Keep** to keep the installation package.

+ Click on **Move to Trash** to delete the installation package.

## Launch the installation manually

In case the automatic installation fails,

+ Open a **Terminal** window.

+ Launch the command

``` bash
sudo installer -pkg embedXcode-231.pkg -target /
```
:octicons-plus-circle-16: With the embedXcode+ edition release 7.0 and later, all the projects use the latest release of the installed template. There is no need to update the projects themselves.

:octicons-plus-circle-16: Project created with embedXcode+ prior to release 7.0 need to be updated.

+ Please refer to the section [Update project automatically](../../Legacy/Section2/#upgrade-projects-from-embedxcode-to-embedxcode) :octicons-link-16: for more details.
